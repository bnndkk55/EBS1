#!/usr/bin/perl
#���L���a�I���ӱN��Ʈ���
require "ebs_sub1.cgi";
require "debug_sub.pl";
print "Content-type: text/html;\n\n";

pre_get_value();
$GetUserName=$parm1;
$GetUserPassword=$parm2;



&DBM_INPORT(P);
@PL_VALUES = split(/\s/,$P{"$GetUserName"});
$realpassword=(crypt ($GetUserPassword,eb));
#print "Pass=1 ($GetUserPassword ne $realpassword)";
if ($realpassword ne @PL_VALUES[2]) {print "Pass=0";return;}

print "Pass=1"; 
exit;





sub pre_get_value
{
# ���Φr��Χ�r��ѽX�^��Ӫ��r��
if ($ENV{'REQUEST_METHOD'} eq 'POST')
{
    read(STDIN, $temp, $ENV{'CONTENT_LENGTH'});
}
else
{
    $temp=$ENV{'QUERY_STRING'};
}

@key_value=split(/&/,$temp);

foreach $item(@key_value) 
{
    ($key,$value)=split (/=/,$item,2);
    $value=~tr/+/ /;
    $value=~ s/%(..)/pack("c",hex($1))/ge;
    $FORM{$key}=$value;
}

$buff = "$ENV{'QUERY_STRING'}";
$buff =~ s/\+/ /g;

($parm1,$parm2,$parm3,$parm4,$parm5)=split(/ /,$buff);
}
