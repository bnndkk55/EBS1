#!/usr/bin/perl
#���L���a�I���ӱN��Ʈ���
require "ebs_sub1.cgi";
require "debug_sub.pl";
$PasswordNameErrorMdy="�K�X�����D!";
%GMPassword=("DEBUG"=>"ertgfd","GM01"=>"rtgbvf","Chris"=>"ertyuyty","GM05"=>"gm05asdqwezxc");
print "Content-type: text/html;\n\n";
print "<html>";
&pre_get_value;


$UserName=$FORM{'SelectID'};
$Password=$FORM{'GmPassword'};
$GmName=$FORM{'GmName'};
$RestoreDay=$FORM{'RestoreDay'};
if (($GmName eq "") or ($Password eq ""))
{
print << "---HTNLTAG----"; 
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=big5">
</head>
<body bgcolor="#FFF4E6">
<form method="POST" action="restoreuserdata.pl?writedata" name="PasswordForm">
ID<input type="text" value="$GmName" name="GmName">
Password<input type="password" value="$Password" name="GmPassword"><br>
�n�٭쪺���aID�<<input type="text" value="$UserName" name="SelectID"><br>
�n�٭쪺���(�u����)<input type="text" value="" name="RestoreDay"><br>
<input type="submit" value="OK">
</form>
</body>
</html>
---HTNLTAG----
exit;
}	

CheckGMPassword($GmName,$Password);
print "�K�X�q�L!<br>";

if (($RestoreDay <1) || ($RestoreDay >31)){print "�������!";exit;}


if ($parm1 eq "writedata")
{
$RealBakFile="$EventRecordDir/ebsbak$RestoreDay";
if (!-e "$RealBakFile.db"){print "File read error!";exit}

&LOCK;
dbmopen (%V2,"$DBM_P",0666);
dbmopen (%VBK,"$EventRecordDir/restorbak",0666);
%VBK=%V;
dbmclose %VBK;
dbmclose %V2;
&UNLOCK;
print '�ƥ���ƪ���<br>';

@PL_VALUES=ReadDBData($UserName,$RealBakFile);
WriteDBData($DBM_P,$UserName,@PL_VALUES);
print "�٭�OK!";
}



sub pre_get_value
{
# ���Φr��Χ�r��ѽX�^��Ӫ��r��
if ($ENV{'REQUEST_METHOD'} eq 'POST')
{
    read(STDIN, $temp, $ENV{'CONTENT_LENGTH'});
}
else
{
    $temp=$ENV{'QUERY_STRING'};
}

@key_value=split(/&/,$temp);

foreach $item(@key_value) 
{
    ($key,$value)=split (/=/,$item,2);
    $value=~tr/+/ /;
    $value=~ s/%(..)/pack("c",hex($1))/ge;
    $FORM{$key}=$value;
}

$buff = "$ENV{'QUERY_STRING'}";
$buff =~ s/\+/ /g;

($parm1,$parm2,$parm3)=split(/ /,$buff);
}


sub WriteDBData
{
my($FileName,$UserName,@DataValue)=@_;
&LOCK;
dbmopen (%P,"$FileName",0666);
$P{"$UserName"}="@DataValue";
dbmclose %P;
&UNLOCK;
print "Wrote ($UserName,$FileName)";
}	

sub ReadDBData
{
my @DataValue;
my($UserName,$FileName)=@_;
&LOCK;
dbmopen (%V,"$FileName",0666);
@DataValue= split(/\s/,$V{"$UserName"});
dbmclose %V;
&UNLOCK;
return @DataValue;
}	

sub CheckGMPassword
{
my($GmName,$Password)=@_;
if (($GmName ne "") && ($Password ne ""))
{
my $PasswordInfo=$GMPassword{$GmName};
if ($PasswordInfo ne $Password)
{
print $PasswordNameErrorMdy;
exit;
}	
}
else
{
print $PasswordNameErrorMdy;
exit;
}		

}	
