use DBI;

#print "start..";
#$dbh = DBI->connect("DBI:mysql:database=$cfsq04;host=$MysqlHost",$cfsq02,$cfsq03, {RaiseError => 1});
#print "connect<br>";
#表格建立
sub sql01
{
my ($DataBaseHead,$TableName,$TableFieldNameType)=@_;
$sth=$DataBaseHead->do ("CREATE TABLE IF NOT EXISTS $TableName ($TableFieldNameType)");
$dbh->disconnect ();
}

 
#資料寫入
sub sql02
{
my ($DataBaseHead,$TableName,$TableFieldName,$TableFieldValue)=@_;
my $MyCommand=$DataBaseHead->do("INSERT INTO $TableName ($TableFieldName) VALUES ($TableFieldValue)" );
my $sth=$DataBaseHead->prepare($MyCommand);
}


#=============== Show some =========================
#資料找尋
#sql03(表頭代碼,表格名稱,模式,要搜索的欄位名稱,開頭的關鍵字,結尾的關鍵字)
#模式:some=一些,
#開頭的關鍵字,結尾的關鍵字若均為空的將搜詢所有資料
#開頭的關鍵字='aa',結尾的關鍵字='bb' 則會找所有符合 aa*bb的資料
#
#sql03($DataBaseHead,$table,"all",'ID');為找出所有內容
#$AllValue=sql03($DataBaseHead,$table,"some",'ID','','');
#while (my $row=$AllValue->fetchrow_hashref())
#{print "Name $row->{ID} $row->{BASE_DATA} $row->{OTHERS} <br>";}	

sub sql03
{
my ($DataBaseHead,$TableName,$Mode,@Other)=@_;
my $sth;

if ($Mode eq "all")
{
my ($FieldName)=@Other;
$sth=$DataBaseHead->prepare("SELECT * FROM $TableName");
$sth->execute();
}



if ($Mode eq "some")
{
my ($FieldName,$ValueHead,$ValueTail)=@Other;
$sth=$DataBaseHead->prepare("SELECT * FROM $TableName where $FieldName like ? ");
$sth->execute("$ValueHead%$ValueTail");
}

#$orderT = DESC 為由大排到小
#$orderT = ASC 為由小排到大
#$AllValue=&sql03($dbh,$cfsq05,"order",'B97',$readStartN,$pageMaxList,'DESC');
if ($Mode eq "order")
{
my ($FieldName,$starts,$amount,$orderT)=@Other;
$sth=$DataBaseHead->prepare("SELECT * FROM $TableName ORDER BY $FieldName $orderT LIMIT $starts,$amount ");
$sth->execute();
}



if ($Mode eq "one")
{
my ($FieldName,$Value)=@Other;
#$sth=$DataBaseHead->prepare("SELECT * FROM $TableName where $FieldName = '$Value'"); 
#$sth->execute();
$sth=$DataBaseHead->selectrow_hashref("SELECT * FROM $TableName where $FieldName = '$Value'"); 
}


if ($Mode eq "selfset")
{
my ($SelfSet,$SPMode)=@Other;
if ($SPMode eq '0')
{
$sth=$DataBaseHead->selectrow_hashref("SELECT * FROM $TableName where $SelfSet"); 
}
if ($SPMode eq '1')
{
$sth = $DataBaseHead->prepare ("SELECT * FROM $TableName where $SelfSet");
$sth->execute();
}
}

return $sth;
}

#刪除整個表格資料 sql04(表頭代碼,表格名稱);
#sql04($DataBaseHead,$table);
sub sql04
{
my ($DataBaseHead,$TableName)=@_;
$sth=$DataBaseHead->do ("DROP TABLE $TableName");
$dbh->disconnect ();
}


#刪除一筆資料 sql05(表頭代碼,表格名稱,由那個欄位名找,找到某值後才刪)
#sql05($DataBaseHead,$table,'ID','1064378182');
sub sql05
{
my ($DataBaseHead,$TableName,$FieldName,$Value)=@_;
my $MyCommand=$DataBaseHead->do("delete from $TableName where $FieldName='$Value'" );
my $sth=$DataBaseHead->prepare($MyCommand);
}


#改變某欄位資料內容 sql06(表頭代碼,表格名稱,由那個欄位名找,要找該欄位相符的值,找到後要改變的值,)
#sql06($DataBaseHead,$table,'ID','abcdefg',"B0='$FORM{B0}'");
sub sql06
{
my ($DataBaseHead,$TableName,$FieldName,$Value1,$Update_Field_Value)=@_;
my $MyCommand=$DataBaseHead->do("update $TableName set $Update_Field_Value where $FieldName = '$Value1'" );
my $sth=$DataBaseHead->prepare($MyCommand);
#my $sth=$DataBaseHead->prepare("update $TableName set $Update_Field_Value where $FieldName = '$Value1'");

}

1;