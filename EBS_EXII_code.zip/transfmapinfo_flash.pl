#!/usr/bin/perl
#���L���a�I���ӱN��Ʈ���
require "ebs_sub1.cgi";
require "debug_sub.pl";
print "Content-type: text/html;\n\n";
@ReadMapData=read_file("ebsmap1.dat");
chomp (@ReadMapData);

$MapIndex=0;
$Counti=0;
$TotalMapI=@ReadMapData;
print "TotalMi=$TotalMapI";
$ca1=chr(10);
$ca2=chr(13);
foreach(@ReadMapData)
{
$userdata_line=@ReadMapData[$MapIndex];
$userdata_line=~ s/$ca1//g;
$userdata_line=~ s/$ca2//g;
local($mapx,$mapy,$PlaceAttr,$status,$other) = split(/,/,$userdata_line);
#if ($status ne '�L')
#{
print "&Mapx$Counti=$mapx&Mapy$Counti=$mapy&PlcAt$Counti=$PlaceAttr&Stat$Counti=$status&MapPic$mapx$mapy=$PlaceAttr";
$Counti++;
#}
$MapIndex++;
}
print "&TotalRealMi=$Counti";
