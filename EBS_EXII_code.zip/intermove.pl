#!/usr/bin/perl
require "ebs_sub1.cgi";require "debug_sub.pl";
print "Content-type: text/html;\n\n";
print '<meta http-equiv="ache-control"" content="no-cache">';
print '<html><body bgcolor="#E3E3E3">';&pre_get_value;if ($parm1 eq ""){return;}if ($parm1 eq "move"){$MoveWay=$FORM{'movemode'};$GetUserName=$FORM{'pname'};$GetUserPassword=$FORM{'pass'};}&DBM_INPORT(P);@PL_VALUES = split(/\s/,$P{"$FORM{'pname'}"});CheckPassword($GetUserPassword,@PL_VALUES[2]);$MapGobalSetX=50;$MapGobalSetY=35;$MaxX=50;$MaxY=50;$MinX=0;$MinY=0;$OutputMessage="";$EachMoveTimeSet=5;$MoveNeedEN=100;$XD=10;$YD=10;if (rindex($Ipaddress,'192.168.0') ne -1) {$ExternalImage=$UserLocalDir;$EachMoveTimeSet=0;$MoveNeedEN=0;}

$NoMove = 0;

print qq~
<script>
function SetImgXY(Img,Px,Py,PlayerID){var Vx=Px*$XD;var Vy=Py*$YD;Vx+=$MapGobalSetX;Vy+=$MapGobalSetY;document.write('<img src="$UserLocalDir/images/img3/'+Img+'.gif" style="position: absolute; visibility: visible; z-index: 2; top:'+Vy+'; left:'+Vx+';zoom:25%" alt="'+PlayerID+'">');}	
</script>
~;(@PL_VALUES[15],@PL_VALUES[25])=AutoRepair("HP",@PL_VALUES[15],@PL_VALUES[16],@PL_VALUES[25],@PL_VALUES[26]);(@PL_VALUES[17],@PL_VALUES[25])=AutoRepair("EN",@PL_VALUES[17],@PL_VALUES[18],@PL_VALUES[25],@PL_VALUES[26]);($PlCurrentWeaponID,$None)= split(/!/,@PL_VALUES[9]);$OutputMessage="Go!$GetUserName! ";if ((time)-@PL_VALUES[26]< $EachMoveTimeSet) {$NoMove=1;$OutputMessage.="���ʳt�פӧ�..����L�k�Ө�! ";}if (@PL_VALUES[25] == 1) {$NoMove=1;$OutputMessage.="����ײz��..�L�k����! ";}if (@PL_VALUES[17] < $MoveNeedEN) {$NoMove=1;$OutputMessage.="EN ����..�L�k����! ";}$UserX=@PL_VALUES[95];$UserY=@PL_VALUES[96];





if ($NoMove eq 1) {$OutputMessage.=" �L���� ";}else{if ($MoveWay eq "�F") {$UserX++;$IsWall=0;if ($UserX > $MaxX) {$UserX = $MinX;}}if ($MoveWay eq "��") {$UserX--;$IsWall=0;if ($UserX < $MinX) {$UserX = $MaxX;}}if ($MoveWay eq "�_") {$UserY--;$IsWall=0;if ($UserY < $MinY) {$UserY = $MaxY;}}if ($MoveWay eq "�n") {$UserY++;$IsWall=0;if ($UserY > $MaxY) {$UserY = $MinY;}}if ($UserX eq "") {$UserX=0;}if ($UserY eq "") {$UserY=0;}


@ReadMapData=read_file("ebsmap1.dat");
$MaxIndex=@ReadMapData-1;

#print "$NoMove �{���ק襤,�ɶ��Ƥ� �y�� �� 49 x 49";

if ($UserX > 49) {$UserX = 0;};
if ($UserY > 49) {$UserY = 0;};







$MapIndex=($UserX*50)+$UserY;

$userdata_line=@ReadMapData[$MapIndex];
$userdata_line=mychomp($userdata_line);

if ($MoveWay eq "m")
{
$imapidx=0;
print "<br>";
foreach (@ReadMapData)
{

$userdata_line=@ReadMapData[$imapidx];
$userdata_line=mychomp($userdata_line);
local($mapx,$mapy,$PlaceAttr,$status) = split(/,/,$userdata_line);
if ($PlaceAttr eq '��a') {$maptype='grass10x10';}
if ($PlaceAttr eq '��L') {$maptype='tree10x10';}
if ($PlaceAttr eq '����') {$maptype='town10x10';}
if ($PlaceAttr eq '�۰�') {$maptype='rock10x10';}
if ($PlaceAttr eq '�s��') {$maptype='mount10x10';}
$showx=($mapx *10)+$MapGobalSetX;
$showy=($mapy *10)+$MapGobalSetY;
print qq~<img src="$ExternalImage/$maptype.gif" style="position: absolute; visibility: visible; z-index: 3; top:$showy; left:$showx;">~;

$imapidx++;

	
}
	
}


local($mapx,$mapy,$PlaceAttr,$status) = split(/,/,$userdata_line);

#1print "-- $NoMove  $mapx,$mapy,$PlaceAttr,$status)--";
if ($NoMove == 0) {CheckStatus();}








#exit;





@PL_VALUES[95]=$UserX;@PL_VALUES[96]=$UserY;@PL_VALUES[26]=(time);@PL_VALUES[17]-=$MoveNeedEN;if (@PL_VALUES[100] eq ''){@PL_VALUES[100]='0';}$OutputMessage.="$MoveWay�� ��y��:X:$UserX,Y:$UserY ����$MoveNeedEN EN �� @PL_VALUES[17] EN.";}WritePldata($GetUserName,@PL_VALUES);print '<script>';print "SetImgXY('@PL_VALUES[100]',$UserX,$UserY,'$GetUserName');";while (($Key,$Value) = each %MapNPCInfo){@NPC_VALUES = split(/\,/,$Value);print "SetImgXY(\"0\",@NPC_VALUES[0],@NPC_VALUES[1],\"$Key:@NPC_VALUES[2]\");\n";}while (($Key,$Value) = each %P){if ($Key ne $GetUserName){@VS_VALUES = split(/\s/,$Value);$VsX=@VS_VALUES[95];$VsY=@VS_VALUES[95];if (($VsX ne "") && ($VsY ne "")){print "SetImgXY(\"@VS_VALUES[100]\",$VsX,$VsY,\"$Key\");\n";}}} print '</script>';print "</body></html>";

print qq~



<img src="$ExternalImage/50x50bmap.gif" style="position: absolute; visibility: visible; z-index: -1; top:$MapGobalSetY; left:$MapGobalSetX;">







<table border="0" width="980" cellspacing="0" height="230" cellpadding="0">
  <tr>
    <td width="542" rowspan="2" height="226"></td>
    <td width="422" height="51" valign="top" align="left">
      <table border="1" width="101%" bordercolor="#E9FEC0" bordercolorlight="#77E613" bordercolordark="#CEFFCE" bgcolor="#BEF894" height="42">
        <tr>
          <td width="100%" height="36">�a�ϵ{��:DEBUG�P���J�����s�@ �{���ק襤,�ɶ��Ƥ� $UserX,$UserY </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td width="422" height="171" valign="top" align="left">�@
      <table border="1" width="100%" height="150">
        <tr>
          <td width="100%" bgcolor="#E7C687" bordercolor="#F7E0AC" bordercolorlight="#C19D31" bordercolordark="#EDDFC5" height="144">$OutputMessage</td>
        </tr>
      </table>
      �@









~;




exit;sub WritePldata{my($UserName,@DataValue)=@_;&LOCK;dbmopen (%P,"$DBM_P",0666);$P{"$UserName"}="@DataValue";dbmclose %P;&UNLOCK;}	sub ReadPldata{my @DataValue;my($UserName)=@_;&LOCK;dbmopen (%V,"$DBM_P",0666);@DataValue= split(/\s/,$V{"$UserName"});dbmclose %V;&UNLOCK;return @DataValue;}	sub pre_get_value{if ($ENV{'REQUEST_METHOD'} eq 'POST'){    read(STDIN, $temp, $ENV{'CONTENT_LENGTH'});}else{    $temp=$ENV{'QUERY_STRING'};}@key_value=split(/&/,$temp);foreach $item(@key_value) {    ($key,$value)=split (/=/,$item,2);    $value=~tr/+/ /;    $value=~ s/%(..)/pack("c",hex($1))/ge;    $FORM{$key}=$value;}$buff = "$ENV{'QUERY_STRING'}";$buff =~ s/\+/ /g;($parm1,$parm2,$parm3)=split(/ /,$buff);}sub AutoRepair(){my $ReturnHP,$ReturnEN,$CurrentTime;my($Mode,$CurrentValue,$LimitValue,$CurrentStatus,$LastFightTime)=@_;$CurrentTime=(time);if ($Mode eq "HP"){$ReturnHP=$CurrentValue+($CurrentTime-$LastFightTime)*$HP_REPAIR;if ($ReturnHP > $LimitValue)    {$ReturnHP = $LimitValue;return ($ReturnHP,0);}   else    {return ($ReturnHP,$CurrentStatus);}}	if ($Mode eq "EN"){$ReturnEN=$CurrentValue+($CurrentTime-$LastFightTime)*$EN_REPAIR;if ($ReturnEN > $LimitValue)    {$ReturnEN = $LimitValue;return ($ReturnEN,$CurrentStatus);}   else    {return ($ReturnEN,$CurrentStatus);}}	}	






sub CheckStatus
{

	 if ($status eq '�p��') 
	    {
	    local($mapx,$mapy,$PlaceAttr,$status,$MoneyAmount) = split(/,/,$userdata_line);
       	    
       	    
	    $OutputMessage.="$GetUserName �b$PlaceAttr �J��p�� �l��$MoneyAmount G";
	    @PL_VALUES[8]-=$MoneyAmount;
	    WritePldata($GetUserName,@PL_VALUES);
	    }

	 if ($status eq '�H') 
	    {
	    
	    local($mapx,$mapy,$PlaceAttr,$status,$CharacterName,$Words1,$Words2,$Words3) = split(/,/,$userdata_line);
       	    
       	    
       	    
	    $Words="�L�{�b���Q����..";
	    $GetRndNumber=int rand(5);
	    if ($GetRndNumber eq 1) {$Words=$Words1;}
	    if ($GetRndNumber eq 2) {$Words=$Words2;}
	    if ($GetRndNumber eq 3) {$Words=$Words3;}
	    
	    
	    $OutputMessage.="$GetUserName �b$PlaceAttr �J��$CharacterName $Words";
	    }
        
	 if ($status eq '�L') 
	    {
	    local($mapx,$mapy,$PlaceAttr,$status) = split(/,/,$userdata_line);
             	    
	    }


}	


sub mychomp
{
($str1)=@_;
my $ca1=chr(10),$ca2=chr(13);
$str1=~ s/$ca1//g;
$str1=~ s/$ca2//g;
return $str1;
}