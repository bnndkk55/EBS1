#!/usr/bin/perl
#���L���a�I���ӱN��Ʈ���
require "ebs_sub1.cgi";
require "debug_sub.pl";
print "Content-type: text/html;\n\n";

pre_get_value();
$UserName=$parm1;
$Password=$parm2;

if ($parm3 eq "dellongid")
{

dbmopen (%P,"$DBM_P",0666);

while ( my ($Key,$Value) = each %P)
{
if (length($Key) > 40) {delete $P{"$Key"}};
}


dbmclose %P;
exit;
}




sub pre_get_value
{
# ���Φr��Χ�r��ѽX�^��Ӫ��r��
if ($ENV{'REQUEST_METHOD'} eq 'POST')
{
    read(STDIN, $temp, $ENV{'CONTENT_LENGTH'});
}
else
{
    $temp=$ENV{'QUERY_STRING'};
}

@key_value=split(/&/,$temp);

foreach $item(@key_value) 
{
    ($key,$value)=split (/=/,$item,2);
    $value=~tr/+/ /;
    $value=~ s/%(..)/pack("c",hex($1))/ge;
    $FORM{$key}=$value;
}

$buff = "$ENV{'QUERY_STRING'}";
$buff =~ s/\+/ /g;

($parm1,$parm2,$parm3,$parm4,$parm5)=split(/ /,$buff);
}
