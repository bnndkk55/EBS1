#!/usr/bin/perl
require 'config.cgi';
require "debug_sub.pl";
require 'ebs_sub1.cgi';
require "$LOG_FOLDER/$HASH_DATA";

#print "Content-type: text/html;charset=big5\n\n";

&pre_get_value;

$UserName=$FORM{'UserName'};
$Password=$FORM{'Password'};
$Restore=$FORM{'Restore'};

if ($FORM{'info'} ne ""){&C_LIST2;}	
if ($FORM{'CNTRY'} ne ""){&CNTRY_LIST;}
if ($FORM{'mycountry'} ne ""){&MY_LIST2;}	


sub MY_LIST2{

	&HEADER;
	&DBM_INPORT(P);
	@PL_VALUES = split(/\s/,$P{"$FORM{'pname'}"});
	&DBM_CONVERT('C',"$PL_VALUES[5]");

	sub TR {$VALUES[7]='No-Comment'if !$VALUES[7];"<tr><td nowrap style=\"color:$VALUES[13];\">$Key</td><td>".&RANK($VALUES[0],$VALUES[5],$VALUES[6])."</td><td><img src=$IMG_FOLDER2/$VALUES[27].gif width=32 height=32></td><td style=\"color:$VALUES[13];\">$VALUES[7]</td></tr>"}

	print "<table $center border=8 cellspacing=0 style=\"font-size:15px;border:8px outset $CL_VALUES[0];\">";
	print "<tr><td colspan=4 bgcolor=$CL_VALUES[0] style=\"color:red;font-size:20px;\">$PL_VALUES[5]";
	print "<span style=\"font-size:15px;\">&nbsp;&nbsp;��O&nbsp;<b>\$$CL_VALUES[1]</b></span>"if $PL_VALUES[5];
	print "</td></tr>";
	foreach $Key (sort {$P{$b} <=> $P{$a}} keys %P){
		@VALUES = split(/\s/,$P{$Key});
		if (!$PL_VALUES[5] && !$VALUES[5]){print &TR;}
		if ($PL_VALUES[5] && $PL_VALUES[5] eq $VALUES[5] && !$VALUES[28] && ($VALUES[6] == 1 || $VALUES[6] == 0)){print &TR;}
		if ($PL_VALUES[5] && $PL_VALUES[5] eq $VALUES[5] && $VALUES[28]){
			($UNIT_A.= &TR,$uflag_A=1) if $VALUES[28] eq $CL_VALUES[2] && $VALUES[6] != -1;
			($UNIT_B.= &TR,$uflag_B=1) if $VALUES[28] eq $CL_VALUES[3] && $VALUES[6] != -1;
			($UNIT_C.= &TR,$uflag_C=1) if $VALUES[28] eq $CL_VALUES[4] && $VALUES[6] != -1;
			($LEADER_A.= &TR,$lflag_A=1) if $VALUES[28] eq $CL_VALUES[2] && $VALUES[6] == -1;
			($LEADER_B.= &TR,$lflag_B=1) if $VALUES[28] eq $CL_VALUES[3] && $VALUES[6] == -1;
			($LEADER_C.= &TR,$lflag_C=1) if $VALUES[28] eq $CL_VALUES[4] && $VALUES[6] == -1;
		}

		$plys++;
	}
	if ($PL_VALUES[5]){
	print "<tr><td colspan=4 bgcolor=$CL_VALUES[0] style=\"color:#000000;font-size:20px;\">&nbsp;<b>�Ĥ@����</b>&nbsp;";
	print $CL_VALUES[2] ? "$CL_VALUES[2]":!$CL_VALUES[2] ? '���s�s':'</td></tr>';
	print $lflag_A ? "$LEADER_A":!$lflag_A ? "<tr><td colspan=4>�ȵL����</td></tr>":'\n';
	print $uflag_A ? "$UNIT_A":!$uflag_A ? "<tr><td colspan=4>�ȵL����</td></tr>":'';
	print "<tr><td colspan=4 bgcolor=$CL_VALUES[0] style=\"color:#000000;font-size:20px;\">&nbsp;<b>�ĤG����</b>&nbsp;";
	print $CL_VALUES[3] ? "$CL_VALUES[3]":!$CL_VALUES[3] ? '���s�s':'</td></tr>';
	print $lflag_B ? "$LEADER_B":!$lflag_B ? "<tr><td colspan=4>�ȵL����</td></tr>":'\n';
	print $uflag_B ? "$UNIT_B":!$uflag_B ? "<tr><td colspan=4>�ȵL����</td></tr>":'';
	print "<tr><td colspan=4 bgcolor=$CL_VALUES[0] style=\"color:#000000;font-size:20px;\">&nbsp;<b>�ĤT����</b>&nbsp;";
	print $CL_VALUES[4] ? "$CL_VALUES[4]":!$CL_VALUES[4] ? '���s�s':'</td></tr>';
	print $lflag_C ? "$LEADER_C":!$lflag_C ? "<tr><td colspan=4>�ȵL����</td></tr>":'\n';
	print $uflag_C ? "$UNIT_C":!$uflag_C ? "<tr><td colspan=4>�ȵL����</td></tr>":'';
	}
	print "</table><br><br><br><br>";

#	&FOOTER;

}
sub C_LIST2{
	&DBM_INPORT(C);
	&HEADER;
	print << "	-----END-----";
	<form action="countrylist.pl" method=POST target=Sub onSubmit="">
	<center>
	<input type=hidden name="pname" value="$FORM{'pname'}">
	<b>$FORM{'pname'} �п�@�Ӱ�a�Ӭd�ݱ��� </b><br>
	-----END-----
	while (($C_Name,$C_Value) =each %C) {
		@C_VALUE = split(/\s/,$C_Value);
			print "<input type=submit name=CNTRY value=\"$C_Name\"";
			print " STYLE=\" background:$C_VALUE[0];color:black\">\n";
	}
		print "<input type=submit name=CNTRY value=\"�ۥѾԤh\"";
		print " STYLE=\" background:#808080;color:white\"></center></form>\n";
}


sub CNTRY_LIST{

	$CO_NAME=$FORM{'CNTRY'};
	($FORM{'CNTRY'}='',$CL_VALUES[0]='#000000') if $FORM{'CNTRY'} eq '�ۥѾԤh';
	&HEADER;
	&LOCK;&DBM_INPORT(P);&DBM_INPORT(C);&UNLOCK;
	@PL_VALUES = split(/\s/,$P{"$FORM{'pname'}"});
	@CL_VALUES = split(/\s/,$C{"$FORM{'CNTRY'}"});
	#require "$LOG_FOLDER/_hash.data" if $FORM{'CNTRY'} eq "$PL_VALUES[5]";

	sub TR {local($WN_A,$WLV_A) = split(/!/,$VALUES[9]);$WLV_A=int($WLV_A/$WEAPON_LVUP);
			if ($FORM{'CNTRY'} eq "$PL_VALUES[5]"){
				$VSSayWords='';
				$AddInfo='';
				@WN_sA=split(/\,/,$WEAPON_LIST{"$WN_A"});
				if ($VALUES[31] ne ""){	$VSSayWords="<br>��:$VALUES[31]";}
				
				$AddInfo="<br>HP:$VALUES[15]/$VALUES[16]<br>EN:$VALUES[17]/$VALUES[18]<br>¾�~:@PlayerJob[$VALUES[82]]<br>����:$VALUES[3]";
				
			}else{$WN_sA[0]='????????';$VSSayWords="";$AddInfo="";}
		"<tr><td nowrap>$Key</td><td>LV:$VALUES[29]<br>".&RANK($VALUES[0],$VALUES[5],$VALUES[6])."</td><td><img src=$IMG_FOLDER3/$VALUES[100].gif ><img src=$IMG_FOLDER2/$VALUES[27].gif width=32 height=32></td><td align=center>".&STATUS_CONVERT("$VALUES[19]",'s')."</td><td align=center>".&STATUS_CONVERT("$VALUES[20]",'s')."</td><td align=center>".&STATUS_CONVERT("$VALUES[21]",'s')."</td><td align=center>".&STATUS_CONVERT("$VALUES[22]",'s')."</td><td align=center>".&STATUS_CONVERT("$VALUES[24]",'j')."</td><td><b>".$WN_sA[0]."(LV$WLV_A)</b>$AddInfo$VSSayWords</td><td align=center>".(&LOGIN_CHECK($Key) ? "���ɤ�":"<font color=red>��Ԥ�</font>")."</td></tr>"}

	print << "	-----END-----";
	<form action="countrylist.pl" method=POST target=Sub onSubmit="">
	<center><input type=hidden name="cmd" value="CO_LIST">
	<input type=hidden name="pname" value="$FORM{'pname'}">
        $FORM{'pname'} �� $PL_VALUES[5] �d�� $FORM{'CNTRY'}<br>
	<b style=\"font-size:13px;\">�Q�d�ݭ��Ӱ�a�������H</b><br>
	-----END-----
	while (($C_Name,$C_Value) =each %C) {
		@C_VALUE = split(/\s/,$C_Value);
			print "<input type=submit name=CNTRY value=\"$C_Name\"";
			print " STYLE=\" background:$C_VALUE[0];color:black\">\n";
	}
		print "<input type=submit name=CNTRY value=\"�ۥѾԤh\"";
		print " STYLE=\" background:#808080;color:white\"></center></form>\n";

	print "<table $center border=8 cellspacing=0 style=\"font-size:15px;border:8px outset $CL_VALUES[0];\">";
	print "<tr><td colspan=9 bgcolor=$CL_VALUES[0] style=\"font-size:35px;\">$CO_NAME";
	print "&nbsp;&nbsp;&nbsp;�� �O&nbsp;<b>\$$CL_VALUES[1]</b></td></tr>";
	print "<tr><td>�Τ�W</td><td>����</td><td>&nbsp;</td><td>AT</td><td>GD</td><td>SP</td><td>HIT</td><td>��</td><td>�Z���˳�</td></tr>";
	foreach $Key (sort {$P{$b} <=> $P{$a}} keys %P){
		@VALUES = split(/\s/,$P{$Key});
		if ($FORM{'CNTRY'} eq "$VALUES[5]" && !$VALUES[28] && ($VALUES[6] == 1 || $VALUES[6] == 0)){print &TR;}

		if ($FORM{'CNTRY'} && $FORM{'CNTRY'} eq "$VALUES[5]" && $VALUES[28]){
			($UNIT_A.= &TR,$uflag_A=1) if $VALUES[28] eq $CL_VALUES[2] && $VALUES[6] != -1;
			($UNIT_B.= &TR,$uflag_B=1) if $VALUES[28] eq $CL_VALUES[3] && $VALUES[6] != -1;
			($UNIT_C.= &TR,$uflag_C=1) if $VALUES[28] eq $CL_VALUES[4] && $VALUES[6] != -1;
			($LEADER_A.= &TR,$lflag_A=1) if $VALUES[28] eq $CL_VALUES[2] && $VALUES[6] == -1;
			($LEADER_B.= &TR,$lflag_B=1) if $VALUES[28] eq $CL_VALUES[3] && $VALUES[6] == -1;
			($LEADER_C.= &TR,$lflag_C=1) if $VALUES[28] eq $CL_VALUES[4] && $VALUES[6] == -1;
		}
		$plys++;
	}

	if ($FORM{'CNTRY'}){
	print "<tr><td colspan=9 bgcolor=$CL_VALUES[0] style=\"color:#000000;font-size:25px;\">&nbsp;<b>�Ĥ@����</b>&nbsp;";
	print $CL_VALUES[2] ? "$CL_VALUES[2]":!$CL_VALUES[2] ? '���s�s':'</td></tr>';
	print $lflag_A ? "$LEADER_A":!$lflag_A ? "<tr><td colspan=9>�ȵL����</td></tr>":'\n';
	print $uflag_A ? "$UNIT_A":!$uflag_A ? "<tr><td colspan=9>�ȵL����</td></tr>":'';
	print "<tr><td colspan=9 bgcolor=$CL_VALUES[0] style=\"color:#000000;font-size:25px;\">&nbsp;<b>�ĤG����</b>&nbsp;";
	print $CL_VALUES[3] ? "$CL_VALUES[3]":!$CL_VALUES[3] ? '���s�s':'</td></tr>';
	print $lflag_B ? "$LEADER_B":!$lflag_B ? "<tr><td colspan=9>�ȵL����</td></tr>":'\n';
	print $uflag_B ? "$UNIT_B":!$uflag_B ? "<tr><td colspan=9>�ȵL����</td></tr>":'';
	print "<tr><td colspan=9 bgcolor=$CL_VALUES[0] style=\"color:#000000;font-size:25px;\">&nbsp;<b>�ĤT����</b>&nbsp;";
	print $CL_VALUES[4] ? "$CL_VALUES[4]":!$CL_VALUES[4] ? '���s�s':'</td></tr>';
	print $lflag_C ? "$LEADER_C":!$lflag_C ? "<tr><td colspan=9>�ȵL����</td></tr>":'\n';
	print $uflag_C ? "$UNIT_C":!$uflag_C ? "<tr><td colspan=9>�ȵL����</td></tr>":'';
	}

	print "</table><br><br><br><br>";

	&FOOTER;
	exit;
}




sub pre_get_value
{
# ���Φr��Χ�r��ѽX�^��Ӫ��r��
if ($ENV{'REQUEST_METHOD'} eq 'POST')
{
    read(STDIN, $temp, $ENV{'CONTENT_LENGTH'});
}
else
{
    $temp=$ENV{'QUERY_STRING'};
}

@key_value=split(/&/,$temp);

foreach $item(@key_value) 
{
    ($key,$value)=split (/=/,$item,2);
    $value=~tr/+/ /;
    $value=~ s/%(..)/pack("c",hex($1))/ge;
    $FORM{$key}=$value;
}

$buff = "$ENV{'QUERY_STRING'}";
$buff =~ s/\+/ /g;

($parm1,$parm2,$parm3)=split(/ /,$buff);
}