#!/usr/bin/perl
#EBS EX �j�ƭܮw DEBUG ��@..�ۧ@�v,���v�Ҧ�
require 'config.cgi';
require "debug_sub.pl";
require 'ebs_sub1.cgi';
require "$LOG_FOLDER/$HASH_DATA";

print "Content-type: text/html;charset=big5\n\n";
&checkserver;
&pre_get_value;
$UserName=$FORM{'UserName'};
$Password=$FORM{'Password'};
$Restore=$FORM{'Restore'};

if (rindex($UserName,'-�X-') ne -1 ){print"NO..NO...Monster can't use this!";exit;}

if ($UserName ne "")
{
CheckStorageTime($UserName);
}

$RefreashYardSellScreen=$FORM{'RefreashYardSellScreen'};


$RecordDay=((localtime)[3]);
$RealStorageFile="$StorageDir/$UserName.dat";
$MaxStorageSpaceNumber=35;
$IncreaseStorageSpaceFee=10000000;
$UpgradeItemFee=20000;
$MaxItemPriceDouble=10;
$MaxItemYardSellDays=10;
$UpgradeItemPoint=$WEAPON_LVUP*$WEAPON_RANKUP;
$SplitSign='#od_#';
$BuyItNowTag="UseBuyItNow";
$YardSellFile="$LOG_FOLDER/yardsell";

$currenttime=localtime(time);

if ($parm1 eq "")
{
print << "----HTMLTAG---";
<body bgcolor="#000000">
<LINK href=ltb.css type=text/css rel=stylesheet>
<table width=100% height=100%><tr><td align=center>
<table border=0 cellpadding=0 cellspacing=0 bgcolor="#909090" align=center style="border:1px outset #909090;font-size:16px;">
<form method="POST" action="itemmanager.pl?enter">
<tr><td style="background-color:#404040;" colspan=2>�ܮw</td></tr>
<tr><td align=center><b style="color:#000000;">�b��<input type="text" name="UserName" size="20"></b></td><td><input type=hidden name="plname" style="height:21px; color:#ffffff; font-size:16px; background:#000000; border:1 inset #c0c0c0;">
<tr><td align=center><b style="color:#000000;">  �K�X<input type="password" name="Password" size="20"><br>
 <input type="submit" value="����" name="B1"><input type="reset" value="���s�]�w" name="B2"></p>
</form>
----HTMLTAG---

print '<font size="2">�����H�j�� ONLINE �M�� �˳ƺ޲z��. <br>�ФűN�ۦP�W�P���ŦP�g��Ȫ��˳Ʃ��ܮw..�_�h�|�ް_�s���z������<br><A href="http://www.7era.com/ebsxp/">DEBUG</A> �s�@..�ۧ@�v,���v�Ҧ�(���{��������DEBUG�}�o�P��Ӫ��ܮw�{�������L��)</font><br>';
exit;
}
if (($Password eq "") || ($UserName eq "")) {exit;}

CheckSameAndSpaceWeapon($UserName);


if ($parm1 eq "enter")
{
if (@PL_VALUES[5] eq $WaitDiePlace){print "�A�ثe�b $WaitDiePlace ";exit;}
ShowAllweaponData();
}

if ($parm1 eq "restorweapon")
{
$WeaponChoose=$FORM{'WeaponChoose'};
$RestorWeaponChoose=$WeaponChoose-1;
$IncreaseStorageSpace=$FORM{'IncreaseStorageSpace'};

if ($IncreaseStorageSpace ne "")
{
print "�W�[�ܮw�Ŷ���...";
@Nothing=read_file($RealStorageFile);
$StorageSpaceNumber=@Nothing;
if ($StorageSpaceNumber < $MaxStorageSpaceNumber)
{

&LOCK;
dbmopen (%P,"$DBM_P",0666);
@PL_VALUES = split(/\s/,$P{"$UserName"});
$CurrentMoney=@PL_VALUES[8];
$CurrentMoney-=$IncreaseStorageSpaceFee;
if ($CurrentMoney > 0)
{
@PL_VALUES[8]=$CurrentMoney;
@Nothing[$StorageSpaceNumber+1]="0\n";
write_file($RealStorageFile,@Nothing);
print "��h��� $IncreaseStorageSpaceFee";
}
else
{
print "������� $IncreaseStorageSpaceFee";
}	

$P{"$UserName"}="@PL_VALUES";

dbmclose %P;

&UNLOCK;

print "����...";
}
else
{
print "����...��]:�o�w�g�O�̤j�Ŷ��F";
}	

ShowAllweaponData();
}	



$RestoreWeaponID=GetStorageID($RestorWeaponChoose);

#print '='.length(@SortArray[$Restori]).'=';
if (length($RestoreWeaponID) < 3)
{
print "�D�k�Z��ID!!"; 
ShowAllweaponData();
}	

&LOCK;
dbmopen (%P,"$DBM_P",0666);
@PL_VALUES = split(/\s/,$P{"$UserName"});
dbmclose %P;
&UNLOCK;


@SortArray=(@PL_VALUES[10],@PL_VALUES[11],@PL_VALUES[98],@PL_VALUES[99]);
$IsRestore=0;
$Restori=0;
foreach (@SortArray)
{
 if ((length(@SortArray[$Restori]) <3 ) && ($IsRestore eq 0))
    {
    @SortArray[$Restori]=$RestoreWeaponID;
    $IsRestore=1;
    }	
 $Restori++;
}	


@PL_VALUES[10]=@SortArray[0];
@PL_VALUES[11]=@SortArray[1];
@PL_VALUES[98]=@SortArray[2];
@PL_VALUES[99]=@SortArray[3];


#$Complex

&LOCK;
dbmopen (%P,"$DBM_P",0666);
$P{"$UserName"}="@PL_VALUES";
dbmclose %P;
&UNLOCK;


if ($Restore ne "")
{
 CallStorageFunction("restore",$UserName,"",$RestorWeaponChoose);
}	



ShowAllweaponData();
}




if ($parm1 eq "putweapon")
{
GetWeaponInfo();
$WeaponChoose=$FORM{'WeaponChoose'};
$PutToStorage=$FORM{'PutToStorage'};
$SellWeapon=$FORM{'SellWeapon'};
$Complex=$FORM{'Complex'};
$AskPrice=$FORM{'AskPrice'};
$Upgrade=$FORM{'Upgrade'};
$UseItem=$FORM{'UseItem'};


if ($PutToStorage ne "")
   {
    PutItemToStorage($WeaponChoose);
    print "�w�N�Z�� $WeaponChoose ��m�i�ܮw!";
   }

if ($SellWeapon ne "")
   {
    SellItemWeapon();
    print "�w�N�Z�� $WeaponChoose �X�⵹���ʰӤH!";

   }

if ($AskPrice ne "")
   {
    $WeaponLocation=ItemChooseIndex($WeaponChoose);
    ($ItemID,$ItemPoint)= split(/!/,$PL_VALUES[$WeaponLocation]);
    $AskSellPrice=AskItemPrice($ItemID,$ItemPoint,"sell");
    $AskBuePrice=AskItemPrice($ItemID,$ItemPoint,"buy");
    print "�����~����:��X��:$AskSellPrice �R�J��:$AskBuePrice ";
   }

if ($Complex ne "")
   {
    $CheckComplexItem="";
    print "�X���}�l!";
    $CheckComplexItem=ComplexItem();
    
    if ($CheckComplexItem ne "" ) 
       {
       	PutOneItemToStorage("$CheckComplexItem!0",$UserName);
       	TakeitemAway("all",-1);
       }
    
   }

#print "($FORM{'BuyItemChoose'})";
if ($FORM{'BuyItemChoose'} ne "")
{
 BuyItem("Buy");
}

if ($Upgrade ne "")
   {
    ($ItemID,$ItemPoint)= split(/!/,@PL_VALUES[9]);
    $ChooseIndex=$FORM{'ItemChoose'};
    $ItemUpgradeForm=ItemUpgrade("upgrade",$ItemID,$ChooseIndex,$UserName,$Password);   
   }   	

if ($UseItem ne "")
   {
    if ($WeaponChoose > 0)
    {
    $WeaponLocation=ItemChooseIndex($WeaponChoose);
    $CurrentHandItem=@PL_VALUES[9];
    $WantChangeItem=@PL_VALUES[$WeaponLocation];	
    if ($WantChangeItem eq ''){print "���i�˳ƪŮ�";exit;}
    @PL_VALUES[9]=$WantChangeItem;
    @PL_VALUES[$WeaponLocation]=$CurrentHandItem;
    ChangeUserData($UserName,@PL_VALUES);
    }
   }   	




if ($WeaponNamePutToStorage ne "")
{
dbmopen(%FILEID,"$EventRecordDir/storetrack$RecordDay",0766);
$WeaponNamePutToStorage=GetItemName($WeaponNamePutToStorage);
my ($ID,$Point,$Type)=split(/!/,$WeaponNamePutToStorage);
$FILEID{$UserName}="$FILEID{$UserName} $WeaponNamePutToStorage ($Point) #I��J $currenttime #o#";
#print $FILEID{$UserName};
dbmclose(%FILEID);
}
ShowAllweaponData();

}	


	


sub GetWeaponInfo()
{
&DBM_INPORT(P);
while (($Key,$Value) = each %P)
        {
if ($UserName eq $Key)
{
@PL_VALUES = split(/\s/,$Value);
#print "$Key �i�J...";
CheckPassword($Password,$PL_VALUES[2]);
#print "PASSWORD allow!";
$FinalFightTime=@PL_VALUES[26];
$Counter++;
$FinalFightTime=(time)-$FinalFightTime;
$FinalFightTime=int($FinalFightTime/(24*60*60));
$Weapon1=@PL_VALUES[10];
$Weapon2=@PL_VALUES[11];
$Weapon3=@PL_VALUES[98];
$Weapon4=@PL_VALUES[99];

$WeaponName1=GetItemName($Weapon1);
$WeaponName2=GetItemName($Weapon2);
$WeaponName3=GetItemName($Weapon3);
$WeaponName4=GetItemName($Weapon4);
}
}

}	



sub pre_get_value
{
# ���Φr��Χ�r��ѽX�^��Ӫ��r��
if ($ENV{'REQUEST_METHOD'} eq 'POST')
{
    read(STDIN, $temp, $ENV{'CONTENT_LENGTH'});
}
else
{
    $temp=$ENV{'QUERY_STRING'};
}

@key_value=split(/&/,$temp);

foreach $item(@key_value) 
{
    ($key,$value)=split (/=/,$item,2);
    $value=~tr/+/ /;
    $value=~ s/%(..)/pack("c",hex($1))/ge;
    $FORM{$key}=$value;
}

$buff = "$ENV{'QUERY_STRING'}";
$buff =~ s/\+/ /g;

($parm1,$parm2,$parm3)=split(/ /,$buff);
}


sub ShowAllweaponData
{
if (-e $RealStorageFile)
{

}
else
{
@Nothing="0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n";
print "�إ߭ܮw��...";
write_file($RealStorageFile,@Nothing);
print "�إߧ���...";
}	

GetWeaponInfo();
@GetOneWeponData=read_file($RealStorageFile);



$UBField="
    <option value=\"1\">�w�ƪZ���@ ($WeaponName1)</option>
    <option value=\"2\">�w�ƪZ���G ($WeaponName2)</option>
    <option value=\"3\">�w�ƪZ���T ($WeaponName3)</option>
    <option value=\"4\">�w�ƪZ���| ($WeaponName4)</option>
";

$UBForm="
<form method=\"POST\" action=\"itemmanager.pl?putweapon\" name=\"ItemForm\">
  <input type=\"hidden\" name=\"UserName\" value=\"$UserName\">  <input type=\"hidden\" name=\"Password\" value=\"$Password\">
    <select size=\"4\" name=\"WeaponChoose\">
  $UBField
  </select>
  <br><input type=\"submit\" value=\"���ܮw\" name=\"PutToStorage\">
  <input type=\"submit\" value=\"���~�߰�\" name=\"SellWeapon\" onClick=\"if (confirm('���~�߰�A�T�w�ܡH') == true){}else{this.disabled=true;} \" >
  <input type=\"submit\" value=\"���~�߻�\" name=\"AskPrice\">
  <input type=\"submit\" value=\"���~�X��\" name=\"Complex\">
  <input type=\"submit\" value=\"�˳ƪ��~\" name=\"UseItem\">

</form>
";






$ReListi=1;
foreach $Value(@GetOneWeponData)
{
$WeaponName=GetItemName($Value);
$RestoreField.="<option value=\"$ReListi\">$WeaponName</option>";
$ReListi++;
}




$RestoreForm="
<form method=\"POST\" action=\"itemmanager.pl?restorweapon\">
  <input type=\"hidden\" name=\"UserName\" value=\"$UserName\"> <input type=\"hidden\" name=\"Password\" value=\"$Password\">
  <select size=\"8\" name=\"WeaponChoose\">
  $RestoreField
  </select>
  <br>
  <input type=\"submit\" value=\"�ѭܮw���^\" name=\"Restore\">
  <input type=\"submit\" value=\"�t�W�[�Ŷ�\" name=\"IncreaseStorageSpace\">
  <hr>
</form>
";


$RefreshScreenForm="
<form method=\"POST\" action=\"itemmanager.pl?enter\">
  <input type=\"hidden\" name=\"UserName\" value=\"$UserName\"> <input type=\"hidden\" name=\"Password\" value=\"$Password\">
  <input type=\"submit\" value=\"�e����s\" name=\"RefreshScreen\">
</form>
";


my ($ItemID,$ItemPoint,$ItemType)= split(/!/,@PL_VALUES[9]);
ItemShowPreProcess($ItemID);
$CurrentHandItemName=GetItemName(@PL_VALUES[9]);
$ItemUpgradeForm=ItemUpgrade("show",$ItemID,$ChooseIndex,$UserName,$Password);
$BuyItemForm=BuyItem("show");
print << "-----HTMLTAG----";
<head>
<title></title>
</head>
<body bgcolor="#FDFFF0" background="" text="#C0C0C0">
<div align="center">
  <p>
  <center>
  </p>
<table border="0" width="935" height="555" cellspacing="0" cellpadding="0" background="$ExternalImage/storage2.jpg">
  <tr>
    <td width="238" valign="top" height="121" colspan="2">
    <font color="#000000">
      ID:$UserName �ثe���:@PL_VALUES[8]<br>       
      �ثe��W�˳�:$CurrentHandItemName �I��:$ItemPoint       
      <br>�˳Ƨ�y�O��:$UpgradeItemFee �I��:$UpgradeItemPoint  
      <p align="center">�ƥ���<br> 
      $UBForm</p>
      <p align="center">$ComplexForm</p>
      </font>
      <font color="#00FFFF">
      &nbsp;
    </font>
    </td>
    <td width="317" valign="top" height="193" rowspan="2">
    <font color="#000000">
      <p align="center">�ܮw <br>(�Ŷ��W�[�O $IncreaseStorageSpaceFee)<br>    
      </font>  
      </p> 
      <table border="0" width="83%" height="413">
        <tr>
          <td width="100%" height="123"></td>
        </tr>
        <tr>
          <td width="100%" height="278">$RestoreForm</td>
        </tr>
      </table>
    </td> 
  </tr> 
  <tr> 
    <td width="139" valign="top" height="78" > 
      <font color="#00FFFF">$ItemUpgradeForm
    </font>
    </td>
    <td width="100" valign="top" height="78" >
      <font color="#00FFFF">$BuyItemForm
    </font>
    </td>
  </tr>
</table>
$RefreshScreenForm
</center>
</div>
�@
<p>�@</p>
<p>
<font size="2">�����H�j�� ONLINE �M�� �˳ƺ޲z��. <br><A href="http://www.markhome.com/freeweb/debug" target="_blank">DEBUG</A> �s�@..�ۧ@�v,���v�Ҧ�(���{��������DEBUG�}�o�P��Ӫ��ܮw�{�������L��)</font></p>  
</body>  

-----HTMLTAG----
#===========
#print $UBForm;
#print $RestoreForm;
#===========

exit;

}	


sub GetItemName
{
my $ItemID,$ItemPoint,@CurrentHandItem;
($GetOneItemData)=@_;
($ItemID,$ItemPoint)= split(/!/,$GetOneItemData);
@ItemName=split(/\,/,$WEAPON_LIST{"$ItemID"});
return @ItemName[0];
}


sub CallStorageFunction
{
my $Mode,$UserName,$ItemID,$ItemSelectLocation,@GetStorageItemData;
($Mode,$UserName,$ItemID,$ItemSelectLocation)=@_;
@GetStorageItemData=read_file($RealStorageFile);
if ($Mode eq "restore")
	{

	if ($IsRestore eq 0)
		{
		print "�ƥ����w��!�L�k��m�F��<br>";
		}	
		else
			{
			@GetStorageItemData[$RestorWeaponChoose]="0\n";
			$currenttime=localtime(time);

			if ($RestoreWeaponID ne "")
				{
				dbmopen(%FILEID,"$EventRecordDir/storetrack$RecordDay",0766);
				$WeaponNameGetFromStorage=GetItemName($RestoreWeaponID);
				$FILEID{$UserName}="$FILEID{$UserName} $WeaponNameGetFromStorage  #I���X $currenttime #o#";
				dbmclose(%FILEID);
				}

			write_file($RealStorageFile,@GetStorageItemData);
			}	
	}	
}



#======= PUT WEAPON to restorage ====

sub PutItemToStorage
{
my $GetOneItemID,$ItemChoose,$WeaponLocation;
($ItemNumberChoose)=@_;
$WeaponLocation=ItemChooseIndex($ItemNumberChoose);
$GetOneItemID=@PL_VALUES[$WeaponLocation];
$IsFull=PutOneItemToStorage($GetOneItemID,$UserName);
if ( $IsFull eq 1)
{
print "<br>�ܮw�w��!�L�k��m�F��";
}
else
{
$WeaponLocation=ItemChooseIndex($ItemNumberChoose);
TakeitemAway("one",$WeaponLocation);
}
}	

#===== Put One Item To Storage===========
sub PutOneItemToStorage
{
my $IsFull,$GetOneItemID,$List_i,$IsPut,$UserName,$PersonalStorageFile;
($GetOneItemID,$UserName)=@_;
$PersonalStorageFile="$StorageDir/$UserName.dat";
@GetOneWeponData=read_file($PersonalStorageFile);
$List_i=0;
$IsPut=0;
$IsFull=1;
foreach (@GetOneWeponData)
{
	if (length(@GetOneWeponData[$List_i]) < 3)
	{
		if (($GetOneItemID ne "") && ($IsPut eq 0))
		{
 		@GetOneWeponData[$List_i]="$GetOneItemID"."\n";
 		$IsFull=0;
 		$IsPut=1;
		}     
	}
$List_i++;
} 
if ( $IsFull eq 0)
{
 write_file($PersonalStorageFile,@GetOneWeponData);
}
return $IsFull;
}



sub ChangeUserData
{
my $UserName,$ChangeIndex,$GetChangeData,@ChangeData,@UserDataValues;
($UserName,@ChangeData)=@_;
&LOCK;
dbmopen (%WP,"$DBM_P",0666);
$WP{"$UserName"}="@ChangeData";
dbmclose %WP;
&UNLOCK;
}

#===== take Out Item From ItemList=======
sub TakeitemAway
{
my $Mode,$WeaponLocation;

($Mode,$WeaponLocation)=@_;



&LOCK;
dbmopen (%P,"$DBM_P",0666);
@PL_VALUES = split(/\s/,$P{"$UserName"});
 
if ($Mode eq "all")
  {
   @SortArray=('','','','');
  }  	

if ($Mode eq "one")
  {
  $WeaponNamePutToStorage=@PL_VALUES[$WeaponLocation];
  @PL_VALUES[$WeaponLocation]='';
  @SortArray=(@PL_VALUES[10],@PL_VALUES[11],@PL_VALUES[98],@PL_VALUES[99]);


for ($i=0;$i<@SortArray;$i++)
    {
	for ($j=$i;$j<@SortArray;$j++)
	{
	if (length (@SortArray[$i])< length (@SortArray[$j]))
	   {
		$WValue=@SortArray[$i];
		@SortArray[$i]=@SortArray[$j];
		@SortArray[$j]=$WValue;
	   }
	}    
    
    }

  }

@PL_VALUES[10]=@SortArray[0];
@PL_VALUES[11]=@SortArray[1];
@PL_VALUES[98]=@SortArray[2];
@PL_VALUES[99]=@SortArray[3];
$P{"$UserName"}="@PL_VALUES";
dbmclose %P;
&UNLOCK;

}	







#======= Sell Item ====

sub SellItemWeapon
{

$WeaponLocation=ItemChooseIndex($WeaponChoose);


($ItemID,$ItemPoint)= split(/!/,$PL_VALUES[$WeaponLocation]);
$SellPrice=AskItemPrice($ItemID,$ItemPoint,"sell");
$SellWeaponName=GetItemName($PL_VALUES[$WeaponLocation]);
&record_fight(""," ","$UserName $SellWeaponName   $ItemPoint�I �Z���X��,�ثe��$PL_VALUES[8]G");


&LOCK;
	dbmopen (%P,"$DBM_P",0666);
		 @PL_VALUES = split(/\s/,$P{"$UserName"});
                 $WeaponNamePutToStorage=@PL_VALUES[$WeaponLocation];
                 @PL_VALUES[$WeaponLocation]='';
                 $PL_VALUES[8]+=$SellPrice;

@SortArray=(@PL_VALUES[10],@PL_VALUES[11],@PL_VALUES[98],@PL_VALUES[99]);

for ($i=0;$i<@SortArray;$i++)
    {
	for ($j=$i;$j<@SortArray;$j++)
	{
	if (length (@SortArray[$i])< length (@SortArray[$j]))
	   {
		$WValue=@SortArray[$i];
		@SortArray[$i]=@SortArray[$j];
		@SortArray[$j]=$WValue;
	   }
	}    
    
    }

@PL_VALUES[10]=@SortArray[0];
@PL_VALUES[11]=@SortArray[1];
@PL_VALUES[98]=@SortArray[2];
@PL_VALUES[99]=@SortArray[3];
$P{"$UserName"}="@PL_VALUES";
dbmclose %P;
&UNLOCK;



}	

sub ItemChooseIndex
{
my $WeaponLocation,$WeaponChoose;
($WeaponChoose)=@_;
if ($WeaponChoose eq 1) 
{
 $WeaponLocation=10;
}

if ($WeaponChoose eq 2) 
{
 $WeaponLocation=11;
}
if ($WeaponChoose eq 3) 
{
 $WeaponLocation=98;
}
if ($WeaponChoose eq 4) 
{
 $WeaponLocation=99;
}
return $WeaponLocation;
}

sub AskItemPrice
{
my ($ItemData,$ItemPoint,$CommerceMode)=@_;
@ItemData=split(/\,/,$WEAPON_LIST{"$ItemID"});


if ($CommerceMode eq "sell")
   {
    return (int (($ItemData[5]/3)+$ItemPoint*10));
   }	

if ($CommerceMode eq "buy")
   {
    return (int $ItemData[5]);
   }	
}


sub ComplexItem
{
my $Value,$Value2,$Value3,$ComplexPass,$ComplexItemID,$ItemIDIndex,$NewComplexItemName,$ComplexProcessIndex,@NewItemData,@ReadComplexdata,@ItemIDBuffer;
($ItemID1,$ItemPoint1)= split(/!/,$PL_VALUES[10]);
($ItemID2,$ItemPoint2)= split(/!/,$PL_VALUES[11]);
($ItemID3,$ItemPoint3)= split(/!/,$PL_VALUES[98]);
($ItemID4,$ItemPoint4)= split(/!/,$PL_VALUES[99]);

$ItemIDIndex=0;
if ($ItemID1 ne "") {@ItemIDBuffer[$ItemIDIndex]=$ItemID1;$ItemIDIndex++;}
if ($ItemID2 ne "") {@ItemIDBuffer[$ItemIDIndex]=$ItemID2;$ItemIDIndex++;}
if ($ItemID3 ne "") {@ItemIDBuffer[$ItemIDIndex]=$ItemID3;$ItemIDIndex++;}
if ($ItemID4 ne "") {@ItemIDBuffer[$ItemIDIndex]=$ItemID4;$ItemIDIndex++;}

#print @ComplexWays;
foreach $Value(@ComplexWays)
       {
       if ($Value ne "")
          {
           ($ComplexItemID,@ReadComplexdata)=split(/\,/,$Value);
           $NeedPassNumber=@ReadComplexdata;
           $ComplexPass=0;
#print "($ComplexItemID,@ReadComplexdata)";
           $ComplexProcessIndex=0;
           $ComplexPass=0;
           foreach (@ItemIDBuffer)
                   {
             	     if (@ReadComplexdata[$ComplexProcessIndex] eq @ItemIDBuffer[$ComplexProcessIndex]) 
               	        {
               	       	 $ComplexPass++;
               	        }
               	    $ComplexProcessIndex++;
                   }

#print "--- I= $ItemIDIndex  C= $ComplexPass ---";
           if (($ComplexPass eq  $NeedPassNumber) && ($ComplexPass >1))
              {
#print "�X�� $ComplexItemID,";
               @NewItemData=split(/\,/,$WEAPON_LIST{"$ComplexItemID"});
               $NewComplexItemName=@NewItemData[0];
               print "�X�� �s�Z�� $NewComplexItemName !";
               &record_fight($UserName,"","$UserName �X�� �s�Z�� $NewComplexItemName !");
               return $ComplexItemID;
              }	
          }
       }	


}	


sub BuyItem
{
my ($Mode)=@_;
if ($Mode eq "show")
{
return "
<form method=\"POST\" action=\"itemmanager.pl?putweapon\">
  <input type=\"hidden\" name=\"UserName\" value=\"$UserName\">  
  <input type=\"hidden\" name=\"Password\" value=\"$Password\">
   <select size=\"4\" name=\"BuyItemChoose\" style=\"font-size:11\">
  $ItemBuyBag
  </select>
  <br><input type=\"submit\" value=\"�R�i�˳�\" name=\"BuyItem\">
</form>
";
}

if ($Mode eq "Buy")
{
$BuyItemID=$FORM{'BuyItemChoose'};
$BuyItemLen=length($BuyItemID);
$NeedPrice=GetItemInfo($BuyItemID,'price');

&LOCK;
dbmopen (%P,"$DBM_P",0666);
@PL_VALUES = split(/\s/,$P{"$UserName"});
$CurrentMoney=@PL_VALUES[8];
$CurrentMoney-=$NeedPrice;

if ($BuyItemLen > 1)
{
my $ItemName=GetItemInfo($BuyItemID,'name');

PublishMsg("$UserName���ϥΥ~���R�Z��..$ItemName");
exit;
}	


if ($CurrentMoney > 0) 
{
@PL_VALUES[8]=$CurrentMoney;
my $BuyInPoint=CheckItemVailbSpace();
if ($BuyInPoint>0)
{
@PL_VALUES[$BuyInPoint]="$BuyItemID!0!";
$P{"$UserName"}="@PL_VALUES";
print "��h��� $NeedPrice";
}
else
{
print "�L�Ŧ�i��!";
}	

}
else
{
print "������� $NeedPrice ";
}	
dbmclose %P;
&UNLOCK;
}	


}	



sub ItemShowPreProcess
{
my ($ItemID)=@_;
$ItemUpgradeIndex=0;
$ItemUpgradeBag="";
while (my ($key,$val) = each %WEAPON_LIST)
{
my $CurrentItemKey=substr($key,0,length($ItemID));
if (($CurrentItemKey eq $ItemID) && (length($key) == length($ItemID)+1) && ($CurrentItemKey ne ''))
{
$UpgradeItem=GetItemInfo($key,'name');
$ItemUpgradeBag.="<option value=\"$key\">$UpgradeItem</option>";
$ItemUpgradeIndex++;
}

my $BuyItemKey=substr($key,0,1);
my $ItemName=GetItemInfo($BuyItemKey,'name');
my $ItemPrice=GetItemInfo($BuyItemKey,'price');

if ((length($key) == 1) && ($PL_VALUES[8]>$ItemPrice))
{
$ItemBuyBag.="<option value=\"$BuyItemKey\">$ItemName ($ItemPrice)</option>";
}

}

}	


sub ItemUpgrade
{
my $OrginalItem,$ChooseIndex,$Mode,$UserName,$Password;
($Mode,$OrginalItem,$ChooseIndex,$UserName,$Password)=@_;

$ItemCheckMark=0;
$ItemUpgradeIndex=0;

if ($Mode eq "upgrade") 
{
$UpgradeItem=$FORM{'ItemUpgradeChoose'};
if ($UpgradeItem eq ""){print "�п�˳�";exit;}
my @ItemInfo=split(/!/,@PL_VALUES[9]);
$UpgradeItemLen=length(@ItemInfo[0]);

my $UpgradeKey1=substr($UpgradeItem,0,$UpgradeItemLen);


if ((@ItemInfo[0] ne $UpgradeKey1) || (length($UpgradeItem)>$UpgradeItemLen+1))
{
$WeaponName1=GetItemInfo(@ItemInfo[0],'name');
$WeaponName2=GetItemInfo($UpgradeItem,'name');
PublishMsg("$UserName���ϥΥ~���ɯŪZ��..$WeaponName1..�ɨ�$WeaponName2");
exit;
}



if ($UpgradeItem eq '')
  {
   print "�A�S���i��y���˳�";
  }
  else
  {  	
&LOCK;
dbmopen (%P,"$DBM_P",0666);
@PL_VALUES = split(/\s/,$P{"$UserName"});
$CurrentMoney=@PL_VALUES[8];
($CurrentHandItemID,$CurrentHandItemPoint)=split(/!/,@PL_VALUES[9]);
$CurrentMoney-=$UpgradeItemFee;
if (($CurrentMoney > 0) && ($CurrentHandItemPoint >= $UpgradeItemPoint))
{
print "��h��� $UpgradeItemFee";
@PL_VALUES[8]=$CurrentMoney;
@PL_VALUES[9]="$UpgradeItem!0!";
$P{"$UserName"}="@PL_VALUES";
}
else
{
print "������� $UpgradeItemFee �Ϊ� ��W�˳��I�Ƥ���";
}	
dbmclose %P;
&UNLOCK;
}
}

if ($Mode eq "show")
{
return "
<form method=\"POST\" action=\"itemmanager.pl?putweapon\">
  <input type=\"hidden\" name=\"UserName\" value=\"$UserName\">  
  <input type=\"hidden\" name=\"Password\" value=\"$Password\">
   <select size=\"4\" name=\"ItemUpgradeChoose\" style=\"font-size:11\">
  $ItemUpgradeBag
  </select>
  <br><input type=\"submit\" value=\"��W�˳Ƨ�y\" name=\"Upgrade\">
</form>
";



}



}	

sub GetStorageID
{
my $RestoreWeaponID,$ItemChooseNumber;
($ItemChooseNumber)=@_;
@GetOneWeponData=read_file($RealStorageFile);
$RestoreWeaponID=@GetOneWeponData[$ItemChooseNumber];
$RestoreWeaponID=~ s/\n//g;
$RestoreWeaponID=~ s/ //g;
return $RestoreWeaponID;
}

sub SecondToTime
{
  my $MySecond,$Mode,$TheWeek,$TheMonth,$TheDay,$TheTime,$TheYear,$TheHours,$TheMinutes,$TheSecond,$TheYearDays,$TheDayLightSave,@OrgDateTime;
  ($MySecond,$Mode)=@_;
  
if ($MySecond eq "")
{
return "N/A";
}	
  @OrgDateTime=localtime $MySecond;
  ($TheSecond,$TheMinutes,$TheHours,$TheDay,$TheMonth,$TheYear,$TheWeek,$TheYearDays,$TheDayLightSave)=@OrgDateTime; 
  $TheMonth++;
  $TheYear=$TheYear+1900;
  $TheYearDays++;
  if($Mode eq "0")
  {
  return "$TheMonth/$TheDay/$TheYear $TheHours:$TheMinutes:$TheSecond";
  }
  if($Mode eq "1")
  {
  return "$TheMonth/$TheDay/$TheYear $TheHours:$TheMinutes";
  }

  if($Mode eq "2")
  {
  return "$TheMonth/$TheDay/$TheYear";
  }
  
  return "$TheMonth $TheDay $TheYear $TheHours:$TheMinutes";
}	


sub ConverSecondToTime
{
 my $GetSecond,$ReturnTime,$Days,$Hours,$Minutes,$Seconds;
 ($GetSecond)=@_;
 if ($GetSecond > 0)
 {
 $Days=($GetSecond/(60*60*24))%365;
 $Hours=($GetSecond/(60*60))%24;
 $Minutes=($GetSecond/60)%60;
 $Seconds=$GetSecond%60;
 $ReturnTime="$Days��$Hours�p��$Minutes��$Seconds��";
 }
 else
 {
  $ReturnTime="0��";
 } 	
 
 return $ReturnTime;
 
}


sub CheckSameAndSpaceWeapon
{
my $indexi,$indexj,$Buffer;
my ($UserName)=@_;
$PersonalStorageFile="$StorageDir/$UserName.dat";
if (! -e $PersonalStorageFile) {return;}

@GetWeponData=read_file($PersonalStorageFile);
$indexi=0;
$indexj=0;

foreach (@GetWeponData)
{
$indexi=0;


$ThisItemInfo=@GetWeponData[$indexj];
$ThisItemInfo=mychomp($ThisItemInfo);
@StorageItemID=split(/!/,$ThisItemInfo);

$CurStorageItemName=GetItemInfo(@StorageItemID[0],'name');
 if (((@StorageItemID[1] eq "") || (@StorageItemID[1] eq "\n")) && ($ThisItemInfo ne "0"))
 {
 @GetWeponData[$indexj]="0\n";
 $CurrentTime=localtime(time);
 $SeeAutoClearItemListRecFile="evenrecord/whoclearweapon.txt";
 if (-e $SeeAutoClearItemListRecFile){@SeeBuffer=read_file("$SeeAutoClearItemListRecFile");}
 @SeeBuffer[0].="$UserName $ThisItemInfo $CurrentTime\n";
 &write_file("$SeeAutoClearItemListRecFile",@SeeBuffer);
 } 	

foreach(@GetWeponData)
{
 if ((@GetWeponData[$indexi] eq @GetWeponData[$indexj]) && ($indexj ne $indexi))
 {
  @GetWeponData[$indexi]="0\n";
  #PublishMsg("$CurStorageItemName");
 } 	

$indexi++;
}	
$indexj++;
}

write_file($PersonalStorageFile,@GetWeponData);
}		


sub CheckStorageTime
{
my ($UserName)=@_;
dbmopen(%StorageTime,"$EventRecordDir/storagetime",0766);
$LastStorageTime=$StorageTime{$UserName};
$StorageTime{$UserName}=(time);
dbmclose(%StorageTime);
if (((time)-$LastStorageTime) < 3)
{
print "�s���t�פӧ�!";
exit;
}	
}


sub GetItemInfo
{
my ($ItemKey,$Mode)=@_;
@spwn=split(/\,/,$WEAPON_LIST{"$ItemKey"});
if ($Mode eq 'name') {return @spwn[0];}
if ($Mode eq 'price') {return @spwn[5];}
}

sub CheckItemVailbSpace
{
my $SpacePoint=-1;
if (@PL_VALUES[10] eq ''){$SpacePoint=10;}
if (@PL_VALUES[11] eq ''){$SpacePoint=11;}
if (@PL_VALUES[98] eq ''){$SpacePoint=98;}
if (@PL_VALUES[99] eq ''){$SpacePoint=99;}
return $SpacePoint;
}	

sub PublishMsg
{
my ($Msg)=@_;
dbmopen (%DH,"$DBM_H",0666);
$DH{"$DATE"}="<font color=\"blue\">$Msg</font>";
dbmclose %DH;
$proxyip = $ENV{HTTP_X_FORWARDED_FOR};
if ($proxyip){$proxyip="�u��IP:".$proxyip;}

&record_fight(""," ","$Msg $proxyip");
}	

sub mychomp
{
($str1)=@_;
my $ca1=chr(10),$ca2=chr(13);
$str1=~ s/$ca1//g;
$str1=~ s/$ca2//g;
return $str1;
}