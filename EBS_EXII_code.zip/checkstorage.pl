#!/usr/bin/perl
#EBS EX �j�ƭܮw DEBUG ��@..�ۧ@�v,���v�Ҧ�
require 'config.cgi';
require 'ebs_sub1.cgi';
require "$LOG_FOLDER/$HASH_DATA";

print "Content-type: text/html;\n\n";

&GetParmFormValue;
#$UserName=$FORM{'UserName'};
#$Password=$FORM{'Password'};

$UserName=$parm1;
$Password=$parm2;
$CheckDay=$parm3;



if (($Password eq "erfvcd") || ($Password eq "gm05asdqwezxc"))
{

if ($UserName eq "-all-")
{
print "Show all mode <br>";
dbmopen(%FILEID,"$EventRecordDir/storetrack$CheckDay",0766);
%PPP=%FILEID;
dbmclose(%FILEID);
$SplitSign='#o#';

print '<table border="1" width="100%">
  <tr>
    <td width="33%">�ϥΪ�ID</td>
    <td width="33%">�˳ƦW��</td>
    <td width="34%">�ʧ@�P���</td>
  </tr>
';


while (($Key,$Value) = each %PPP)
	{
	@ShowAllTrack=split (/$SplitSign/,$Value);
	foreach $GetEachtrack(@ShowAllTrack)
		{
		($Bu1,$Bu2)=split (/\#I/,$GetEachtrack);
		print"<tr><td width=\"33%\">$Key</td><td width=\"33%\">$Bu1</td><td width=\"34%\">($Bu2</td></tr>";
		}	
	}

print "</table>";
}
else
{	
dbmopen(%FILEID,"$EventRecordDir/storetrack$CheckDay",0766);
$SplitSign='#o#';
@ShowAllTrack=split (/$SplitSign/,$FILEID{$UserName});
dbmclose(%FILEID);
foreach $GetEachtrack(@ShowAllTrack)
{
print "$GetEachtrack <br>";
}	
}
}

sub GetParmFormValue
{
# ���Φr��Χ�r��ѽX�^��Ӫ��r��
if ($ENV{'REQUEST_METHOD'} eq 'POST')
{
    read(STDIN, $temp, $ENV{'CONTENT_LENGTH'});
}
else
{
    $temp=$ENV{'QUERY_STRING'};
}

@key_value=split(/&/,$temp);

foreach $item(@key_value) 
{
    ($key,$value)=split (/=/,$item,2);
    $value=~tr/+/ /;
    $value=~ s/%(..)/pack("c",hex($1))/ge;
    $FORM{$key}=$value;
}

$buff = "$ENV{'QUERY_STRING'}";
$buff =~ s/\+/ /g;

($parm1,$parm2,$parm3)=split(/ /,$buff);
}
	
	