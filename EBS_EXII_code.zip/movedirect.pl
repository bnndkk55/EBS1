#!/usr/bin/perl
#���L���a�I���ӱN��Ʈ���
require "ebs_sub1.cgi";
require "$LOG_FOLDER/$HASH_DATA";
print "Content-type: text/html;\n\n";


&pre_get_value;
@SelfWeaponInfo='';@EnemyWeaponInfo='';
$EachMoveTimeSet=5;
$FightDeny=1;
$EarnMoneyLimit=5000;
$EarnExpLimit=500;
$MeetTas=0;
$FightWithUser=0;
$CurrentPeople="";
$Mode=$parm1;
if ($Mode eq ""){return;}

if ($Mode eq "move")
{
$GetUserName=$parm2;
$GetUserPassword=$parm3;
$MoveWay=$parm4;
$SingleFight=$parm5;
#print "$GetUserName $GetUserPassword $MoveWay";
}

&DBM_INPORT(P);
@PL_VALUES = split(/\s/,$P{"$GetUserName"});

(@PL_VALUES[15],@PL_VALUES[25])=AutoRepair("HP",@PL_VALUES[15],@PL_VALUES[16],@PL_VALUES[25],@PL_VALUES[26]);
(@PL_VALUES[17],@PL_VALUES[25])=AutoRepair("EN",@PL_VALUES[17],@PL_VALUES[18],@PL_VALUES[25],@PL_VALUES[26]);
($PlCurrentWeaponID,$None)= split(/!/,@PL_VALUES[9]);


$SelfAtt=@PL_VALUES[19];
$SelfPro=@PL_VALUES[20];
$SelfSpd=@PL_VALUES[21];
$SelfHit=@PL_VALUES[22];



CheckPassword($GetUserPassword,@PL_VALUES[2]);
@ReadMoveData=read_file("movedata.dat");
@ReadMapData=read_file("ebsmap1.dat");

$MaxIndex=@ReadMapData-1;
$MaxX=49;$MaxY=49;
$MinX=0;
$MinY=0;
$OutputMessage="";
$i=0;
$FindUser=0;
$MapPeopleDatai=0;
$MapPeopleData="";

$Tda=@ReadMoveData;
$FlashUse="TotalData=$Tda";
$ix=0;
$OtherUserNameList="";
	foreach (@ReadMoveData)
        	{
          	$userdata_line=@ReadMoveData[$i];
          	$userdata_line=mychomp($userdata_line);
		($AllUserName,$AllUserX,$AllUserY) = split(/,/,$userdata_line);
		if ($AllUserName eq $GetUserName)
             	   {          	
             	    $UserName=$AllUserName;$UserX=$AllUserX;$UserY=$AllUserY;
             	    @UserValues = split(/\s/,$P{"$UserName"});
		    if ((time)-@PL_VALUES[26]< $EachMoveTimeSet) 
		    	{$NoMove=1;$OutputMessage.="���ʳt�פӧ�..����L�k�Ө�! ";}
             	    if (@PL_VALUES[25] == 1) 
             	    	{
             	    	$NoMove=1;$OutputMessage.="����ײz��..�L�k����! ";
            	        if (@PL_VALUES[15] < 0) 
		        {@PL_VALUES[15] = 0;WritePldata($GetUserName,@PL_VALUES);}

             	    	}
             	    if ($NoMove ne 1) 
             	    {
             	    if ($MoveWay eq "right") {$UserX++;$IsWall=0;if ($UserX > $MaxX) {$UserX = $MaxX;$IsWall=1;}}
             	    if ($MoveWay eq "left") {$UserX--;$IsWall=0;if ($UserX < $MinX) {$UserX = $MinX;$IsWall=1;}}
             	    if ($MoveWay eq "up") {$UserY--;$IsWall=0;if ($UserY < $MinY) {$UserY = $MinY;$IsWall=1;}}
             	    if ($MoveWay eq "down") {$UserY++;$IsWall=0;if ($UserY > $MaxY) {$UserY = $MaxY;$IsWall=1;}}
             	    if ($MoveWay eq "fight") {$IsWall=0;$FightWithUser=1;}
             	    if ($UserX eq "") {$UserX=0;}
             	    if ($UserY eq "") {$UserY=0;}
             	    $AllUserName=$UserName;$AllUserX=$UserX;$AllUserY=$UserY;
             	    }
             	    $FindUser=1;
             	   }
		if (($AllUserX eq $UserX) && ($AllUserY eq $UserY) && ($AllUserName ne $GetUserName))
		{$OtherUserNameList.="$AllUserName,";}
             	@ReadMoveData[$i]="$AllUserName,$AllUserX,$AllUserY\n";
             	$FlashUse.="&USN$ix=$AllUserName&USX$ix=$AllUserX&USY$ix=$AllUserY";
             	$i++;
            	$ix++;
       		} 
if ($FindUser ne 1)
{
@ReadMoveData[$i]="$GetUserName,0,0\n";
}	  	

@FlashUserA[0]=$FlashUse;
write_file("moveflash.dat",@FlashUserA);
write_file("movedata.dat",@ReadMoveData);
    
if ($IsWall eq 1) 
{
 $OutputMessage.=SetFontAttr("3","#ff6699",0,"$GetUserName�I��@�ӫܤj����ê��,�L�k�e�i! ");
}

if ($FightWithUser eq 1)
{
$NoFight=0;
CheckOtherEnemyAndFight();
}

$MapIndex=($UserX*50)+$UserY;

$userdata_line=@ReadMapData[$MapIndex];
$userdata_line=mychomp($userdata_line);
local($mapx,$mapy,$PlaceAttr,$status) = split(/,/,$userdata_line);
if ($NoMove ne 1) {CheckStatus();}
($CurrentItem1ID,$None)= split(/!/,@PL_VALUES[9]);
($UBItem1ID,$None)= split(/!/,@PL_VALUES[10]);
($UBItem2ID,$None)= split(/!/,@PL_VALUES[11]);
($UBItem3ID,$None)= split(/!/,@PL_VALUES[98]);
($UBItem4ID,$None)= split(/!/,@PL_VALUES[99]);



@UBItem1Data=split(/\,/,$WEAPON_LIST{$UBItem1ID});
@UBItem2Data=split(/\,/,$WEAPON_LIST{$UBItem2ID});
@UBItem3Data=split(/\,/,$WEAPON_LIST{$UBItem3ID});
@UBItem4Data=split(/\,/,$WEAPON_LIST{$UBItem4ID});

$AttPlus=0;
$ProPlus=0;
$SpdPlus=0;
$HitPlus=0;

if (@UBItem1Data[7] eq 100) {$SpdPlus=@UBItem1Data[8];}
if (@UBItem2Data[7] eq 101) {$ProPlus=@UBItem2Data[8];}
if (@UBItem3Data[7] eq 102) {$AttPlus=@UBItem3Data[8];}
if (@UBItem4Data[7] eq 103) {$HitPlus=@UBItem4Data[8];}

$SelfAtt=@PL_VALUES[19]+$AttPlus;
$SelfPro=@PL_VALUES[20]+$ProPlus;
$SelfSpd=@PL_VALUES[21]+$SpdPlus;
$SelfHit=@PL_VALUES[22]+$HitPlus;

if (@PL_VALUES[25] == 1) {$IsCanFight="����ײz��";} else {$IsCanFight="�i�@��!"};

$OutputMessage.=SetFontAttr("3","#f105ab",1,"$GetUserName �ثe���A:$IsCanFight ��:@PL_VALUES[8]�� HP:@PL_VALUES[15]/@PL_VALUES[16]  EN:@PL_VALUES[17]/@PL_VALUES[18] ��:$SelfAtt ��:$SelfPro �t:$SelfSpd �R:$SelfHit");
if ($OtherUserNameList ne "") {$OtherUserNameList="�ثe�o�Ӱϰ��٦�$OtherUserNameList�b�o";}
#�Z���W��,�����O,�R���v,�����^��,���OEN,��X��,�J���k,



print "&FightMsg=$OutputMessage$OtherUserNameList";

sub CheckStatus
{
	 if ($status eq '�ĤH') 
	    {
	    local($mapx,$mapy,$PlaceAttr,$status,$EnemyName,$HitRate,$SayWords,$EnemyHP,$EnemyEN,$EnemyAtt,$EnemyPro,$EnemySpd,$EnemyHit,$EnemyWeapon) = split(/,/,$userdata_line);
       	    @Nothing=ShowPlaceBackground($PlaceAttr,1); 
            ProcessMeetEnemy();
	    }
	    

	 if ($status eq '�p��') 
	    {
	    local($mapx,$mapy,$PlaceAttr,$status,$MoneyAmount) = split(/,/,$userdata_line);
       	    
       	    @Nothing=ShowPlaceBackground($PlaceAttr); 
	    $OutputMessage.=SetFontAttr("3","#f105ab",1,"$GetUserName �b$PlaceAttr �J��p�� �l��$MoneyAmount G");
	    @PL_VALUES[8]-=$MoneyAmount;
	    WritePldata($GetUserName,@PL_VALUES);
	    }

	 if ($status eq '�H') 
	    {
	    
	    local($mapx,$mapy,$PlaceAttr,$status,$CharacterName,$Words1,$Words2,$Words3) = split(/,/,$userdata_line);
       	    
       	    
       	    @Nothing=ShowPlaceBackground($PlaceAttr); 
	    $Words="�L�{�b���Q����..";
	    $GetRndNumber=int rand(5);
	    if ($GetRndNumber eq 1) {$Words=$Words1;}
	    if ($GetRndNumber eq 2) {$Words=$Words2;}
	    if ($GetRndNumber eq 3) {$Words=$Words3;}

    
	    $OutputMessage.=SetFontAttr("3","#f105ab",1,"$GetUserName �b$PlaceAttr �J��$CharacterName $Words");
	    
	    require "movedirectaddtion.pl";

	    }
        
	 if ($status eq '�L') 
	    {
	    local($mapx,$mapy,$PlaceAttr,$status) = split(/,/,$userdata_line);
            local($IsMeet,$ExpMin,$ExpMax,$MoneyMin,$MoneyMax,$EnemyName,$HitRate,$SayWords,$EnemyHP,$EnemyEN,$EnemyAtt,$EnemyPro,$EnemySpd,$EnemyHit,$EnemyWeapon) =ShowPlaceBackground($PlaceAttr); 
            if ($IsMeet eq 1)
               {
               ProcessMeetEnemy();
               }	
	    
	    }


}	

sub ProcessMeetEnemy
{
	    $MeetRand=int(rand(100));
	    if ($MeetRand < $HitRate)
	    {
	    $WeaponName=GetItemName($EnemyWeapon);
   	    $OutputMessage.=SetFontAttr("3","#f105ab",1,"�b$PlaceAttr �J��$status $EnemyName ,HP=$EnemyHP,EN=$EnemyEN,��:$EnemyAtt,��:$EnemyPro,�t:$EnemySpd,��:$EnemyHit,�Z��:$WeaponName");
	    $OutputMessage.=SetFontAttr("3","#f105ab",1,"$EnemyName �� $SayWords");
            $NoFight=0;
	    if (@PL_VALUES[25] == 1)
	       {
	       $OutputMessage.=SetFontAttr("3","#f105ab",1,"$GetUserName ����ײz��,�L�k�԰�!");
	       $NoFight=1;
	       }
	
	   if ($NoFight eq 0)
	      {
               ($SelfHPLose,$EnemyHPLose,$SelfEnLose,$EnemyEnLose,$SelfMoney,$EnemyMoney,$SelfWeaponFinalPower,$EnemyWeaponFinalPower)=CaculateFight($SelfAtt,$SelfPro,$SelfSpd,$SelfHit,$SelfWeapon,$EnemyAtt,$EnemyPro,$EnemySpd,$EnemyHit,$EnemyWeapon);
	       $OutputMessage.=SetFontAttr("3","#f105ab",1,"$EnemyName �H $WeaponName ���� $GetUserName...�g�L�@�}��������.");
	       
	       $CurrentEnemyHP=$EnemyHP-$EnemyHPLose;
	       @PL_VALUES[15]-=$SelfHPLose;
	       @PL_VALUES[17]-=$SelfEnLose;
	       @PL_VALUES[8]+=$SelfMoney;
	       
	       $CurrentTime=(time);
	       @PL_VALUES[26]=$CurrentTime;

	       if (@PL_VALUES[15] <=0) 
	     	{
     		$SelfGetExp=$ExpMin+ int rand($ExpMax/$EarnExpLimit);
     		$SelfMoney=$MoneyMin+int rand($MoneyMax/$EarnMoneyLimit);

	    	@PL_VALUES[25] = 1;
	    	@PL_VALUES[15] =0;
		$OutputMessage.=SetFontAttr("3","#f105ab",0,"$GetUserName �Q�j�}�F. �]���A�ѼĤH���W��� $SelfMoney G �g���$SelfGetExp. ");
	    	@PL_VALUES[30]+=$SelfGetExp;
	    	@PL_VALUES[8]+=$SelfMoney;
	    	}

	       if ($CurrentEnemyHP <=0) 
	        {
	       	
     		$SelfGetExp=$ExpMin+ int rand(int ($ExpMax/$EarnExpLimit));
     		$SelfMoney=$MoneyMin+int rand(int ($MoneyMax/$EarnMoneyLimit));
     		$OutputMessage.=SetFontAttr("3","#f105ab",0,"$EnemyName �Q�j�}�F. �]���A�ѼĤH���W��� $SelfMoney G �g���$SelfGetExp. ");
     		@PL_VALUES[30]+=$SelfGetExp;
	    	@PL_VALUES[8]+=$SelfMoney;
	       	}
	       
	       $OutputMessage.=SetFontAttr("3","#f105ab",1," $GetUserName �l�� $SelfHPLose �IHP �����԰��`�@ì�o�� $SelfMoney G �g��� $SelfGetExp �I, $EnemyName �l�� $EnemyHPLose �IHP ì�o$EnemyMoney G $EnemyName�]���F!");

	      }

	        
	    
	    WritePldata($GetUserName,@PL_VALUES);
	   } 
}


sub ShowPlaceBackground
{
my @GetEnemyData,$RndValue;
my ($PlaceAttr,$DefaultEnemy)=@_;
if ($PlaceAttr eq "��a") 
{
if ($DefaultEnemy eq 1) {return;}
 $RndValue=int rand(2);
 if ($RndValue eq 1) {@GetEnemyData=MeetEnemyType(0);}
 else { @GetEnemyData=MeetEnemyType(1);}
}
if ($PlaceAttr eq "�۰�") 
{
 if ($DefaultEnemy eq 1) {return;}
 @GetEnemyData=MeetEnemyType(3);
}
if ($PlaceAttr eq "��L") 
{
if ($DefaultEnemy eq 1) {return;}
 @GetEnemyData=MeetEnemyType(4);
}
if ($PlaceAttr eq "����") 
{
 if ($DefaultEnemy eq 1) {return;}
 }

if ($PlaceAttr eq "�s��") 
{
 if ($DefaultEnemy eq 1) {return;}
 $EneTypeCho=int(rand(3));

 if ($EneTypeCho eq 0)
 {
 @GetEnemyData=MeetEnemyType(5);
 }

 if ($EneTypeCho eq 1)
 {
 @GetEnemyData=MeetEnemyType(6);
 }

 if ($EneTypeCho eq 2)
 {
 @GetEnemyData=MeetEnemyType(7);
 }	


}
return (@GetEnemyData);
}	

sub MeetEnemyType
{
my $IsMeet,$ExpMin,$ExpMax,$MoneyMin,$MoneyMax,$EnemyName,$HitRate,$SayWords,$EnemyHP,$EnemyEN,$EnemyAtt,$EnemyPro,$EnemySpd,$EnemyHit,$EnemyWeapon;
my ($EnemyNumber)=@_;
$IsMeet=0;
if ($EnemyNumber eq 0)
{
$EnemyName="�̦̦h";
$HitRate=90;$SayWords="�ڬO$EnemyName!�n��N�ӧa!����!";$EnemyHP=6000;$EnemyEN=500;
$EnemyAtt=20;$EnemyPro=10;$EnemySpd=30;$EnemyHit=10;$EnemyWeapon="aa!0";
$ExpMin=10;$ExpMax=500;
$MoneyMin=5;$MoneyMax=500;

$IsMeet=1;
}	
if ($EnemyNumber eq 1)
{
$EnemyName="�b�~�H";
$HitRate=20;$SayWords="�ڬO$EnemyName!���ߧګr�A��!";$EnemyHP=9000;$EnemyEN=100;
$EnemyAtt=30;$EnemyPro=70;$EnemySpd=90;$EnemyHit=30;$EnemyWeapon="bb!0";
$ExpMin=30;$ExpMax=700;
$MoneyMin=50;$MoneyMax=700;
$IsMeet=1;
}	
if ($EnemyNumber eq 3)
{
$EnemyName="�۩��~";
$HitRate=50;$SayWords="�ڬO$EnemyName!�ڪ����Y�i�O�ܵw��!";$EnemyHP=12000;$EnemyEN=200;
$EnemyAtt=80;$EnemyPro=170;$EnemySpd=30;$EnemyHit=30;$EnemyWeapon="ccc!0";
$ExpMin=50;$ExpMax=1000;
$MoneyMin=50;$MoneyMax=1500;

$IsMeet=1;
}	

if ($EnemyNumber eq 4)
{
$EnemyName="��";
$HitRate=70;$SayWords="�ڬO$EnemyName!���ߧڹ�A�I�k!";$EnemyHP=22000;$EnemyEN=2200;
$EnemyAtt=180;$EnemyPro=270;$EnemySpd=230;$EnemyHit=230;$EnemyWeapon="eee!0";
$ExpMin=250;$ExpMax=1500;
$MoneyMin=55;$MoneyMax=2500;

$IsMeet=1;
}	

if ($EnemyNumber eq 5)
{
$EnemyName="�i���~";
$HitRate=80;$SayWords="�ڬO$EnemyName!";$EnemyHP=52000;$EnemyEN=3200;
$EnemyAtt=280;$EnemyPro=370;$EnemySpd=330;$EnemyHit=330;$EnemyWeapon="ffff!0";
$ExpMin=450;$ExpMax=1700;
$MoneyMin=100;$MoneyMax=4500;
$IsMeet=1;
}	

if ($EnemyNumber eq 6)
{
$EnemyName="�j�]���~";
$HitRate=90;$SayWords="�ڬO$EnemyName!";$EnemyHP=72000;$EnemyEN=3200;
$EnemyAtt=380;$EnemyPro=470;$EnemySpd=430;$EnemyHit=430;$EnemyWeapon="yyyyy!0";
$ExpMin=600;$ExpMax=2300;
$MoneyMin=500;$MoneyMax=5000;
$IsMeet=1;
}	

if ($EnemyNumber eq 7)
{
$EnemyName="�]���~";
$HitRate=80;$SayWords="�ڬO$EnemyName!";$EnemyHP=122000;$EnemyEN=3200;
$EnemyAtt=450;$EnemyPro=500;$EnemySpd=500;$EnemyHit=430;$EnemyWeapon="wggggggg!0";
$ExpMin=1000;$ExpMax=3000;
$MoneyMin=2500;$MoneyMax=5000;
$IsMeet=1;
}	



return ($IsMeet,$ExpMin,$ExpMax,$MoneyMin,$MoneyMax,$EnemyName,$HitRate,$SayWords,$EnemyHP,$EnemyEN,$EnemyAtt,$EnemyPro,$EnemySpd,$EnemyHit,$EnemyWeapon);
}	



sub pre_get_value
{
# ���Φr��Χ�r��ѽX�^��Ӫ��r��
if ($ENV{'REQUEST_METHOD'} eq 'POST')
{
    read(STDIN, $temp, $ENV{'CONTENT_LENGTH'});
}
else
{
    $temp=$ENV{'QUERY_STRING'};
}

@key_value=split(/&/,$temp);

foreach $item(@key_value) 
{
    ($key,$value)=split (/=/,$item,2);
    $value=~tr/+/ /;
    $value=~ s/%(..)/pack("c",hex($1))/ge;
    $FORM{$key}=$value;
}

$buff = "$ENV{'QUERY_STRING'}";
$buff =~ s/\+/ /g;

($parm1,$parm2,$parm3,$parm4,$parm5)=split(/ /,$buff);
}


sub WritePldata
{
my($UserName,@DataValue)=@_;
&LOCK;
dbmopen (%P,"$DBM_P",0666);
$P{"$UserName"}="@DataValue";
dbmclose %P;
&UNLOCK;
}	

sub ReadPldata
{
my @DataValue;
my($UserName)=@_;
&LOCK;
dbmopen (%V,"$DBM_P",0666);
@DataValue= split(/\s/,$V{"$UserName"});
dbmclose %V;
&UNLOCK;
return @DataValue;
}	

sub GetItemName
{
my $ItemID,$ItemPoint,@CurrentHandItem;
($GetOneItemData)=@_;
($ItemID,$ItemPoint)= split(/!/,$GetOneItemData);
@ItemName=split(/\,/,$WEAPON_LIST{"$ItemID"});
return @ItemName[0];
}



sub CaculateFight
{
my $SelfHPLose,$EnemyHPLose,$SelfEnLose,$EnemyEnLose,$SelfMoney,$EnemyMoney;
my($SelfAtt,$SelfPro,$SelfSpd,$SelfHit,$SelfWeapon,$EnemyAtt,$EnemyPro,$EnemySpd,$EnemyHit,$EnemyWeapon)=@_;

($SelfItemID,$ItemPoint)= split(/!/,$SelfWeapon);
($EnemyItemID,$ItemPoint)= split(/!/,$EnemyWeapon);
@SelfWeaponInfo=TakeWeaponInfo($SelfItemID);
@EnemyWeaponInfo=TakeWeaponInfo($EnemyItemID);

#�Z���W��,�����O,�R���v,�����^��,���OEN,��X��,�J���k,
$SelfWeaponName=@SelfWeaponInfo[0];
$EnemyWeaponName=@EnemyWeaponInfo[0];
$SelfWeaponPower=@SelfWeaponInfo[1];
$EnemyWeaponPower=@EnemyWeaponInfo[1];
$SelfWeaponAim=@SelfWeaponInfo[2];
$EnemyWeaponAim=@EnemyWeaponInfo[2];
$SelfWeaponTimes=@SelfWeaponInfo[3];
$EnemyWeaponTimes=@EnemyWeaponInfo[3];
$SelfWeaponEn=@SelfWeaponInfo[4];
$EnemyWeaponEn=@EnemyWeaponInfo[4];

$SelfWeaponSpecial=@SelfWeaponInfo[7];
$EnemyWeaponSpecial=@EnemyWeaponInfo[7];



$SelfEnLose=$SelfWeaponEn;
$EnemyEnLose=$EnemyWeaponEn;

$SelfWeaponTotalPower=($SelfWeaponPower*($SelfWeaponAim/100))*$SelfWeaponTimes;
$EnemyWeaponTotalPower=($EnemyWeaponPower*($EnemyWeaponAim/100))*$EnemyWeaponTimes;

$SelfWeaponFinalPower=$SelfWeaponTotalPower-$EnemyWeaponTotalPower;
$EnemyWeaponFinalPower=$EnemyWeaponTotalPower-$SelfWeaponTotalPower;

if ($SelfWeaponFinalPower < 0){$SelfWeaponFinalPower = 0;}
if ($EnemyWeaponFinalPower < 0){$EnemyWeaponFinalPower = 0;}

$SelfHPLose=(($EnemyAtt+1)*($EnemySpd+1)*(int rand($EnemyHit)+1)+$EnemyWeaponFinalPower)-(($SelfPro+1)*($SelfSpd+1)*(int rand($SelfHit+1)));
$EnemyHPLose=(($SelfAtt+1)*($SelfSpd+1)*(int rand($SelfHit)+1)+$SelfWeaponFinalPower)-(($EnemyPro+1)*($EnemySpd+1)*(int rand($EnemyHit+1)));

if ($SelfHPLose < 0) {$SelfHPLose=0;}
if ($EnemyHPLose < 0) {$EnemyHPLose=0;}

$SelfMoney=int ($EarnMoneyLimit-$SelfHPLose);
$EnemyMoney=int ($EarnMoneyLimit-$EnemyHPLose);

if ($SelfMoney < 0) {$SelfMoney =10;}
if ($EnemyMoney < 0) {$EnemyMoney =10;}
$SelfWeaponName=GetItemName($SelfWeapon);


$GetSelfSpecialName=WeaponSpecial($SelfWeaponSpecial);
$GetEnemySpecialName=WeaponSpecial($EnemyWeaponSpecial);
print "&MyWeaponName=$SelfWeaponName&HeWeaponName=$EnemyWeaponName&MyFightTimes=$SelfWeaponTimes&MyWepSpc=$GetSelfSpecialName&HeFightTimes=$EnemyWeaponTimes&HeWepSpc=$GetEnemySpecialName";

return ($SelfHPLose,$EnemyHPLose,$SelfEnLose,$EnemyEnLose,$SelfMoney,$EnemyMoney,$SelfWeaponFinalPower,$EnemyWeaponFinalPower);
}	


sub CheckOtherEnemyAndFight
{
$i=0;
foreach (@ReadMoveData)
       	{
       	$userdata_line=@ReadMoveData[$i];
       	$userdata_line=mychomp($userdata_line);
       	($RealEnemyName,$RealEnemyX,$RealEnemyY) = split(/,/,$userdata_line);
#=====================        
	
	if (($RealEnemyX eq $UserX) && ($RealEnemyY eq $UserY) && ($RealEnemyName ne  $GetUserName) && ($SingleFight eq $RealEnemyName))
           {          	
	    $WriteToPl=0;
            @VS_VALUES = split(/\s/,$P{"$RealEnemyName"});
            $CurrentPeople.=" $RealEnemyName ,";
            if (@VS_VALUES[1] ne "")
            {
	   (@VS_VALUES[15],@VS_VALUES[25])=AutoRepair("HP",@VS_VALUES[15],@VS_VALUES[16],@VS_VALUES[25],@VS_VALUES[26]);
	   (@VS_VALUES[17],@VS_VALUES[25])=AutoRepair("EN",@VS_VALUES[17],@VS_VALUES[18],@VS_VALUES[25],@VS_VALUES[26]);
   	if (@VS_VALUES[15] < 0) {@VS_VALUES[15] = 0;}
   	if (@VS_VALUES[17] < 0) {@VS_VALUES[17] = 0;}
	    $VSAtt=@VS_VALUES[19];
	    $VSPro=@VS_VALUES[20];
	    $VSSpd=@VS_VALUES[21];
	    $VSHit=@VS_VALUES[22];
            $VSWeapon=@VS_VALUES[9];
            $NoFight=0;

            $PLNoFight=0;
	    if (@PL_VALUES[25] == 1) 
	       {
	       	$IsPLCanFight="����ײz��";
	       	$PLNoFight=1;
	       }
   		else 
   		{
   		 $IsPLCanFight="�i�@��!";
   		}

            $VSNoFight=0;
	    if (@VS_VALUES[25] == 1) 
	       {
	       	$IsVSCanFight="����ײz��";
	       	if (@VS_VALUES[15] < 0) 
	       	{@VS_VALUES[15] = 0;WritePldata($RealEnemyName,@VS_VALUES);}
	       	$VSNoFight=1;
	       }
   		else 
   		{
   		 $IsVSCanFight="�i�@��!";
   		}

	    $OutputMessage.=SetFontAttr("3","#f105ab",0,"�J�� @VS_VALUES[5] �� $RealEnemyName, $RealEnemyName �ثe$IsVSCanFight HP:@VS_VALUES[15]/@VS_VALUES[16]  EN:@VS_VALUES[17]/@VS_VALUES[18] ��:$VSAtt ��:$VSPro �t:$VSSpd �R:$VSHit .");
            
	    if ((@VS_VALUES[5] eq @PL_VALUES[5]) && (@PL_VALUES[5] ne $NONE_NATIONALITY) && (@PL_VALUES[5] ne ""))
	    {
	     $VSNoFight=1;
	     $PLNoFight=1;
             $OutputMessage.=SetFontAttr("3","#f105ab",0,"...��ӬO�ۤv�H�r!���O�P@VS_VALUES[5]��..�԰�����..");	     
	    }	

	    @PL_HandWEAPONINFO=split(/!/,@PL_VALUES[9]);
	    @PL_WEAPON3INFO=split(/!/,@PL_VALUES[12]);
	    @VS_WEAPON3INFO=split(/!/,@VS_VALUES[12]);
	    if ((@PL_WEAPON3INFO[0] eq "hqkubiki") && (@VS_WEAPON3INFO[0] eq "hqkubiki") )
	    {
	     if (int (@PL_WEAPON3INFO[0]/$WEAPON_LVUP) eq int (@VS_WEAPON3INFO[0]/$WEAPON_LVUP))
	     {
	     $VSNoFight=1;
	     $PLNoFight=1;
             $OutputMessage.=SetFontAttr("3","#f105ab",0,"...��ӬO�B�ͧr!..�԰�����..");	     
             }
	    }	

            
            if (($VSNoFight eq 0) && ($PLNoFight eq 0))
            {
            ($SelfHPLose,$VsHPLose,$SelfEnLose,$VsEnLose,$SelfMoney,$VSMoney,$SelfWeaponFinalPower,$EnemyWeaponFinalPower)=CaculateFight($SelfAtt,$SelfPro,$SelfSpd,$SelfHit,@PL_VALUES[9],$VSAtt,$VSPro,$VSSpd,$VSHit,@VS_VALUES[9]);
            @VS_VALUES[15]-=$VsHPLose;
            @VS_VALUES[17]-=$EnemyEnLose;

            @PL_VALUES[15]-=$SelfHPLose;
            @PL_VALUES[17]-=$SelfEnLose;
	    
	    $CurrentTime=(time);
	    #@VS_VALUES[26]=$CurrentTime;
	    @PL_VALUES[26]=$CurrentTime;
            $OutputMessage.=SetFontAttr("3","#f105ab",1,"$GetUserName �Z�����ħ����O $SelfWeaponFinalPower $RealEnemyName �Z�����ħ����O $EnemyWeaponFinalPower");
	    $OutputMessage.=SetFontAttr("3","#f105ab",0,"$RealEnemyName �H $EnemyWeaponName ���� $GetUserName...�g�L�@�}��������.");

	    if ((@PL_VALUES[15] <=0) && (@PL_VALUES[25] ne 1))
	    {
	    	$OutputMessage.=SetFontAttr("3","#f105ab",0,"$GetUserName �Q�j�}�F. ");
	    	@PL_VALUES[25]=1;
    	    }

	    if ((@VS_VALUES[15] <=0) && (@VS_VALUES[25] ne 1))
	    {
	    	$OutputMessage.=SetFontAttr("3","#f105ab",0,"$RealEnemyName �Q�j�}�F. ");
	    	@VS_VALUES[25]=1;
    	    }

   	    $OutputMessage.=SetFontAttr("3","#0005ab",1,"$GetUserName �l�� $SelfHPLose �IHP ì�o�� $SelfMoney G, $RealEnemyName �l�� $VsHPLose�IHP ì�o$VSMoney G ! $RealEnemyName �ثe HP�ѤU@VS_VALUES[15]  EN�|�l@VS_VALUES[17]<br>");
   	    WritePldata($RealEnemyName,@VS_VALUES);
   	    WritePldata($GetUserName,@PL_VALUES);

   	    }

           }
           }
#=====================
        $i++;
        } 

}	








#=====================DEBUG SUB S==============
#=====================DEBUG SUB S==============
#=====================DEBUG SUB S==============
#=====================DEBUG SUB S==============
#=====================DEBUG SUB S==============
sub write_file
{
 local($writefile_dat,@value)=@_;
 open(WRITEFILE,">$writefile_dat") || die $!;
 if ($local_test eq 0) {flock(WRITEFILE,LOCK_EX)};
 print WRITEFILE @value;
 if ($local_test eq 0) {flock(WRITEFILE,LOCK_UN)};
 close(WRITEFILE);
}	

sub read_file
{
 local($filename)=@_;
 open(READFILE,"<$filename") || die $!;
 if ($local_test eq 0) {flock(WRITEFILE,LOCK_EX)};
 @filedata = <READFILE>;
 if ($local_test eq 0) {flock(WRITEFILE,LOCK_UN)};
 close(READFILE);
return @filedata,;
}	

sub CheckPassword
{
local ($mypassword,$orgpassword,$Mode)=@_;
local $realpassword;
if ($mypassword eq "")
{
print "Pass=-2"; 
exit;
}	
$realpassword=(crypt ($mypassword,eb));
if ($realpassword ne $orgpassword)
{
print "Pass=-2"; 
exit;
}	
}

sub CountryIncreseMoneyValue
{
my ($CountryName,$Money)=@_;
#@CL_VALUES=($Color,$Money,$Term1,$Term2,$Term3,$WarName,$TargetCountry,$FightTime,$Term1TargetCountry,$Term2TargetCountry,$Term3TargetCountry,$BotaHp,$BoatName,$none,$none2,$Picture,$CountryLocation);
dbmopen (%CL,"$DBM_C",0666);
@CL_VALUES=split(/\s/,$CL{"$CountryName"});
@CL_VALUES[1]+=$Money;
$CL{"$CountryName"}="@CL_VALUES";
dbmclose %CL;
}	


sub mychomp
{
($str1)=@_;
my $ca1=chr(10),$ca2=chr(13);
$str1=~ s/$ca1//g;
$str1=~ s/$ca2//g;
return $str1;
}

sub TakeWeaponInfo
{
($WeaponID)=@_;
(@ReturnData)=split(/\,/,$WEAPON_LIST{$WeaponID});
return @ReturnData;
}		

sub AutoRepair()
{
my $ReturnHP,$ReturnEN,$CurrentTime;
my($Mode,$CurrentValue,$LimitValue,$CurrentStatus,$LastFightTime)=@_;
$CurrentTime=(time);
if ($Mode eq "HP")
{
$ReturnHP=$CurrentValue+($CurrentTime-$LastFightTime)*$HP_REPAIR;
if ($ReturnHP > $LimitValue) 
   {$ReturnHP = $LimitValue;return ($ReturnHP,0);}
   else 
   {return ($ReturnHP,$CurrentStatus);}
}	

if ($Mode eq "EN")
{
$ReturnEN=$CurrentValue+($CurrentTime-$LastFightTime)*$EN_REPAIR;
if ($ReturnEN > $LimitValue) 
   {$ReturnEN = $LimitValue;return ($ReturnEN,$CurrentStatus);}
   else 
   {return ($ReturnEN,$CurrentStatus);}
}	

}	

sub SetFontAttr
{
$ReturnString;
my ($FontSize,$FontColor,$IsBreakLine,$Content)=@_;
$ReturnString="<font color=\"$FontColor\" >$Content</font>";
if ($IsBreakLine eq 1) {$ReturnString.='<br>';}
return $ReturnString;
}	

sub WeaponSpecial
{
my ($SpecialType)=@_;
return "�L" if $SpecialType==0;
return "�l�a" if $SpecialType==1;
return "�j�}" if $SpecialType==2;
return "���m�[�j" if $SpecialType==3;
return "�����[�j" if $SpecialType==4;
return "���m�j�T����" if $SpecialType==5;
return "�e�q" if $SpecialType==6;
return "�îg" if $SpecialType==7;
return "�g������" if $SpecialType==8;
return "���m�ˮ`���Z������" if $SpecialType==10;
return "�������m�]�����ˮ`�^" if $SpecialType==11;
return "�e��" if $SpecialType==12;
return "��������" if $SpecialType==13;
return "HP�l��" if $SpecialType==14;
return "���z" if $SpecialType==15;
return "���O" if $SpecialType==16;
return "����" if $SpecialType==17;
return "�`�ӥΪ����P��������" if $SpecialType==18;
return "EN�l��" if $SpecialType==19;
return "�߿����v�W�[" if $SpecialType==20;
return "�����ݩʥ[�j" if $SpecialType==21;
return "���@�ݩʥ[�j" if $SpecialType==22;
return "�ӱ��ݩʥ[�j" if $SpecialType==23;
return "�˷��ݩʥ[�j" if $SpecialType==24;
return "�g������,�L�k�����ɤ��H" if $SpecialType==25;
return "�H���������ର�ؼ�" if $SpecialType==26;
}	
