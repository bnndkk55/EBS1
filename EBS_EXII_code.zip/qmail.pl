#!/usr/bin/perl
print "Content-type: text/html\n\n";   
if ($ENV{'REQUEST_METHOD'} eq 'POST'){read(STDIN, $temp, $ENV{'CONTENT_LENGTH'});}else{    $temp=$ENV{'QUERY_STRING'};}@key_value=split(/&/,$temp);foreach $item(@key_value) {   ($key,$value)=split (/=/,$item,2);$value=~tr/+/ /; $value=~ s/%(..)/pack("c",hex($1))/ge; $FORM{$key}=$value;}$buff = "$ENV{'QUERY_STRING'}";
if ($FORM{'name'} eq "") {showform();}
#$MailPath="/usr/local/psa/qmail/sendmail -t";# Sendmail ������|
$MailPath = "/usr/sbin/sendmail -t";# Sendmail ������| �Y�Ϊ��Oqmail �Ц۩w
print "�H�X�� ...";

$AdminEmailAddr='admin@frwonline.com';#�����Email

$MailSubjectMdy="�D��DOMAIN";#�D�D
$SenderMail = $FORM{'email'};#�H�H��
$MailFromMdy=$SenderMail;
$MailContent="�m�W $FORM{'name'}<br>
���q�W�� $FORM{'businessname'}<br>
�p���q�� $FORM{'telnumber'}<br>
FAX $FORM{'fax'}<br>
�q�l�a�} $FORM{'email'}<br>
�a�} $FORM{'address'}<br>
��W $FORM{'domain'}<br>
Domain ��k $FORM{'domainmethod'}<br>
���� $FORM{'city'}<br>
�A�ȭp�� $FORM{'serviceplan'}<br>
��a/�a�� $FORM{'country'}<br>
\n\n";

open (MAIL, "|$MailPath") or print"$SentMailErrorMdy  $!";
if ($FORM{'email'} eq "") {print "����g Email ";exit;}
print MAIL  "From: $SenderMail <$SenderMail>\nTo: $AdminEmailAddr\nSubject: $MailSubjectMdy\ncontent-type:text/html;\n\n $MailContent\n";
close (MAIL);
print "�H��w�H�X. ����!";

sub showform
{
print << "---HTMLTAGE----";
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=big5">
<title>�m�W</title>
</head>

<body>

<form method="POST" action="qmail.pl">
  <table border="1" width="64%">
    <tr>
      <td width="25%">�m�W:</td>
      <td width="25%"><input name="name" size="20"></td>
      <td width="25%">���q�W��</td>
      <td width="25%"><input name="businessname" size="20"></td>
    </tr>
    <tr>
      <td width="25%">�p���q��:</td>
      <td width="25%"><input name="telnumber" size="20"></td>
      <td width="25%">FAX</td>
      <td width="25%"><input name="fax" size="20"></td>
    </tr>
    <tr>
      <td width="25%">�q�l�a�}:</td>
      <td width="25%"><input name="email" size="20"></td>
      <td width="25%">�a�}</td>
      <td width="25%"><input name="address" size="20"></td>
    </tr>
    <tr>
      <td width="25%">��W</td>
      <td width="25%"><input name="domain" size="20"><br>
        <input type="radio" value="transfer" name="domainmethod">Transfer<input type="radio" value="new" name="domainmethod">New</td>
      <td width="25%">����</td>
      <td width="25%"><input name="city" size="20"></td>
    </tr>
    <tr>
      <td width="25%">�A�ȭp��</td>
      <td width="25%"><select name="serviceplan">
          <option selected>�п�ܩһݤ��A��
          <option>NA25
          <option>NA50
          <option>NA100
          <option>NA200
          <option>NA300
          <option>NA400
          <option>NA500
          <option>SV1
          <option>SV2
          <option>SV3
          <option>SV4</option>
        </select></td>
      <td width="25%">��a/�a��</td>
      <td width="25%"><input name="country" size="20"></td>
    </tr>
  </table>
  <p><input type="button" value="���s" name="B3"><input type="submit" value="����" name="B1"><input type="reset" value="���s�]�w" name="B2"></p>
</form>

</body>

</html>
---HTMLTAGE----
exit;
}	

