#!/usr/bin/perl
require 'ebs_sub1.cgi';
print "Content-type: text/html;\n\n";
pre_get_value();

$UserName=$parm1;
$CancelMark=$parm2;

&LOCK;
dbmopen (%P,"$DBM_P",0666);
	@VALS = split(/\s/,$P{"$UserName"});
dbmclose %P;
&UNLOCK;

$CallingTime=@VALS[70];

#print "Name=$UserName $CallingTime";
if ($CallingTime > 1)
{
print "HaveMsg=1";
}	
else
{
print "HaveMsg=0";
}	



if ($CancelMark eq 1)
{
&LOCK;
dbmopen (%P,"$DBM_P",0666);
	@VALS = split(/\s/,$P{"$UserName"});
	$VALS[70] = 0;
	$P{"$UserName"}="@VALS";
	
dbmclose %P;
&UNLOCK;
}


sub pre_get_value
{
# ���Φr��Χ�r��ѽX�^��Ӫ��r��
if ($ENV{'REQUEST_METHOD'} eq 'POST')
{
    read(STDIN, $temp, $ENV{'CONTENT_LENGTH'});
}
else
{
    $temp=$ENV{'QUERY_STRING'};
}

@key_value=split(/&/,$temp);

foreach $item(@key_value) 
{
    ($key,$value)=split (/=/,$item,2);
    $value=~tr/+/ /;
    $value=~ s/%(..)/pack("c",hex($1))/ge;
    $FORM{$key}=$value;
}

$buff = "$ENV{'QUERY_STRING'}";
$buff =~ s/\+/ /g;

($parm1,$parm2,$parm3)=split(/ /,$buff);
}