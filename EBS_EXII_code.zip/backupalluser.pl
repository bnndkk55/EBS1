#!/usr/bin/perl
#DEBUG ��@..�ۧ@�v,���v�Ҧ�
print "Content-type: text/html;\n\n";
require 'config.cgi';
require "debug_sub.pl";
require "ebs_sub1.cgi";
print "�ƥ��ҥHUSER�{��!<br>";
@GmNAME=("DEBUG","Chris","GM01");
@GmPassword=("tyhnbg","$MASTER_PWD","rtgbvf");

&pre_get_value;

$GmPassword=$parm1;
$GmName=$parm2;
$CheckPassword=0;
$i=0;


foreach $GetGmName(@GmNAME)
{
 if ($GmName eq $GetGmName)
    {
     $TakeGmPassword=@GmPassword[$i];
     if ($GmPassword eq  $TakeGmPassword)
     {  
     $CheckPassword=1;
     }
    }
$i++;

}
	

if ($CheckPassword eq 0)
   {
    print "$GetGmName PASSWORD ERROR! ";

@pair = split(/;/, $ENV{'HTTP_COOKIE'});
foreach (@pair) {my($key, $value) = split(/=/, $_);$DUMMY{$key} = $value;}
@pairs = split(/,/, $DUMMY{EB});
foreach (@pairs) 
{
my($key, $value) = split(/:/, $_);
$COOKIE{$key} = $value;
}
print "<br> ����$COOKIE{'pname'}($Ipaddress) <br>����: $COOKIE{'passname'} <br>�Q���J�̷s�� deluser.pl �o�Otest ���O����";

    exit;
   }	


&LOCK;
dbmopen (%P,"$DBM_P",0666);
while (($Key,$Value) = each %P)
        {
	$PCopy{"$Key"}=$P{"$Key"};
	
	}
	print "<br>copy $Key<br>";	
dbmclose %P;
&UNLOCK;

$BCK_P="$LOG_FOLDER/backalluser".(time);

&LOCK;
dbmopen (%PCK,"$BCK_P",0666);
while (($Key,$Value) = each %PCopy)
        {
	$PCK{"$Key"}=$PCopy{"$Key"};
	print "$Key,"
	}
	print "<br>copy $Key ok<br>";	
dbmclose %PCK;
&UNLOCK;


print "<br> check...<br>";
&LOCK;
dbmopen (%PCK2,"$BCK_P",0666);
while (($Key2,$Value) = each %PCK2)
        {
	
	print "$Key2,"
	}
	print "<br>Check ok<br>";	
dbmclose %PCK2;
&UNLOCK;



sub pre_get_value
{
# ���Φr��Χ�r��ѽX�^��Ӫ��r��
if ($ENV{'REQUEST_METHOD'} eq 'POST')
{
    read(STDIN, $temp, $ENV{'CONTENT_LENGTH'});
}
else
{
    $temp=$ENV{'QUERY_STRING'};
}

@key_value=split(/&/,$temp);

foreach $item(@key_value) 
{
    ($key,$value)=split (/=/,$item,2);
    $value=~tr/+/ /;
    $value=~ s/%(..)/pack("c",hex($1))/ge;
    $FORM{$key}=$value;
}

$buff = "$ENV{'QUERY_STRING'}";
$buff =~ s/\+/ /g;

($parm1,$parm2,$parm3)=split(/ /,$buff);
}
