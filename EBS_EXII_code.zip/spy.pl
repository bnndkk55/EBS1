#!/usr/bin/perl
#EBS EX �j�ƭܮw DEBUG ��@..�ۧ@�v,���v�Ҧ�
require 'config.cgi';
require "debug_sub.pl";

$Password="iambiggm01";
&pre_get_value;

$year=$parm1;
$month=$parm2;
$mday=$parm3;
$filename="evenrecord/$year-$month-$mday.htm";
$message="�Ӧ� IP $Ipaddress �� $FORM{'pname'} �� $nowtime ����  $FORM{'vsname'} $happen<br>\n";
@fightdata=&read_file("$filename");
print @fightdata;

sub pre_get_value
{
# ���Φr��Χ�r��ѽX�^��Ӫ��r��
if ($ENV{'REQUEST_METHOD'} eq 'POST')
{
    read(STDIN, $temp, $ENV{'CONTENT_LENGTH'});
}
else
{
    $temp=$ENV{'QUERY_STRING'};
}

@key_value=split(/&/,$temp);

foreach $item(@key_value) 
{
    ($key,$value)=split (/=/,$item,2);
    $value=~tr/+/ /;
    $value=~ s/%(..)/pack("c",hex($1))/ge;
    $FORM{$key}=$value;
}

$buff = "$ENV{'QUERY_STRING'}";
$buff =~ s/\+/ /g;

($parm1,$parm2,$parm3)=split(/ /,$buff);
}
