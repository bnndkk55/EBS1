#!/usr/bin/perl
print "Content-type: text/html;\n\n";
use DBI;
require "ebs_sub1.cgi";
require "debug_sub.pl";
require "mysqlconfig.pl";
require "mysqlsub.pl";

($parm1,$parm2,$parm3)=&A8();

#$UserID=$FORM{'ID'};

print "start..";

$dbh = DBI->connect("DBI:mysql:database=$cfsq04;host=$cfsq01",$cfsq02,$cfsq03, {RaiseError => 1});
print "connect<br>";
#print "Delete table $UserTable<br>";DropTable($dbh,$UserTable);

if ($parm1 eq "storage")
{
$TableField="B0 varchar(255) primary key";
foreach (1..$cfsq07){$TableField.=",B$_ varchar(255)";}
foreach (($cfsq07+1)..$cfsq06){$TableField.=",B$_ TEXT";}

#$TableField.=",B201 TEXT,B202 TEXT,B203 TEXT";
&sql01($dbh,$cfsq05,$TableField);
print "Create table UserID Field $TableField";
}

