#!/usr/bin/perl
#���L���a�I���ӱN��Ʈ���
require "ebs_sub1.cgi";
require "debug_sub.pl";
print "Content-type: text/html;\n\n";


$ps_x=30;
$ps_y=150;
$vs_x=520;
$vs_y=150;$Pl_MsnStyle="�t�̤���";$Vs_MsnStyle="���q����";$ps_die=0;$vs_die=0;
$Pl_W[0]="�Ҥ������`�ӼC";$Vs_W[0]="�Ҥ������`�ӼC";
$PL_VALUES[27]="104";$VS_VALUES[27]="576";
$PlLoseHP=-1000;
$VsLoseHP=-2000;
$currentBackground="fight_forest";
print << "	-----END-----";
<html> 
<body bgcolor="ffffff" bgproperties="fixed">
<script LANGUAGE="JavaScript">
<!--
self.document.body.bgcolor="ffffff";
self.document.body.background=""; 
//-->
</script>         

<div id=bgpicture style="position: absolute; visibility: visible; z-index: 900; top:0; left:0;"><img src="$IMG_FOLDER4/$currentBackground.jpg"></div> 
<div id=psbodydata style="position: absolute; visibility: visible; z-index: 900; top:5; left:70;"><br></div> 
<div id=vsbodydata style="position: absolute; visibility: visible; z-index: 900; top:5; left:540;"><br></div>
<div id=vsbody style="position: absolute; visibility: visible; z-index: 900; top: $vs_y; left: $vs_x;"><img src="$IMG_FOLDER2/$VS_VALUES[27].gif" name="vsimg"></div>
<div id=psbody style="position: absolute; visibility: visible; z-index: 900; top: $ps_y; left: $ps_x;"><img src="$IMG_FOLDER2/$PL_VALUES[27].gif" name="plimg" style="filter:fliph();"></div> 
<div id=dieword style="position: absolute; visibility: visible; z-index: 900; top: -1000; left: -1000;font-size=70px;"><center><font color="red"><b>K.O</b></font></center></div> 

<div id=pllosehp style="position: absolute; visibility: visible; z-index: 900; top: -1000; left: -1000;font-size=70px;"><center><font color="red"><b>$PlLoseHP</b></font></center></div> 
<div id=vslosehp style="position: absolute; visibility: visible; z-index: 900; top: -1000; left: -1000;font-size=70px;"><center><font color="red"><b>$VsLoseHP</b></font></center></div> 

<div id=diebody style="position: absolute; visibility: visible; z-index: 900; top: -1000; left: -1000;"> <img src="$IMG_FOLDER0/diebody.gif"></div> 
<div id=attacklight style="position: absolute; visibility: visible; z-index: 900; top: -1000; left: -1000;"> <img src="$IMG_FOLDER0/attacklight.gif"></div> 
<div id=light style="position: absolute; visibility: visible; z-index: 900; top: -1000; left: -1000;"> <img src="$IMG_FOLDER0/flash.gif" name="flash"></div> 
<div id=ps_god_sword style="position: absolute; visibility: visible; z-index: 900; top: -1000; left:-1000;"> <img src="$IMG_FOLDER0/god_sword.gif" name="god_sword" style="filter:fliph();"></div> 
<div id=vs_god_sword style="position: absolute; visibility: visible; z-index: 900; top: -1000; left:-1000;"> <img src="$IMG_FOLDER0/god_sword.gif"></div> 
<div id=ps_weapon_a style="position: absolute; visibility: visible; z-index: 900; top: -1000; left:-1000;"> <img src="$IMG_FOLDER0/weapon_a.gif" name="weapon_a" style="filter:fliph();"></div> 
<div id=vs_weapon_a style="position: absolute; visibility: visible; z-index: 900; top: -1000; left:-1000;"> <img src="$IMG_FOLDER0/weapon_a.gif"></div> 
<div id=dieflash style="position: absolute; visibility: visible; z-index: 900; top: -1000; left: -1000;"> <img src="$IMG_FOLDER0/boom1.gif" name="boom1"></div> 
<div id=yell_light style="position: absolute; visibility: visible; z-index: 900; top: -1000; left: -1000;"> <img src="$IMG_FOLDER0/yell_light.gif" name="yelllight"></div> 

<bgsound id=wigwag >
<bgsound id=boomsound >
<bgsound id=background_mus>


<script LANGUAGE="JavaScript">
<!--

var ko_sound="$SoundDir/ko.wav";
var boom1_sound="$SoundDir/boom1.wav";
var boom2_sound="$SoundDir/boom2.wav";
var boom3_sound="$SoundDir/boom3.wav";
var boom4_sound="$SoundDir/boom4.wav";
var fightbg1_sound="$SoundDir/fightmusic1.wav";

var ps_x=$ps_x;
var ps_y=$ps_y;
var vs_x=$vs_x;
var vs_y=$vs_y;
var ps_x_org=ps_x;
var vs_x_org=vs_x;
var timespeed=100;
var fcount=0;
var attacktimes=5;
var actiondown=0;
var flash_x,flash_y;
var flash_width=81;
var flash_height=83;
var bgflash_counter=6;
var dieflash_x,dieflash_y;
var shark_counter=10;
var diefontsize=50;
var Fresh_counter=10;
var IsHit=0;
var ps_speed_x=30;
var vs_speed_x=30;
var vs_backtime=30;
var ps_backtime=30;
var light_type="dieflash";
var sound_switch=1;
var vsbig=1;plbig=1;

var ps_weapon_type_img = "ps_weapon_a";
var ps_weapon_width=document.images['weapon_a'].width;
var ps_weapon_height=document.images['weapon_a'].height;

var vs_weapon_type_img = "vs_weapon_a";
var vs_weapon_width=document.images['weapon_a'].width;
var vs_weapon_height=document.images['weapon_a'].height;

var dieflash_width=document.images['boom1'].width;
var dieflash_height=document.images['boom1'].height;

document.images['vsimg'].width=document.images['vsimg'].width*vsbig;
document.images['vsimg'].height=document.images['vsimg'].height*vsbig;
document.images['plimg'].width=document.images['plimg'].width*plbig;
document.images['plimg'].height=document.images['plimg'].height*plbig;

var vsWidth=document.images['vsimg'].width;
var plWidth=document.images['plimg'].width;

var vsHeight=document.images['vsimg'].height;
var plHeight=document.images['plimg'].height;

var HeightDifferent=plHeight-vsHeight;

var lightspeed=2000;
var light_x=1;
var light_width=document.images['yelllight'].width;
var light_height=document.images['yelllight'].height;

if (HeightDifferent > 0)
{
ps_y=ps_y+HeightDifferent;
}
else
{
vs_y=vs_y+HeightDifferent;
}		


function prv_fun_sound(theobj)
{
if (sound_switch == 0 ) return;
var mysound= eval("document.all."+theobj);
mysound.src=ko_sound;
}



function gobal_fun_get_random(num_area)
{
var rnd=Math.random()*10000*Math.random();
return (Math.floor(rnd%num_area));
}   


function dieword_size()
{
if (diefontsize > 120)
{
return;
}	
diefontsize=diefontsize+21;
document.all["dieword"].style.fontSize=diefontsize;
document.all["dieword"].style.visibility="visible";

if ((diefontsize % 2) == 0)
{
visible_object("dieword");
}
else
{
hidden_object("dieword");
}	

setTimeout('dieword_size()',45);  
}	

function bgcolor_change()
{
 document.bgColor=gobal_fun_get_random(999999);
 if (bgflash_counter > 0)
   {
    bgflash_counter--;
    document.bgColor="ffffff";
    setTimeout('bgcolor_change()',5);  
   }
}	

function gobal_fun_moveto(objectName,x,y)
{
eval('document.all["'+objectName+'"].style'+'.top='+y);
eval('document.all["'+objectName+'"].style'+'.left='+x);
}

function hidden_object(objectName)
{
eval('document.all["'+objectName+'"].style'+'.visibility="hidden";');
}

function visible_object(objectName)
{
eval('document.all["'+objectName+'"].style'+'.visibility="visible";');
}

function fliph_object(objectName)
{
eval('document.all["'+objectName+'"].style'+'.filter="fliph()";');
}


function lightFight()
{
light_width=light_width+10;
light_height=light_height+.5;
light_x=light_x+2;


document.images['yelllight'].width=light_width;
document.images['yelllight'].height=light_height;
if (light_width < 800)
{
lightspeed=lightspeed-300;
setTimeout('lightFight()',lightspeed);
}

}	


function shark(longtime,strong)
{
shark_counter--;
var shark_x=gobal_fun_get_random(strong);
var shark_y=gobal_fun_get_random(strong+5);
window.moveTo(shark_x,shark_y); 
if (shark_counter > 1)
{
setTimeout('bgcolor_change()',longtime);  
}
}


function PlaySound(SoundID,SoundFileName)
{

if (SoundID == "ko" )
	{
 	if (sound_switch ==1)
 	{
 	document.all.wigwag.src=SoundFileName;
 	document.all.wigwag.play=1;
 	sound_switch =0;
 	}
	}
if (SoundID == "boom" )
	{
 	document.all.boomsound.src=SoundFileName;
 	document.all.boomsound.play=1;
 	}

if (SoundID == "backbg" )
	{
 	document.all.background_mus.src=SoundFileName;
 	document.all.background_mus.play=1;
 	}

}

function fighter()
{



if ("$Pl_W[0]" == "�Ҥ������`�ӼC")
{
 ps_weapon_type_img="ps_god_sword";
 ps_weapon_height=document.images['god_sword'].height;
 ps_weapon_width=document.images['god_sword'].width;
}
if ("$Vs_W[0]" == "�Ҥ������`�ӼC")
{
 vs_weapon_type_img="vs_god_sword";
 vs_weapon_height=document.images['god_sword'].height;
 vs_weapon_width=document.images['god_sword'].width;
}

if  (actiondown==0)
{
if ("$Pl_MsnStyle" == "���q����")
{
 ps_speed_x=30;
 vs_speed_x=30;
 attacktimes=6;
 light_type="dieflash";
}

if ("$Pl_MsnStyle" == "����")
{
 ps_speed_x=70;
 vs_speed_x=10;
 attacktimes=2;
 light_type="attacklight";
}

if ("$Pl_MsnStyle" == "���m")
{
 ps_speed_x=10;
 vs_speed_x=40;
 attacktimes=3;
 light_type="attacklight";
 fliph_object(light_type);
}


if ("$Pl_MsnStyle" == "���u����")
{
 ps_speed_x=20;
 vs_speed_x=40;
 attacktimes=6;
 light_type="attacklight";
 fliph_object(light_type);
}



if ("$Pl_MsnStyle" == "����")
 {
 ps_speed_x=150;
 vs_speed_x=10;
 attacktimes=2;
 light_type="attacklight";
 }

if ("$Pl_MsnStyle" == "�{��")
{
 ps_speed_x=300;
 vs_speed_x=40;
 attacktimes=4;
 light_type="attacklight";
 fliph_object(light_type);
}


if ("$Pl_MsnStyle" == "����")
 {
 ps_weapon_height=document.images['god_sword'].height;
 ps_weapon_width=document.images['god_sword'].width;
 ps_weapon_type_img = "ps_god_sword";
 ps_speed_x=30;
 vs_speed_x=30;
 attacktimes=6;
 light_type="attacklight";
 }

if ("$Pl_MsnStyle" == "�t�̤���")
 {
 lightFight();
 ps_speed_x=0;
 
 if (light_width >vs_x)
 {
 vs_speed_x=vs_speed_x-20;
 gobal_fun_moveto('vslosehp',vs_x,vs_y-50);
 }
 
 attacktimes=1;
 light_type="attacklight";
 gobal_fun_moveto('yell_light',ps_x+plWidth+20+light_x,ps_y+20-light_height/2);
if (vs_x > 800)
{
 IsHit=1;
}

 }




ps_x=ps_x+ps_speed_x;
vs_x=vs_x-vs_speed_x;


if (ps_x > vs_x)
{
 ps_x=ps_x-(ps_speed_x+ps_backtime);
 vs_x=vs_x+(vs_speed_x+vs_backtime);
 IsHit=1;
}


//=SHOW WEAPON ATTACK

 vs_flash_x=((vs_x+vs_x)/2)-(flash_width/2)+50;
 vs_flash_y=((vs_y+vs_y)/2);


//==PS WEAPON 

 if (ps_weapon_type_img == "ps_weapon_a")
 {
  ps_weapon_x=ps_x+flash_width-20;
  ps_weapon_y=ps_y+vs_weapon_height+20;
 } 	

 if (ps_weapon_type_img == "ps_god_sword")
 {
  ps_weapon_x=ps_x+ps_weapon_width-20;
  ps_weapon_y=ps_y;
 } 	

//====VS WEAPON

 if (vs_weapon_type_img == "vs_weapon_a")
 {
  vs_weapon_x=vs_x-vs_weapon_width+20;
  vs_weapon_y=vs_y+vs_weapon_height+20;
 } 	
 if (vs_weapon_type_img == "vs_god_sword")
 {
  vs_weapon_x=vs_x-vs_weapon_width+20;
  vs_weapon_y=vs_y;
 } 	

//=SHOW WEAPON ATTACK=END=====

gobal_fun_moveto('psbody',ps_x,ps_y);
gobal_fun_moveto('vsbody',vs_x,vs_y);
gobal_fun_moveto(ps_weapon_type_img,ps_weapon_x,ps_weapon_y);
gobal_fun_moveto(vs_weapon_type_img,vs_weapon_x,vs_weapon_y);

}


if ((IsHit == 1) && (fcount < attacktimes) && (actiondown==0))
{
 fcount++;
 timespeed=500;

 flash_x=((ps_x+vs_x)/2)-(flash_width/2)+50;
 flash_y=((ps_y+vs_y)/2);
 
 if (($ps_die == 1 ) || ($vs_die == 1 ))
 {
 
  dieflash_x =flash_x;
  dieflash_y =flash_y;

if ("$Pl_MsnStyle" == "���q����")
{
  dieflash_x =flash_x;
  dieflash_y =flash_y;
  PlaySound("boom",boom1_sound); 	
}
if ("$Pl_MsnStyle" == "����")
 {
  dieflash_x =flash_x-100;
  dieflash_y =flash_y-20;
  PlaySound("boom",boom2_sound); 	

 }

if ("$Pl_MsnStyle" == "���m")
 {
  dieflash_x =flash_x-30;
  dieflash_y =flash_y-20;
  PlaySound("boom",boom2_sound); 	

  }

if ("$Pl_MsnStyle" == "���u����")
 {
  dieflash_x =flash_x-30;
  dieflash_y =flash_y-20;
  PlaySound("boom",boom2_sound); 	

  }

if ("$Pl_MsnStyle" == "����")
 {
  dieflash_x =flash_x-100;
  dieflash_y =flash_y-20;
  PlaySound("boom",boom2_sound); 	

  }

if ("$Pl_MsnStyle" == "�{��")
 {
  dieflash_x =flash_x-30;
  dieflash_y =flash_y-20;
  hidden_object('psbody');
  PlaySound("boom",boom3_sound); 	

  }

if ("$Pl_MsnStyle" == "����")
 {
   dieflash_x =flash_x-100;
   dieflash_y =flash_y-20;
   PlaySound("boom",boom4_sound); 	

 }
  
  if (actiondown==0 ) 
  {
   	gobal_fun_moveto(light_type,dieflash_x,dieflash_y);
   
	if ((attacktimes-fcount)<2  )
	{
  	dieword_size();
  	gobal_fun_moveto('dieword',flash_x-(diefontsize/2)-40,flash_y-20);
	}  
   
  }
  
 }

}	

if (fcount >= attacktimes)
{
 ps_x=ps_x_org;
 vs_x=vs_x_org;
 hidden_object(ps_weapon_type_img);
 hidden_object(vs_weapon_type_img);
 actiondown=1 ;
}	


if (actiondown== 1)
{

 if ($ps_die == 1 )
 {


	PlaySound("ko",ko_sound);

  	ps_x=ps_x_org;
  	vs_x=vs_x_org;

  
  	hidden_object("psbody");
  	gobal_fun_moveto('diebody',ps_x,ps_y);
 }	


 if ($vs_die == 1)
 {
 	if (sound_switch ==1)
 	{
         PlaySound("ko",ko_sound); 	
         }
 
 	ps_x=ps_x_org;
 	vs_x=vs_x_org;
 	hidden_object("vsbody");
 	gobal_fun_moveto('diebody',vs_x,vs_y);
 }	

gobal_fun_moveto('vsbody',vs_x,vs_y);
gobal_fun_moveto('psbody',ps_x,ps_y);

document.bgColor="000000";

hidden_object(light_type);
hidden_object(ps_weapon_type_img);
hidden_object(vs_weapon_type_img);
hidden_object("dieword");
hidden_object("yell_light");
hidden_object("vslosehp");
hidden_object("pllosehp");

//AutoFreshFrame();
}
setTimeout('fighter()',timespeed);
}

PlaySound("backbg",fightbg1_sound);
fighter();

//-->
</script>         
</body>
</html>

	-----END-----
