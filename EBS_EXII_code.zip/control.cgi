#!/usr/bin/perl

#ver.5
#�]�w
$SCRIPTNM="control.cgi";    #�ɮצW��
$USERDATA="backup/backup.dat";        #�ϥΪ̸�ƳƤ�


require 'ebs_sub1.cgi';
require "debug_sub.pl";


&ERROR('�Ф��n�����q���a�}�i�J','�w���_���бq�z�X�ݪ������i�J') if $ENV{'HTTP_REFERER'} !~ m/^$THIS_DIR/ && $DIRECT_LINK && $SUB ne 'MY_LIST' && $SUB ne 'C_LIST';


&record_fight(""," ","���H�n�i�J�޲z�Y��");

!$SUB && ($SUB='MAINTE');
&$SUB;



sub MAINTE		{&MAINTENANCE;}
sub MAINTE2		{&MAINTENANCE2;}

sub idadmin             {&MASTER1;}
sub miulerebsadmin      {&MASTER2;}
sub SYUSEI		{&SYUSEI2;}
sub TYOUSEI		{&TYOUSEI2;&SYUSEI2;}

sub BACKUP              {&BACKUP2;}
sub DATAUP{&DATAUP2;}
sub HUKUGEN		{&SYUSEI4;}
sub SYUUHUKU		{&TYOUSEI2;&SYUSEI4;}

sub COUNTRY             {&COUNTRY2;}
sub HENSYU		{&HENSYU2;}
sub KAIZAN		{&KAIZAN2;&HENSYU2;}

sub COOKIES              {&COOKIES2;}
sub DEL		{&DEL2;&COOKIES2;}

sub MAINTENANCE{

	&HEADER2;

	print << "	-----END-----";
	<table width=100% height=100%><tr><td align=center>
		<table border=0 cellpadding=0 cellspacing=0 bgcolor="#909090" align=center
		 style="border:1px outset #909090;font-size:16px;">
		<form action=$SCRIPTNM method=POST><input type=hidden name="cmd" value="MAINTE2">
		<tr><td style="background-color:#404040;font=16px" colspan=2 align=center>
		���ź޲z����</td></tr>
		<tr><td align=center><b style="color:#f13214;">PaSsWoRd</b></td>
		<td><input type=password name="pass" style="height:21px; color:#ffffff; font-size:16px; background:#000000; border:1 inset #c0c0c0;">
		<input type=submit value=Login class=button2 onMouseOver=\"style.color='#000000';style.background='#adff2f';\" onMouseOut=\"this.style.color='#adff2f';style.background='#00550c';\">
		</td></tr></form></table>
	<form action=$MAIN_SCRIPT method=POST>
	<input type=submit value=��^ class=button2 onMouseOver=\"style.color='#000000';style.background='#adff2f';\" onMouseOut=\"this.style.color='#adff2f';style.background='#00550c';\">&nbsp;&nbsp;
	<input type=button value="�w�]�޲z����" class=button2 onMouseOver=\"style.color='#000000';style.background='#adff2f';\" onMouseOut=\"this.style.color='#adff2f';style.background='#00550c';\" onClick="parent.top.location.replace('ebs.cgi?MAINTE')">
	</form>
	</td></tr></table>

	-----END-----
}
sub MAINTENANCE2{
	&ERROR('�K�X���~�I�I') if $MASTER_PWD ne "$FORM{'pass'}";

	&HEADER;
	&record_fight(""," ","���H�w�i�J�޲z�Y��");
	
	print << "	-----END-----";
	<form action=$SCRIPTNM method=POST name=mainte>
	<input type=hidden name="cmd"><input type=hidden name="pass" value="$FORM{'pass'}">
	<table width=100% height=100%><tr><td align=center>

	<table class=font9 cellspacing=2 cellpadding=3 bgcolor="#909090">
		<tr><td bgcolor=#404040 colspan=3><center><b>�޲z�ﶵ</b></center></td></tr>

<tr><td bgcolor=#404040 align=center>�H����ƭק�</td>
        <td style="border:1px solid #404040;font-size:12px;color:#000000;">�u�C�XID�C</td>
        <td style="border:1px solid #404040;"><input type=submit value="GO" class=button2 onMouseOver=\"style.color='#000000';style.background='#adff2f';\" onMouseOut=\"this.style.color='#adff2f';style.background='#00550c';\" onClick="mainte.cmd.value='idadmin'"></td>
        </tr>

        <tr><td bgcolor=#404040 align=center>�H����ƭק�</td>
        <td style="border:1px solid #404040;font-size:12px;color:#000000;">�C�X�ԲӤH������ơC</td>
        <td style="border:1px solid #404040;"><input type=submit value="GO" class=button2 onMouseOver=\"style.color='#000000';style.background='#adff2f';\" onMouseOut=\"this.style.color='#adff2f';style.background='#00550c';\" onClick="mainte.cmd.value='miulerebsadmin'"></td>
        </tr>

        <tr><td bgcolor=#404040 align=center>��a��ƭק�</td>
        <td style="border:1px solid #404040;font-size:12px;color:#000000;">�i�H�ק�U�ꪺ��ơC</td>
        <td style="border:1px solid #404040;"><input type=submit value="GO" class=button2 onMouseOver=\"style.color='#000000';style.background='#adff2f';\" onMouseOut=\"this.style.color='#adff2f';style.background='#00550c';\" onClick="mainte.cmd.value='COUNTRY'"></td>
        </tr>

        <tr><td bgcolor=#404040 align=center>�ɮ׾ɥX</td>
        <td style="border:1px solid #404040;font-size:12px;color:#000000;">��ƾɥX�C</td>
        <td style="border:1px solid #404040;"><input type=submit value="GO" class=button2 onMouseOver=\"style.color='#000000';style.background='#adff2f';\" onMouseOut=\"this.style.color='#adff2f';style.background='#00550c';\" onClick="mainte.cmd.value='BACKUP'"></td>
        </tr>
        <tr><td bgcolor=#404040 align=center>�ɮ׾ɤJ</td>
        <td style="border:1px solid #404040;font-size:12px;color:#000000;">��ƾɤJ�C</td>
        <td style="border:1px solid #404040;"><input type=submit value="GO" class=button2 onMouseOver=\"style.color='#000000';style.background='#adff2f';\" onMouseOut=\"this.style.color='#adff2f';style.background='#00550c';\" onClick="mainte.cmd.value='DATAUP'"></td>
        </tr>

        <tr><td bgcolor=#404040 align=center>���a�޲z</td>
        <td style="border:1px solid #404040;font-size:12px;color:#000000;">�ѥ[�̫d�������M��\��</td>
        <td style="border:1px solid #404040;"><input type=submit value="GO" class=button2 onMouseOver=\"style.color='#000000';style.background='#adff2f';\" onMouseOut=\"this.style.color='#adff2f';style.background='#00550c';\" onClick="mainte.cmd.value='COOKIES'"></td>
        </tr>

	</table></form>
	<form action=$MAIN_SCRIPT method=POST>
	<input type=submit value=��^ class=button2 onMouseOver=\"style.color='#000000';style.background='#adff2f';\" onMouseOut=\"this.style.color='#adff2f';style.background='#00550c';\">
	</form>
	</td></tr></table>

	-----END-----
	&FOOTER;

}

sub MASTER1{
&ERROR('�K�X���~�I�I') if $MASTER_PWD ne "$FORM{'pass'}";
&HEADER2;
&DBM_INPORT(P);
print << "-----END-----";
	<script language="JavaScript">
		function syusei(nm){
			fm1.plname.value=nm;
			fm1.sbm1.click();
		}

	</script>
	<form action=$SCRIPTNM method=POST name=fm1 style="position:absolute;visibility:hidden;">
	<input type=hidden name="cmd" value=SYUSEI>
	<input type=hidden name="plname">
	<input type=hidden name="pass" value="$FORM{'pass'}">
	<input type=submit name="sbm1">
        </form>
<center><table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="50%">
<tr><td width="50%" align="right">�b��</td><td width="50%" align="left"> <--�ާ@</td></tr>

-----END-----
while (my($key,$val) = each %P){
@VALS = split(/\s/,$val);$ET++;
print "<tr><td width=50% align=right>$key</td><td width=50% align=left>&nbsp;<a href=javascript:syusei(\"$key\")><--�ץ�</a></td></tr>";
}

print << "-----END-----";

<form action=$SCRIPTNM method=POST>
<input type=hidden name="cmd" value="MAINTE">
<input type=hidden name="pass" value=\"$FORM{'pass'}\"><tr><td algin=center>
<input type=submit value=��^ class=button2 onMouseOver=\"style.color='#000000';style.background='#adff2f';\" onMouseOut=\"this.style.color='#adff2f';style.background='#00550c';\">
</table></center>
-----END-----
&FOOTER;
print "</td></tr></table></form></body>";
}

sub MASTER2{
&ERROR('�K�X���~�I�I') if $MASTER_PWD ne "$FORM{'pass'}";
&HEADER2;
&DBM_INPORT(P);
print << "-----END-----";
	<script language="JavaScript">
		function syusei(nm){
			fm1.plname.value=nm;
			fm1.sbm1.click();
		}

	</script>
	<form action=$SCRIPTNM method=POST name=fm1 style="position:absolute;visibility:hidden;">
	<input type=hidden name="cmd" value=SYUSEI>
	<input type=hidden name="plname">
	<input type=hidden name="pass" value="$FORM{'pass'}">
	<input type=submit name="sbm1">
        </form>
<table width=100% height=100%><tr><td align=left>
�m�˯�����\:<a href="http://www12.big.or.jp/~kazu777/">kazu777</a>�n
<form onSubmit="return seek_str(this.strings.value);">
��J�n�j�������e�C
<input name=strings type=text size=15 onChange="n = 0;">
<input type=submit value="�˯�">
</form>
<table cellspacing=2 cellpadding=3 bgcolor="#909090" style="font-size:16px;" border=1>
<tr><td bgcolor=#404040 colspan=37>�H����ƭק�<tr><td>�s��</td><td>$c </td><td>�b��</td><td>����</td><td>�Ծ�</td><td>PASS</td><td>MS��</td><td>������</td><td>���ݰ�</td><td>�ꤺ</td><td>�o��</td><td>���</td><td>�Z��</td><td>\�w\��1</td><td>\�w\��2</td><td>�ʮ�</td><td>��</td><td>�Z���g��</td><td>HP</td><td>MAXHP</td><td>EN</td><td>MAXEN</td><td>�����O</td><td>���m�O</td><td>�ӱ���</td><td>�R���v</td><td>��y�^��</td><td>���m</td><td>�ײz���A</td><td>�ɶ�</td><td>�e��</td><td>����</td><td>����</td><td>�g��</td><td>�԰��^��</td><td>�ӧQ��</td><td>���</td></tr>

-----END-----
while (my($key,$val) = each %P){
@VALS = split(/\s/,$val);$ET++;
print "<tr><td>$ET</td><td>$c </td><td>$key</td><td>$VALS[0]</td><td>$VALS[1]</td><td>$VALS[2]</td><td>$VALS[3]</td><td>$VALS[4]</td><td>$VALS[5]</td><td>$VALS[6]</td><td>$VALS[7]</td><td>$VALS[8]</td><td>$VALS[9]</td><td>$VALS[10]</td><td>$VALS[11]</td><td>$VALS[12]</td><td>$VALS[13]</td><td>$VALS[14]</td><td>$VALS[15]</td><td>$VALS[16]</td><td>$VALS[17]</td><td>$VALS[18]</td><td>$VALS[19]</td><td>$VALS[20]</td><td>$VALS[21]</td><td>$VALS[22]</td><td>$VALS[23]</td><td>$VALS[24]</td><td>$VALS[25]</td><td>$VALS[26]</td><td>$VALS[27]</td><td>$VALS[28]</td><td>$VALS[29]</td><td>$VALS[30]</td><td>$VALS[32]</td><td>$VALS[33]</td><td><a href=javascript:syusei(\"$key\")>�ץ�</a></td></tr>";
}

print << "-----END-----";

<form action=$SCRIPTNM method=POST>
<input type=hidden name="cmd" value="MAINTE2">
<input type=hidden name="pass" value=\"$FORM{'pass'}\"><tr><td colspan=37>
<input type=submit value=��^ class=button2 onMouseOver=\"style.color='#000000';style.background='#adff2f';\" onMouseOut=\"this.style.color='#adff2f';style.background='#00550c';\">
</td></tr></table>
-----END-----
&FOOTER;
print "</td></tr></table></form></body>";
}

sub SYUSEI2{
&ERROR('�K�X���~�I�I') if $MASTER_PWD ne "$FORM{'pass'}";
&HEADER2;
&DBM_INPORT(P);

@VALS = split(/\s/,$P{"$FORM{'plname'}"});

print << "-----END-----";

	<script language="JavaScript">
		function tyousei(nm){
			fm1.plname.value=nm;
			fm1.sbm1.click();
		}

	</script>

<form action=$SCRIPTNM method=POST name=fm1>
<center><input type=hidden name="cmd" value=TYOUSEI>
	<input type=hidden name="plname">
	<input type=hidden name="pass" value="$FORM{'pass'}">
	<input type=submit name="sbm1" class=button2 onMouseOver=\"style.color='#000000';style.background='#adff2f';\" onMouseOut=\"this.style.color='#adff2f';style.background='#00550c';\"></center>

-----END-----
print << "-----END-----";

<table border=0 cellpadding=0 cellspacing=0 style="border-collapse: collapse" bordercolor=#111111 width=100%><tr>
<td width=33%>
<center><DIV style="FILTER: dropshadow(offx=8,offy=8,color=#000000); POSITION: relative; HEIGHT: 110px">
<TABLE cellSpacing=0 cellPadding=0><TBODY><tr>
<TD style="BORDER-RIGHT: #89a078 2px solid; BORDER-TOP: #89a078 2px solid; FONT-SIZE: 15px; BORDER-LEFT: #89a078 2px solid; COLOR: #efef80; BORDER-BOTTOM: medium none" noWrap align=middle width=120 bgColor=#000000>$FORM{'plname'}</TD>
<TD style="BORDER-RIGHT: #23a012 1px solid; BORDER-TOP: #23a012 1px solid; FONT-SIZE: 15px; BORDER-LEFT: medium none; BORDER-BOTTOM: #89a078 2px solid; BACKGROUND-COLOR: #000000" width=70 align=middle>$VALS[0]<input class=button1 type=text name="para0" value="$VALS[0]" size="3"></TD></TR><tr>
<TD style="BORDER-RIGHT: #89a078 2px solid; PADDING-RIGHT: 4px; BORDER-TOP: medium none; PADDING-LEFT: 4px; PADDING-BOTTOM: 4px; BORDER-LEFT: #89a078 2px solid; PADDING-TOP: 4px; BORDER-BOTTOM: #89a078 2px solid" bgColor=#000000 colSpan=2>
<TABLE style="FONT-SIZE: 13px; COLOR: #d0d0d0" cellSpacing=0 cellPadding=0><TBODY><tr>
<TD align=right><a href=ebs.cgi?ICON2 target=face><img border=0 src="$IMG_FOLDER3/$VALS[100].gif"></a><br>
<input class=button1 type=text name="para100" value="$VALS[100]" size="5"></TD>
<TD class=num style="COLOR: #efef80" noWrap align=right colSpan=2>$STATUS_NAME[0]:&nbsp;$VALS[24]<br>$STATUS_NAME[1]:<input class=button1 type=text name="para24" value="$VALS[24]" size="5"><br>$STATUS_NAME[2]:$VALS[23]<input class=button1 type=text name="para23" value="$VALS[23]" size="5"></TD></TR><tr>
<SPAN><TD align=right>$STATUS_NAME[3]</TD>
<SPAN><TD class=num style="COLOR: #efef80" noWrap align=right colSpan=2><B>$VALS[5]</B><br>
<input class=button1 type=text name="para5" value="$VALS[5]" size="10"></TD></tr><tr>
<TD noWrap align=right>$STATUS_NAME[4]</TD>
<TD noWrap width=30><B class=num>$VALS[29]</B></TD>
<TD noWrap align=right width=70><input class=button1 type=text name="para29" value="$VALS[29]" size="5"></TD></TR><tr>
<TD noWrap>$STATUS_NAME[5]</TD>
<TD noWrap>$VALS[14]</TD>
<TD noWrap align=right><input class=button1 type=text name="para14" value="$VALS[14]" size="5"></TD></TR><tr>
<TD noWrap align=right>$STATUS_NAME[6]</TD>
<TD class=num noWrap align=middle colSpan=2>$VALS[12]<input class=button1 type=text name="para12" value="$VALS[12]" size="5"></TD></TR><tr>
<TD noWrap align=right>$STATUS_NAME[13]</TD>
<TD class=num noWrap align=middle colSpan=2>$VALS[32]<input class=button1 type=text name="para32" value="$VALS[32]" size="5"></TD></TR><tr>
<TD noWrap align=right>$STATUS_NAME[14]</TD>
<TD class=num noWrap align=middle colSpan=2>$VALS[33]<input class=button1 type=text name="para33" value="$VALS[33]" size="5"></TD></TR><tr>
<TD noWrap align=right>�C��</TD>
<TD class=num noWrap align=middle colSpan=2><font color=$VALS[13]>COLOR</font>: <input class=button1 type=text name="para13" value="$VALS[13]" size="5"></TD></TR><tr>
<TD noWrap align=right>$STATUS_NAME[7]</TD>
<TD class=num noWrap align=middle colSpan=2><b>$VALS[6]<input class=button1 type=text name="para6" value="$VALS[6]" size="5"></b></TD></TR><tr>
<SPAN><TD noWrap align=right>$STATUS_NAME[8]</TD>
<SPAN><TD class=num noWrap align=middle colSpan=2>$VALS[8]<input class=button1 type=text name="para8" value="$VALS[8]" size="5"></TD>
</tr></TBODY></TABLE></TD></TR></TBODY></TABLE></DIV></center></td>


<td width=34% rowspan=3>
<table border=3 cellpadding=0 cellspacing=0 style="border-collapse: collapse" width=95% bgcolor=#000000 bordercolor=#008080>
<tr><td width=100% align=center>�K�X:<input class=button1 class=button1 type=text name="para2" value="$VALS[2]" size="10"><br>
<a href=ebs.cgi?ICON target=face><img border=0 src=$IMG_FOLDER2/$VALS[27].gif></a><br>
<input class=button1 class=button1 type=text name="para27" value="$VALS[27]" size="5"><br>
<font size=3>&nbsp;<b>$VALS[3]</b></font><br>
<input class=button1 type=text name="para3" value="$VALS[3]" size="20"></td></tr></table>
<b>$STATUS_NAME[9]</b><br>$VALS[1]<br>
<b>�԰��o��</b><br>$VALS[7]<br>
<input class=button1 type=text name="para7" value="$VALS[7]" size="20"></td>


<td width=33%>
<center><DIV style="FILTER: dropshadow(offx=8,offy=8,color=#000000); POSITION: relative; HEIGHT: 140px">
<TABLE cellSpacing=0 cellPadding=0><TBODY><TR>
<TD style="BORDER-RIGHT: #89a078 2px solid; BORDER-TOP: #89a078 2px solid; FONT-SIZE: 15px; BORDER-LEFT: #89a078 2px solid; COLOR: #efef80; BORDER-BOTTOM: medium none" noWrap align=middle width=50 bgColor=#000000>ARMS</TD>
<TD style="PADDING-RIGHT: 1px; PADDING-LEFT: 0px; PADDING-BOTTOM: 1px; PADDING-TOP: 1px; BORDER-BOTTOM: #89a078 2px solid" width=150>
<SPAN style="BORDER-RIGHT: #23a012 1px solid; BORDER-TOP: #23a012 1px solid; FONT-SIZE: 16px; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none; BACKGROUND-COLOR: #000000">
<B>�Z���P�ޯ��˩w</B></SPAN></TD></TR><TR>
<TD style="BORDER-RIGHT: #89a078 2px solid; BORDER-TOP: medium none; BORDER-LEFT: #89a078 2px solid; BORDER-BOTTOM: medium none; BACKGROUND-REPEAT: no-repeat" vAlign=top bgColor=#000000 colSpan=3 height=70>
<TABLE style="FONT-SIZE: 14px; LINE-HEIGHT: 16px" cellSpacing=0 cellPadding=0 $right><TBODY><TR>
<TD rowSpan=4>
	<center><table cellpadding=0 cellspacing=0 border=0>
	<tr><td width=30 height=30 $right valign=bottom background="$IMG_FOLDER1/btl.gif">
	<img src='$IMG_FOLDER1/tl.gif' width=$AT height=$DE $fil></td>
	<td width=30 height=30 align=left valign=bottom background="$IMG_FOLDER1/btr.gif">
	<img src='$IMG_FOLDER1/tr.gif' width=$SP height=$DE $fil></td></tr>
	<tr><td width=30 height=30 $right valign=top background="$IMG_FOLDER1/bbl.gif">
	<img src='$IMG_FOLDER1/bl.gif' width=$AT height=$MT $fil></td>
	<td width=30 height=30 align=left valign=top background="$IMG_FOLDER1/bbr.gif">
	<img src='$IMG_FOLDER1/br.gif' width=$SP height=$MT $fil></td></tr></table></center></TD>
	<TD $right width=27><IMG src=images/fight.gif></TD>
<TD class=num noWrap width=25><B>��$VALS[19]</B></TD>
<TD $right width=20><IMG src=images/gu.gif></TD>
<TD class=num noWrap><B>��$VALS[20]</B></TD><TD noWrap $right>
<input class=button1 type=text name="para19" value="$VALS[19]" size="5"><input class=button1 type=text name="para20" value="$VALS[20]" size="5"></TD></TR><TR>
<TD $right><IMG src=images/short.gif></TD><TD class=num noWrap><B>�R$VALS[22]</B></TD>
<TD $right height=16><IMG src=images/speed.gif></TD>
<TD class=num noWrap><B>�t$VALS[21]</B></TD>
<TD noWrap $right>
<input class=button1 type=text name="para22" value="$VALS[22]" size="5"><input class=button1 type=text name="para21" value="$VALS[21]" size="5"></TD></TR><TR>
<TD align=middle><IMG src=images/long.gif></TD>
<TD class=num noWrap $right><B>--</B></TD>
<TD align=middle><IMG src=images/cpu.gif></TD>
<TD class=num noWrap $right><B>Piii 500*2</B></TD><TD></TD></TR><TR>
<TD class=num noWrap $right colSpan=5>
<B>-----</B></TD></TR></TBODY></TABLE></TD></TR><TR>
<TD style="BORDER-RIGHT: #89a078 2px solid; BORDER-TOP: medium none; FONT-SIZE: 12px; BORDER-LEFT: #89a078 2px solid; BORDER-BOTTOM: #89a078 2px solid; BACKGROUND-REPEAT: no-repeat" bgColor=#000000 colSpan=2>
<DIV><TABLE $tb_kill bgColor=#000000><font color=#99fffff>&nbsp;<b>$STATUS_NAME[10]</b></a></font>&nbsp;&nbsp;&nbsp;<font color=ffffff>$VALS[39]</font></TABLE>
<input class=button1 type=text name="para39" value="$VALS[39]" size="20">
<TABLE $tb_kill bgColor=#000000><font color=#990000>&nbsp;<b>$STATUS_NAME[11]</b></a></font>&nbsp;&nbsp;&nbsp;<font color=ffffff>$VALS[66]</font></TABLE>
<input class=button1 type=text name="para66" value="$VALS[66]" size="20"><br>
&nbsp;&nbsp;�ƪZ1&nbsp;&nbsp;<b>$VALS[10]</b><input class=button1 type=text name="para10" value="$VALS[10]" size="8"><br>
&nbsp;&nbsp;�ƪZ2&nbsp;&nbsp;<b>$VALS[11]</b><input class=button1 type=text name="para11" value="$VALS[11]" size="8"><br>
&nbsp;&nbsp;�ƪZ3&nbsp;&nbsp;<b>$VALS[98]</b><input class=button1 type=text name="para98" value="$VALS[98]" size="8"><br>
&nbsp;&nbsp;�ƪZ4&nbsp;&nbsp;<b>$VALS[99]</b><input class=button1 type=text name="para99" value="$VALS[99]" size="8"><br>
&nbsp;&nbsp;����&nbsp;&nbsp;<b>$VALS[28]</b><input class=button1 type=text name="para28" value="$VALS[28]" size="8"><br>
&nbsp;&nbsp;�ײz���A<b>$VALS[25]</b><input class=button1 type=text name="para25" value="$VALS[25]" size="8"><br>
</div></TD></TR></TBODY></TABLE></DIV></center></td>
</tr><tr><td width=33%></td><td width=4%></td>

</tr><tr>
<td width=33%>
<DIV style="FILTER: dropshadow(offx=8,offy=8,color=#000000); POSITION: relative; HEIGHT: 50px">
<TABLE cellSpacing=0 cellPadding=0><TBODY><TR>
<TD style="BORDER-RIGHT: #89a078 2px solid; BORDER-TOP: #89a078 2px solid; FONT-SIZE: 15px; BORDER-LEFT: #89a078 2px solid; COLOR: #efef80; BORDER-BOTTOM: medium none" noWrap align=middle width=50 bgColor=#000000 onclick=SK(3);>HP</TD>
<TD style="PADDING-RIGHT: 1px; PADDING-LEFT: 0px; PADDING-BOTTOM: 1px; PADDING-TOP: 1px; BORDER-BOTTOM: #89a078 2px solid" width=140><SPAN style="BORDER-RIGHT: #23a012 1px solid; BORDER-TOP: #23a012 1px solid; FONT-SIZE: 16px; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none; BACKGROUND-COLOR: #000000">
<b>$VALS[15]</b>/<B>$VALS[16]</B>[��]<br>
<input class=button1 type=text name="para15" value="$VALS[15]" size="5">
<input class=button1 type=text name="para16" value="$VALS[16]" size="5">
</TD></TR><TR>
<TD style="BORDER-RIGHT: #89a078 2px solid; PADDING-RIGHT: 4px; BORDER-TOP: medium none; PADDING-LEFT: 4px; PADDING-BOTTOM: 4px; BORDER-LEFT: #89a078 2px solid; PADDING-TOP: 4px; BORDER-BOTTOM: #89a078 2px solid" width=208 bgColor=#000000 colSpan=2><IMG height=10 width=208 src=images/mater.gif></TD>
</TR></TBODY></TABLE></DIV>

<DIV style="FILTER: dropshadow(offx=8,offy=8,color=#000000); POSITION: relative; HEIGHT: 50px">
<TABLE cellSpacing=0 cellPadding=0><TBODY><TR>
<TD style="BORDER-RIGHT: #89a078 2px solid; PADDING-RIGHT: 4px; BORDER-TOP: #89a078 2px solid; PADDING-LEFT: 4px; PADDING-BOTTOM: 4px; BORDER-LEFT: #89a078 2px solid; PADDING-TOP: 4px; BORDER-BOTTOM: medium none" width=208 bgColor=#000000 colSpan=2><IMG height=10 width=208 src=images/mater.gif></TD></TR><TR>
<TD style="PADDING-RIGHT: 1px; BORDER-TOP: #89a078 2px solid; PADDING-LEFT: 0px; PADDING-BOTTOM: 1px; PADDING-TOP: 1px" $right width=150>
<SPAN style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; FONT-SIZE: 16px; BORDER-LEFT: #23a012 1px solid; BORDER-BOTTOM: #23a012 1px solid; BACKGROUND-COLOR: #000000">
<b>$VALS[17]</b>/<B>$VALS[18]</B></SPAN><br>
<input class=button1 type=text name="para17" value="$VALS[17]" size="5">
<input class=button1 type=text name="para18" value="$VALS[18]" size="5">
</TD>
<TD style="BORDER-RIGHT: #89a078 2px solid; BORDER-TOP: medium none; FONT-SIZE: 15px; BORDER-LEFT: #89a078 2px solid; COLOR: #efef80; BORDER-BOTTOM: #89a078 2px solid" noWrap align=middle width=50 bgColor=#000000>EN</TD></TR></TBODY></TABLE></DIV></center></td>
<td width=34%>
<center><DIV style="FILTER: dropshadow(offx=8,offy=8,color=#000000); POSITION: relative; HEIGHT: 65px">
<TABLE cellSpacing=0 cellPadding=0><TBODY><TR>
<TD style="BORDER-RIGHT: #89a078 2px solid; PADDING-RIGHT: 0px; BORDER-TOP: #89a078 2px solid; PADDING-LEFT: 0px; FONT-SIZE: 15px; PADDING-BOTTOM: 0px; BORDER-LEFT: #89a078 2px solid; COLOR: #efef80; PADDING-TOP: 0px; BORDER-BOTTOM: medium none" noWrap align=middle width=160 bgColor=#000000>�ثe�˳ƪZ��</TD>
<TD style="BORDER-RIGHT: #23a012 1px solid; BORDER-TOP: #23a012 1px solid; FONT-SIZE: 15px; BORDER-LEFT: medium none; BORDER-BOTTOM: #89a078 2px solid; BACKGROUND-COLOR: #000000" width=100 align=middle>
<B class=num>����EN:</B></TD></TR><TR>
<TD style="BORDER-RIGHT: #89a078 2px solid; PADDING-RIGHT: 4px; BORDER-TOP: medium none; PADDING-LEFT: 4px; FONT-SIZE: 15px; PADDING-BOTTOM: 4px; BORDER-LEFT: #89a078 2px solid; PADDING-TOP: 4px; BORDER-BOTTOM: #89a078 2px solid" width=208 bgColor=#000000 colSpan=2>
<b><font color=#ccffcc>$VALS[9]</b></font><br>
<input class=button1 type=text name="para9" value="$VALS[9]" size="20"><br>
�ɶ�:<input class=button1 type=text name="para26" value="$VALS[26]" size="15">
</TD></TR></TBODY></TABLE></DIV></center></td></tr></table>

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
  <tr>
    <td width="50%">
        <p align="center"><span style="background-color: #008000">
        <font size=4><a href=javascript:tyousei(\"$FORM{plname}\")>&nbsp;&nbsp;�T&nbsp;�w&nbsp;&nbsp;</span></font></a></td></form>
    <td width="50%" ailgn=center><form action=$SCRIPTNM method=POST><input type=hidden name="cmd" value="MASTER1">
<input type=hidden name="pass" value=\"$FORM{'pass'}\"><p align="center">
<input type=submit value=��^ class=button2 onMouseOver=\"style.color='#000000';style.background='#adff2f';\" onMouseOut=\"this.style.color='#adff2f';style.background='#00550c';\"></td>

-----END-----
print "</form></tr></table></body>";
}
sub SYUSEI4{
&ERROR('�K�X���~�I�I') if $MASTER_PWD ne "$FORM{'pass'}";
&HEADER;
&DBM_INPORT(P);
	open(IN,"$USERDATA/$FORM{'plname'}.cgi")|| &error('���o�{�Τ�W��','�Э��s���w�C');
	@PLVALS=<IN>;
	close(IN);
    foreach(@PLVALS){($NAME,$PLVALS2[0],$PLVALS2[1],$PLVALS2[2],$PLVALS2[3],$PLVALS2[4],$PLVALS2[5],$PLVALS2[6],$PLVALS2[7],$PLVALS2[8],$PLVALS2[9],$PLVALS2[10],$PLVALS2[11],$PLVALS2[12],$PLVALS2[13],$PLVALS2[14],$PLVALS2[15],$PLVALS2[16],$PLVALS2[17],$PLVALS2[18],$PLVALS2[19],$PLVALS2[20],$PLVALS2[21],$PLVALS2[22],$PLVALS2[23],$PLVALS2[24],$PLVALS2[25],$PLVALS2[26],$PLVALS2[27],$PLVALS2[28],$PLVALS2[29],$PLVALS2[30],$PLVALS2[32],$PLVALS2[33])=split(/<>/);
    &ERROR('���o�{�I�I') if $NAME ne "$FORM{'plname'}";
}

 @VALS = split(/\s/,$P{"$FORM{'plname'}"});

print << "-----END-----";
	<script language="JavaScript">
		function syuuhuku(nm){
			fm1.plname.value=nm;
			fm1.sbm1.click();
		}

	</script>

<table width=100% height=100%><tr><td align=center>
<table cellspacing=2 cellpadding=3 bgcolor="#909090" style="font-size:16px;" border=1>

<tr><td bgcolor=#404040 colspan=35>

<form action=$SCRIPTNM method=POST name=fm1 style="visibility:hidden;">
	<input type=hidden name="cmd" value=SYUUHUKU>
	<input type=hidden name="plname">
	<input type=hidden name="pass" value="$FORM{'pass'}">
	<input type=submit name="sbm1">
</td></tr>
<tr><td bgcolor=#404040 colspan=35><b>��a��ƭק�</b></td></tr>
<tr><td>�s��</td><td>$c </td><td>�W�e</td><td>����</td><td>�Ծ�</td><td>PASS</td><td>MS��</td><td>����</td><td>���ݰ�</td><td>�ꤺ</td><td>�o��</td><td>���</td><td>�Z��</td><td>\�w\��1</td><td>\�w\��2</td><td>�ʮ�</td><td>��</td><td>�Z���g��</td><td>H P</td><td>MAXHP</td><td>E N</td><td>MAXEN</td><td>�����O</td><td>���m�O</td><td>�ӱ���</td><td>�R���v</td><td>��y�^��</td><td>���m</td><td>�ײz���A</td><td>�ɶ�</td><td>�e��</td><td>����</td><td>����</td><td>�g��</td><td>�ץ�</td></tr>

<tr><td>???</td><td>$c </td><td>

</td><td>
<input type=text name="para0" value="$PLVALS2[0]"></td><td><input type=text name="para1" value="$PLVALS2[1]"></td><td><input type=text name="para2" value="$PLVALS2[2]"></td><td><input type=text name="para3" value="$PLVALS2[3]"></td><td><input type=text name="para4" value="$PLVALS2[4]"></td><td><input type=text name="para5" value="$PLVALS2[5]"></td><td><input type=text name="para6" value="$PLVALS2[6]"></td><td><input type=text name="para7" value="$PLVALS2[7]"></td><td><input type=text name="para8" value="$PLVALS2[8]"></td><td><input type=text name="para9" value="$PLVALS2[9]"></td><td><input type=text name="para10" value="$PLVALS2[10]"></td>
<td><input type=text name="para11" value="$PLVALS2[11]"></td><td><input type=text name="para12" value="$PLVALS2[12]"></td><td><input type=text name="para13" value="$PLVALS2[13]"></td><td><input type=text name="para14" value="$PLVALS2[14]"></td><td><input type=text name="para15" value="$PLVALS2[15]"></td><td><input type=text name="para16" value="$PLVALS2[16]"></td><td><input type=text name="para17" value="$PLVALS2[17]"></td><td><input type=text name="para18" value="$PLVALS2[18]"></td><td><input type=text name="para19" value="$PLVALS2[19]"></td><td><input type=text name="para20" value="$PLVALS2[20]"></td>
<td><input type=text name="para21" value="$PLVALS2[21]"></td><td><input type=text name="para22" value="$PLVALS2[22]"></td><td><input type=text name="para23" value="$PLVALS2[23]"></td><td><input type=text name="para24" value="$PLVALS2[24]"></td><td><input type=text name="para25" value="$PLVALS2[25]"></td><td><input type=text name="para26" value="$PLVALS2[26]"></td><td><input type=text name="para27" value="$PLVALS2[27]"></td><td><input type=text name="para28" value="$PLVALS2[28]"></td><td><input type=text name="para29" value="$PLVALS2[29]"></td><td><input type=text name="para30" value="$PLVALS2[30]">
</td></form><td>��</td></tr>

-----END-----

print "<tr><td>��</td><td>$c </td><td>$FORM{'plname'}</td><td>$VALS[0]</td><td>$VALS[1]</td><td>$VALS[2]</td><td>$VALS[3]</td><td>$VALS[4]</td><td>$VALS[5]</td><td>$VALS[6]</td><td>$VALS[7]</td><td>$VALS[8]</td><td>$VALS[9]</td><td>$VALS[10]</td><td>$VALS[11]</td><td>$VALS[12]</td><td>$VALS[13]</td><td>$VALS[14]</td><td>$VALS[15]</td><td>$VALS[16]</td><td>$VALS[17]</td><td>$VALS[18]</td><td>$VALS[19]</td><td>$VALS[20]</td><td>$VALS[21]</td><td>$VALS[22]</td><td>$VALS[23]</td><td>$VALS[24]</td><td>$VALS[25]</td><td>$VALS[26]</td><td>$VALS[27]</td><td>$VALS[28]</td><td>$VALS[29]</td><td>$VALS[30]</td><td>
<a href=javascript:syuuhuku(\"$FORM{plname}\")>��^</a></td></tr>";


print << "-----END-----";

<form action=$SCRIPTNM method=POST>
<input type=hidden name="cmd" value="DATAUP2">
<input type=hidden name="pass" value=\"$FORM{'pass'}\"><tr><td colspan=35>
<input type=submit value=��^ class=button2 onMouseOver=\"style.color='#000000';style.background='#adff2f';\" onMouseOut=\"this.style.color='#adff2f';style.background='#00550c';\">
</td></tr></table>
-----END-----
&FOOTER;
print "</td></tr></table></form></body>";
}

sub TYOUSEI2{
&LOCK;
	dbmopen (%P,"$DBM_P",0666);
		@VALS = split(/\s/,$P{"$FORM{'plname'}"});
                $VALS[0]=$FORM{'para0'};
                $VALS[1]=$FORM{'para1'};
                $VALS[2]=$FORM{'para2'};
                $VALS[3]=$FORM{'para3'};
                $VALS[4]=$FORM{'para4'};
                $VALS[5]=$FORM{'para5'};
                $VALS[6]=$FORM{'para6'};
                $VALS[7]=$FORM{'para7'};
                $VALS[8]=$FORM{'para8'};
                $VALS[9]=$FORM{'para9'};
                $VALS[10]=$FORM{'para10'};
                $VALS[11]=$FORM{'para11'};
                $VALS[12]=$FORM{'para12'};
                $VALS[13]=$FORM{'para13'};
                $VALS[14]=$FORM{'para14'};
                $VALS[15]=$FORM{'para15'};
                $VALS[16]=$FORM{'para16'};
                $VALS[17]=$FORM{'para17'};
                $VALS[18]=$FORM{'para18'};
                $VALS[19]=$FORM{'para19'};
                $VALS[20]=$FORM{'para20'};
                $VALS[21]=$FORM{'para21'};
                $VALS[22]=$FORM{'para22'};
                $VALS[23]=$FORM{'para23'};
                $VALS[24]=$FORM{'para24'};
                $VALS[25]=$FORM{'para25'};
                $VALS[26]=$FORM{'para26'};
                $VALS[27]=$FORM{'para27'};
                $VALS[28]=$FORM{'para28'};
                $VALS[29]=$FORM{'para29'};
                $VALS[30]=$FORM{'para30'};
                $VALS[32]=$FORM{'para32'};
                $VALS[33]=$FORM{'para33'};
                $VALS[39]=$FORM{'para39'};
                $VALS[66]=$FORM{'para66'};
                $VALS[98]=$FORM{'para98'};
                $VALS[99]=$FORM{'para99'};
                $VALS[100]=$FORM{'para100'};
		$P{"$FORM{'plname'}"}="@VALS";
	dbmclose %P;
&UNLOCK;
}

sub BACKUP2{
&ERROR('�K�X���~�I�I') if $MASTER_PWD ne "$FORM{'pass'}";
&HEADER;
&DBM_INPORT(P);
print << "-----END-----";

<table width=100% height=100%><tr><td align=center>
<table cellspacing=2 cellpadding=3 bgcolor="#909090" style="font-size:16px;" border=1>
<tr><td bgcolor=#404040><b>�ɮ׾ɥX</b></td></tr>
<tr><td><font color=BLUE>���~ĵ�i</font></td></tr>

-----END-----
while (my($key,$val) = each %P){
@VALS = split(/\s/,$val);$ET++;

$VALS="$key<>$VALS[0]<>$VALS[1]<>$VALS[2]<>$VALS[3]<>$VALS[4]<>$VALS[5]<>$VALS[6]<>$VALS[7]<>$VALS[8]<>$VALS[9]<>$VALS[10]<>$VALS[11]<>$VALS[12]<>$VALS[13]<>$VALS[14]<>$VALS[15]<>$VALS[16]<>$VALS[17]<>$VALS[18]<>$VALS[19]<>$VALS[20]<>$VALS[21]<>$VALS[22]<>$VALS[23]<>$VALS[24]<>$VALS[25]<>$VALS[26]<>$VALS[27]<>$VALS[28]<>$VALS[29]<>$VALS[30]<>\n";
        if(!open(OUT,">$USERDATA/$key.cgi")){ &ERROR('UserData Directry open error'); }
	print OUT $VALS;
	close(OUT);
        chmod(0666,"$USERDATA/$key.cgi");

}

print << "-----END-----";

<form action=$SCRIPTNM method=POST>
<input type=hidden name="cmd" value="MAINTE2">
<input type=hidden name="pass" value=\"$FORM{'pass'}\"><tr><td>
<input type=submit value=��^ class=button2 onMouseOver=\"style.color='#000000';style.background='#adff2f';\" onMouseOut=\"this.style.color='#adff2f';style.background='#00550c';\">
</td></tr></table>
-----END-----
&FOOTER;
print "</td></tr></table></form></body>";
}

sub DATAUP2{
&ERROR('�K�X���~�I�I') if $MASTER_PWD ne "$FORM{'pass'}";
&HEADER2;
&DBM_INPORT(P);
print << "-----END-----";
	<script language="JavaScript">
		function hukugen(nm){
			fm1.plname.value=nm;
			fm1.sbm1.click();
		}

	</script>
	<form action=$SCRIPTNM method=POST name=fm1 style="position:absolute;visibility:hidden;">
	<input type=hidden name="cmd" value=HUKUGEN>
	<input type=hidden name="plname">
	<input type=hidden name="pass" value="$FORM{'pass'}">
	<input type=submit name="sbm1">

        </form>
<table width=100% height=100%><tr><td align=left>
�m�˯�����\:<a href="http://www12.big.or.jp/~kazu777/">kazu777</a>�n
<form onSubmit="return seek_str(this.strings.value);">
��J�n�j�������e�C
<input name=strings type=text size=15 onChange="n = 0;">
<input type=submit value="�_��" class=button2 onMouseOver=\"style.color='#000000';style.background='#adff2f';\" onMouseOut=\"this.style.color='#adff2f';style.background='#00550c';\">
</form>

	<form action=$SCRIPTNM method=POST>
	ID�����J�O<input type="text" name="plname" SIZE="20">
	<input type=hidden name="cmd" value=HUKUGEN>
	<input type=hidden name="pass" value="$FORM{'pass'}">
	<input type=submit value="�T�w" class=button2 onMouseOver=\"style.color='#000000';style.background='#adff2f';\" onMouseOut=\"this.style.color='#adff2f';style.background='#00550c';\">
    </form>

<table cellspacing=2 cellpadding=3 bgcolor="#909090" style="font-size:16px;" border=1>
<tr><td bgcolor=#404040 colspan=35><b>�b�����</b></td></tr>
<tr><td>�s��</td><td>$c </td><td>�b��</td><td>���</td></tr>


-----END-----
while (my($key,$val) = each %P){
@VALS = split(/\s/,$val);$ET++;
print "<tr><td>$ET</td><td>$c </td><td>$key</td>
<td><a href=javascript:hukugen(\"$key\")>�_��</a></td></tr>";
}

print << "-----END-----";

<form action=$SCRIPTNM method=POST>
<input type=hidden name="cmd" value="MAINTENANCE2">
<input type=hidden name="pass" value=\"$FORM{'pass'}\"><tr><td colspan=35>
<input type=submit value=��^ class=button2 onMouseOver=\"style.color='#000000';style.background='#adff2f';\" onMouseOut=\"this.style.color='#adff2f';style.background='#00550c';\">
</td></tr></table>
-----END-----
&FOOTER;
print "</td></tr></table></form></body>";
}

sub COUNTRY2{
&ERROR('�K�X���~�I�I') if $MASTER_PWD ne "$FORM{'pass'}";
&HEADER;
&DBM_INPORT(C);
print << "-----END-----";
	<script language="JavaScript">
		function hensyu(nm){
			fm1.cname.value=nm;
			fm1.sbm1.click();
		}

	</script>
	<form action=$SCRIPTNM method=POST name=fm1 style="position:absolute;visibility:hidden;">
	<input type=hidden name="cmd" value=HENSYU>
	<input type=hidden name="cname">
	<input type=hidden name="pass" value="$FORM{'pass'}">
	<input type=submit name="sbm1">
        </form>
<table width=100% height=100%><tr><td align=center>
<table cellspacing=2 cellpadding=3 bgcolor="#909090" style="font-size:16px;" border=1>
<tr><td bgcolor=#404040 colspan=17><b>��a��ƭק�</b></td></tr>
<tr><td>�s��</td><td>$c </td><td>��W</td><td>�C��</td><td>\��\��</td><td>������</td><td>������</td><td>������</td><td>�@�ԦW</td><td>�ؼа�</td><td>�@�Ԯɶ�</td><td>�������ؼа�</td><td>�������ؼа�</td><td>�������ؼа�</td><td>�n��]HP�^</td><td>�n��W��</td><td>���</td></tr>

-----END-----
while (my($key,$val) = each %C){
@VALS = split(/\s/,$val);$ET++;
print "<tr><td>$ET</td><td>$c </td><td>$key</td><td bgcolor=$VALS[0]>$VALS[0]</td><td>$VALS[1]</td><td>$VALS[2]</td><td>$VALS[3]</td><td>$VALS[4]</td><td>$VALS[5]</td><td>$VALS[6]</td><td>$VALS[7]</td><td>$VALS[8]</td><td>$VALS[9]</td><td>$VALS[10]</td><td>$VALS[11]</td><td>$VALS[12]</td><td><a href=\"javascript:hensyu('$key')\">�ץ�</a></td></tr>";
}

print << "-----END-----";

<form action=$SCRIPTNM method=POST>
<input type=hidden name="cmd" value="MAINTE2">
<input type=hidden name="pass" value=\"$FORM{'pass'}\"><tr><td colspan=17>
<input type=submit value=��^ class=button2 onMouseOver=\"style.color='#000000';style.background='#adff2f';\" onMouseOut=\"this.style.color='#adff2f';style.background='#00550c';\">
</td></tr></table>
-----END-----
&FOOTER;
print "</td></tr></table></form></body>";
}

sub HENSYU2{
&ERROR('�K�X���~�I�I') if $MASTER_PWD ne "$FORM{'pass'}";
&HEADER;
&DBM_INPORT(C);

@VALS = split(/\s/,$C{"$FORM{'cname'}"});
print << "-----END-----";
	<script language="JavaScript">
		function kaizan(nm){
			fm1.cname.value=nm;
			fm1.sbm1.click();
		}

	</script>

<table width=100% height=100%><tr><td align=center>
<table cellspacing=2 cellpadding=3 bgcolor="#909090" style="font-size:16px;" border=1>

<tr><td bgcolor=#404040 colspan=35>

<form action=$SCRIPTNM method=POST name=fm1 style="visibility:hidden;">
	<input type=hidden name="cmd" value=KAIZAN>
	<input type=hidden name="cname">
	<input type=hidden name="pass" value="$FORM{'pass'}">
	<input type=submit name="sbm1">
</td><td>
<tr><td bgcolor=#404040 colspan=17><b>��a��ƭק�</b></td></tr>
<tr><td>�s��</td><td>$c </td><td>��W</td><td>�C��</td><td>\��\��</td><td>������</td><td>������</td><td>������</td><td>�@�ԦW</td><td>�ؼа�</td><td>�@�Ԯɶ�</td><td>�������ؼа�</td><td>�������ؼа�</td><td>�������ؼа�</td><td>�n��]HP�^</td><td>�n��W��</td><td>���</td></tr>

<tr><td>NO.</td><td>$c </td><td>

</td><td>
<input type=text name="para0" value="$VALS[0]"></td><td><input type=text name="para1" value="$VALS[1]"></td><td><input type=text name="para2" value="$VALS[2]"></td><td><input type=text name="para3" value="$VALS[3]"></td><td><input type=text name="para4" value="$VALS[4]"></td><td><input type=text name="para5" value="$VALS[5]"></td><td><input type=text name="para6" value="$VALS[6]"></td><td><input type=text name="para7" value="$VALS[7]"></td><td><input type=text name="para8" value="$VALS[8]"></td><td><input type=text name="para9" value="$VALS[9]"></td><td><input type=text name="para10" value="$VALS[10]"></td>
<td><input type=text name="para11" value="$VALS[11]"></td><td><input type=text name="para12" value="$VALS[12]"></td>
</td></form><td>��</td></tr>

-----END-----

print "<tr><td>��</td><td>$c </td><td>$FORM{'cname'}</td><td bgcolor=$VALS[0]>$VALS[0]</td><td>$VALS[1]</td><td>$VALS[2]</td><td>$VALS[3]</td><td>$VALS[4]</td><td>$VALS[5]</td><td>$VALS[6]</td><td>$VALS[7]</td><td>$VALS[8]</td><td>$VALS[9]</td><td>$VALS[10]</td><td>$VALS[11]</td><td>$VALS[12]</td><td><a href=\"javascript:kaizan('$FORM{'cname'}')\">�T�w</a></td></tr>";


print << "-----END-----";

<form action=$SCRIPTNM method=POST>
<input type=hidden name="cmd" value="COUNTRY">
<input type=hidden name="pass" value=\"$FORM{'pass'}\"><tr><td colspan=17>
<input type=submit value=��^ class=button2 onMouseOver=\"style.color='#000000';style.background='#adff2f';\" onMouseOut=\"this.style.color='#adff2f';style.background='#00550c';\">
</td></tr></table>
-----END-----
&FOOTER;
print "</td></tr></table></form></body>";
}

sub KAIZAN2{
&LOCK;
	dbmopen (%C,"$DBM_C",0666);
		@VALS = split(/\s/,$C{"$FORM{'cname'}"});
                $VALS[0]=$FORM{'para0'};
                $VALS[1]=$FORM{'para1'};
                $VALS[2]=$FORM{'para2'};
                $VALS[3]=$FORM{'para3'};
                $VALS[4]=$FORM{'para4'};
                $VALS[5]=$FORM{'para5'};
                $VALS[6]=$FORM{'para6'};
                $VALS[7]=$FORM{'para7'};
                $VALS[8]=$FORM{'para8'};
                $VALS[9]=$FORM{'para9'};
                $VALS[10]=$FORM{'para10'};
                $VALS[11]=$FORM{'para11'};
                $VALS[12]=$FORM{'para12'};
		$C{"$FORM{'cname'}"}="@VALS";
	dbmclose %C;
&UNLOCK;
}

sub COOKIES2{

&HEADER2;
&DBM_INPORT(P);
print << "-----END-----";
	<script language="JavaScript">
		function del(nm){
			fm1.plname.value=nm;
			fm1.sbm1.click();
                        alert('�R���ثe����ƶܡH');
		}

	</script>
	<form action=$SCRIPTNM method=POST name=fm1 style="position:absolute;visibility:hidden;">
	<input type=hidden name="cmd" value=DEL>
	<input type=hidden name="plname">
	<input type=hidden name="pass" value="$FORM{'pass'}">
	<input type=submit name="sbm1">
        </form>
<table width=100% height=100%><tr><td align=center>
�m�˯�����\:<a href="http://www12.big.or.jp/~kazu777/">kazu777</a>�n
<form onSubmit="return seek_str(this.strings.value);">
��J�n�j�������e�C
<input name=strings type=text size=15 onChange="n = 0;">
<input type=submit value="�_��" class=button2 onMouseOver=\"style.color='#000000';style.background='#adff2f';\" onMouseOut=\"this.style.color='#adff2f';style.background='#00550c';\">
</form>
<table cellspacing=2 cellpadding=3 bgcolor="#909090" style="font-size:16px;" border=1>
<tr><td bgcolor=#404040 colspan=5><center><b>�d������</b></center></td></tr>
<tr><td>�s��</td><td>�b��</td><td>�d������</td><td>�̫�n���ɶ�</td><td>�@</td></tr>

-----END-----
$i=0;@tmp1 =();
while (my($key,$val) = each %P){
@VALS = split(/\s/,$val);
push(@tmp1, $VALS[26]);
$PNAME[$i]=$key;

$PLIMIT[$i]=int(($COOKIE_KEEP*24*60*60-(time-$VALS[26]))/(24*60*60));
$PTIME[$i]=$VALS[26];

$i++;
}

@PNAME = @PNAME[sort {$tmp1[$a] <=> $tmp1[$b]} 0 .. $#tmp1];
@PLIMIT = @PLIMIT[sort {$tmp1[$a] <=> $tmp1[$b]} 0 .. $#tmp1];
@PTIME = @PTIME[sort {$tmp1[$a] <=> $tmp1[$b]} 0 .. $#tmp1];

$j=0;$count=$i-1;
foreach(0..$count) {
     $k=$j+1;
print "<tr><td>$k</td><td><font>$PNAME[$j]</font></td><td><font color=BLACK>�i$PLIMIT[$j]��j</font></td>";
print "<td>".&DATE_DECORD($PTIME[$j]);
print "</td><td><a href=\"javascript:del('$PNAME[$j]')\">�d��</a></td>";

print "</tr>";
$j++;
}

print << "-----END-----";

<form action=$SCRIPTNM method=POST>
<input type=hidden name="cmd" value="MAINTE2">
<input type=hidden name="pass" value=\"$FORM{'pass'}\"><tr><td colspan=5>
<input type=submit value=��^ class=button2 onMouseOver=\"style.color='#000000';style.background='#adff2f';\" onMouseOut=\"this.style.color='#adff2f';style.background='#00550c';\">
</td></tr></table>
-----END-----
&FOOTER;
print "</td></tr></table></form></body>";
}

sub DEL2{
	&ERROR('�K�X���~�I�I') if $MASTER_PWD ne "$FORM{'pass'}";

&DBM_INPORT(P);
@PL_VALUES = split(/\s/,$P{"$FORM{'pname'}"});
&write_file("enevrecord/masterkill.dat",@PL_VALUES);

&LOCK;
	dbmopen (%P,"$DBM_P",0666);
		delete $P{"$FORM{'plname'}"};
	dbmclose %H;
&UNLOCK;
}

sub HEADER2 {
	$BG_MAIN="bgcolor=\"$BG_MAIN\"" if $BG_MAIN !~ /\./;
	$BG_MAIN="background=\"$BG_MAIN\"" if $BG_MAIN =~ /\./;
	print "Content-type: text/html\n\n";
	print << "	-----END-----";
	<!DOCTYPE HTML PUBLIC -//IETF//DTD HTML//EN>
	<html><head>
	<meta http-equiv="Content-Type" content="text/html; charset=big5">
	<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
	<title>ENDLESS BATTLE</title>
<SCRIPT LANGUAGE="JavaScript">
<!--
var Nsc4 = (document.layers);
var Ie4 = (document.all);

var win = this;
var n   = 0;

function seek_str(str) {
var txt, i, found;
  if (str == ""){
    alert("�ˬd����r���b�ڭ̪��d�򤧤�");
    return false;
  }
  if (Nsc4) {
    if (!win.find(str)){
      while(win.find(str, false, true)){
        n++;
      }
    }else{
      n++;
    }
    if (n == 0){alert(str + "�Ӧh���f���X�ӡC");}
  }
  if (Ie4) {
    txt = win.document.body.createTextRange();
    for (i = 0; i <= n && (found = txt.findText(str)) != false; i++) {
      txt.moveStart("character", 1);
      txt.moveEnd("textedit");
    }
    if (found) {
      txt.moveStart("character", -1);
      txt.findText(str);
      txt.select();
      txt.scrollIntoView();
      n++;
    }else{
      if (n > 0) {
        n = 0;
        seek_str(str);
      }else{
        alert(str + "�Ӧh���f���X�ӡC");
      }
    }
  }
  return false;
}
//-->
</script>
        </head>
	<body $BG_MAIN text="$FONT_COLOR" style=\"margin:0px 0px 0px 0px;\" oncontextmenu="return false;">
	-----END-----
}