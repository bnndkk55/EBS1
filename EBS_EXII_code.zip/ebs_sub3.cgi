require "debug_sub.pl";

sub FRAME{
	print <<"	-----END-----";
Content-type: text/html

		<html><head>
		<meta http-equiv='Content-Type' content='text/html; charset=big5' />
		<title>$THIS_Title</title>
                </head>

		<frameset ID="fs1" rows="*,$UPPER_FRAME" frameBorder="1" bordercolor="#002720" framespacing="5">
		<frame name="Main" scrolling=yes src="$MAIN_SCRIPT?LOGIN">
		<frame name="Sub" scrolling=yes src="$MAIN_SCRIPT?LOG0">
		</frameset>
		</html>
	-----END-----
}
sub STATUS{
	&DBM_CONVERT('P',"$FORM{'pname'}") if !$FORM{'Cmode'};
	&DBM_CONVERT('C',"$PL_VALUES[5]") if $PL_VALUES[5];



if($DisableNPC{$FORM{'pname'}} eq 1 )
{
&record_fight(""," ","$FORM{'pname'} �Q��NPC ID ")
&ERROR('NameError','�Τ�W�����D�A�n������');

}	

	&ERROR('NameError','�Τ�W�����D�A�n������') if !@PL_VALUES;
	&ERROR('PwdError','�K�X�����D�A�n������') if crypt ($FORM{'pass'},eb) ne "$PL_VALUES[2]";
	&REPAIR(PL);
		if ($FORM{'login'}){
		if ($ENV{'REMOTE_HOST'}){$host="$ENV{'REMOTE_HOST'}";}else{$ipad=pack('C4',split(/\./,$ENV{'REMOTE_ADDR'}));
		
		
		$host = gethostbyaddr($ipad,2);}
		dbmopen (%L,"$DBM_L",0666);
			foreach (sort {$b <=> $a} keys %L){$lc++;delete $L{"$_"} if $lc > 51;}
			$L{"$DATE"}="$FORM{'pname'}!$ENV{'REMOTE_ADDR'}!$host";
		dbmclose %L;
		

	}
	SET_COOKIE:{
		my @gmt = gmtime(time + $COOKIE_KEEP*24*60*60);
		$gmt[0] = sprintf("%02d", $gmt[0]);	$gmt[1] = sprintf("%02d", $gmt[1]);
		$gmt[2] = sprintf("%02d", $gmt[2]);	$gmt[3] = sprintf("%02d", $gmt[3]);	$gmt[5] += 1900;
		$gmt[4] = ('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')[$gmt[4]];
		$gmt[6] = ('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday')[$gmt[6]];
		my $date_gmt = "$gmt[6], $gmt[3]\-$gmt[4]\-$gmt[5] $gmt[2]:$gmt[1]:$gmt[0] GMT";
		my $cook = "pname:$FORM{'pname'},pass:$FORM{'pass'}";print "Set-Cookie: EB=$cook; expires=$date_gmt\n";
	}
	if ($PL_VALUES[28]){
		foreach ("$CL_VALUES[2]","$CL_VALUES[3]","$CL_VALUES[4]"){if ($PL_VALUES[28] eq "$_") {$DeleteFlag=1;}}
		if (!$DeleteFlag){$PL_VALUES[6]=$PL_VALUES[28]="";$flagd=1;}
	}
	if ($PL_VALUES[5] && !@CL_VALUES){$PL_VALUES[5]=$PL_VALUES[28]='';$PL_VALUES[6]=0;$flagd=1;}
	if (!$PL_VALUES[5] && $PL_VALUES[6]){$PL_VALUES[6]='0';$flagd=1;}
	$tmpdate=time;
	if ($PL_VALUES[34] eq ""){$PL_VALUES[34]="$tmpdate!0";$flagd=1;}
	if ($flagd){
		dbmopen (%PL,"$DBM_P",0666);
			$PL{"$FORM{'pname'}"}="@PL_VALUES";
		dbmclose %PL;
	}


	local($WN_A,$WLV_A,$WEX_A) = split(/!/,$PL_VALUES[9]); local($WN_B,$WLV_B,$WEX_B) = split(/!/,$PL_VALUES[10]);
	local($WN_C,$WLV_C,$WEX_C) = split(/!/,$PL_VALUES[11]); local($WN_D,$WLV_D,$WEX_D) = split(/!/,$PL_VALUES[98]);
	local($WN_E,$WLV_E,$WEX_E) = split(/!/,$PL_VALUES[99]);
require "$LOG_FOLDER/_bougu.data"; 
local($BG_A,$BGT_A) = split(/!/,$PL_VALUES[41]); 
	if   ($PL_VALUES[25] == 0){$CONDITIONAL = '<font color=#33CCFF>��</font>';}
	elsif($PL_VALUES[25] == 1){$CONDITIONAL = '<font color=red>��</font>';}

	$CL_VALUES[0]='#808080' if !$PL_VALUES[5];


&HEADER;
$ListAllFighters=ListAllFighter();
if ($PL_VALUES[5] eq $NoFightPlace){&ERROR('�]�S�O�z��..�A�ȮɳQ�B��F..�o�q�ɶ�..�L�k���');}

if ($PL_VALUES[5] eq $WaitDiePlace)
{
 rename "$StorageDir/$FORM{'pname'}.dat","$StorageDir/$FORM{'pname'}.bakdat";
 &ERROR('�]�S�O�z��..�A�Q���F..����ID�Q�R����..�ߤ@���|�N�O���ݯ����S�j!');
}



print << "---HTMLTAG----";

<script LANGUAGE="JavaScript">
<!--
function hidden_object(objectName)
{
eval('document.all["'+objectName+'"].style'+'.visibility="hidden";');
}

function visible_object(objectName)
{
eval('document.all["'+objectName+'"].style'+'.visibility="visible";');
}

//-->
</script>         


<div id=ShowOtherInf style="position: absolute; visibility:hidden; z-index: 900; top:5; left:0;">
<input type=button value="����" $STYLE_B1 onClick="hidden_object('ShowOtherInf')">
<table border="1" width="100%" bgcolor="#FFFFCC">
    <td bgcolor="#CCFFCC">
    <font color="#000000">
    $ListAllFighters <br>
        �̫��s�ɶ�:$nowtime �A��IP:$Ipaddress <A href="$THIS_DIR"><span style="background-color: #808080">�D����</A> <A href="$BBS_DIR">�Q�װ�</A> </span>  

    </font>  
</table>  
</div>
---HTMLTAG----


	require "$LOG_FOLDER/_ex.data";
	@WEX_sA=split(/\,/,$WEAPONEX_LIST{"$WEX_A"});
	@WEX_sB=split(/\,/,$WEAPONEX_LIST{"$WEX_B"});
	@WEX_sC=split(/\,/,$WEAPONEX_LIST{"$WEX_C"});
	@WEX_sD=split(/\,/,$WEAPONEX_LIST{"$WEX_D"});
	@WEX_sE=split(/\,/,$WEAPONEX_LIST{"$WEX_E"});
	$WEP_A=$WLV_A%$WEAPON_LVUP;	$WEP_B=$WLV_B%$WEAPON_LVUP;	$WEP_C=$WLV_C%$WEAPON_LVUP; $WEP_D=$WLV_D%$WEAPON_LVUP; $WEP_E=$WLV_E%$WEAPON_LVUP;
	$WLV_A=int$WLV_A/$WEAPON_LVUP;$WLV_B=int$WLV_B/$WEAPON_LVUP;$WLV_C=int$WLV_C/$WEAPON_LVUP;$WLV_D=int$WLV_D/$WEAPON_LVUP;$WLV_E=int$WLV_E/$WEAPON_LVUP;

#=========================Online show=======
@onlinefighter[0]="document.write('$ListAllFighters');\n";
write_file("$HTMLAbsDir/onlinefighter.htm",@onlinefighter);
($CuntOnline,$CuntOnline2)=split(/:/,$ListAllFighters);
($CuntOnline2,$CuntOnline)=split(/��/,$CuntOnline);

@onlinefighter[0]="document.write('$CuntOnline');\n";
write_file("onlinepeople.htm",@onlinefighter);

#============== SHow ARM INFO==============
@WN_sA=split(/\,/,$WEAPON_LIST{"$WN_A"});
if (!$WN_sA[0]){$WEX_sA[0]="";}
$ShowWeaponSpecial=WeaponSpecial();
@BG_sA=split(/\,/,$BOUGU_LIST{"$BG_A"}); 
$WeaponAttPower=STATUS_CONVERT($WN_sA[1]*$WN_sA[3]/500,'s');
$WeaponHitPower=&STATUS_CONVERT($WN_sA[2]/4,'s');
#============================================

#============ FIGHT RECORD=======================
($DatHp,$Result,$DatHp2,$Result2,$DatHp3,$Result3,$DatHp4,$Result4,$DatHp5,$Result5) = split(/!/,$PL_VALUES[1]);
$DateRecord=&DATE_DECORD("$DatHp");
$DateRecord2=&DATE_DECORD("$DatHp2");
$DateRecord3=&DATE_DECORD("$DatHp3");
$DateRecord4=&DATE_DECORD("$DatHp4");
$DateRecord5=&DATE_DECORD("$DatHp5");

print << "---HTMLTAG----";
<div id=FightRecord style="position: absolute; visibility:hidden; z-index: 900; top:5; left:0;">
<input type=button value="����" $STYLE_B1 onClick="hidden_object('FightRecord')">

<table border="1" width="87%" bgcolor="#CCCC00">
  <tr>
    <td width="100%" bgcolor="#CCFFCC">
<font color="#000000">
<b>�԰��p��</b><br>
$DateRecord $Result<br>  
$DateRecord2 $Result2<br>  
$DateRecord3 $Result3<br>  
$DateRecord4 $Result4<br>  
$DateRecord5 $Result5<br>  
</font>  
  </tr>  
</table>  
<br>  

</div>
---HTMLTAG----
#=================================================


#==================== WEAPON and SKILL CHECK==============================
$AttPointShow=&STATUS_CONVERT("$PL_VALUES[19]",'s')."($PL_VALUES[19])";
$ProPointShow=&STATUS_CONVERT("$PL_VALUES[20]",'s')."($PL_VALUES[20])";
$SpdPointShow=&STATUS_CONVERT("$PL_VALUES[22]",'s')."($PL_VALUES[22])";
$HitPointShow=&STATUS_CONVERT("$PL_VALUES[21]",'s')."($PL_VALUES[21])";
@WN_sB=split(/\,/,$WEAPON_LIST{"$WN_B"});
@WN_sC=split(/\,/,$WEAPON_LIST{"$WN_C"});
@WN_sD=split(/\,/,$WEAPON_LIST{"$WN_D"});
@WN_sE=split(/\,/,$WEAPON_LIST{"$WN_E"});
$WeaponbExp="(Lv.$WLV_B/exp.$WEP_B)";
$WeaponcExp="(Lv.$WLV_C/exp.$WEP_C)";
$WeapondExp="(Lv.$WLV_D/exp.$WEP_D)";
$WeaponeExp="(Lv.$WLV_E/exp.$WEP_E)";

if (!$WN_sB[0]){$WEX_sB[0]="";$WeaponbExp="�L";}
if (!$WN_sC[0]){$WEX_sC[0]="";$WeaponcExp="�L";}
if (!$WN_sD[0]){$WEX_sD[0]="";$WeapondExp="�L";}
if (!$WN_sE[0]){$WEX_sE[0]="";$WeaponeExp="�L";}

print << "---HTMLTAG----";
<div id=WeaponSkillCheck style="position: absolute; visibility:hidden; z-index: 900; top:5; left:0;">
<input type=button value="����" $STYLE_B1 onClick="hidden_object('WeaponSkillCheck')">


<table border="1" width="85%" bgcolor="#A7AE97">
  <tr>
    <td width="100%" colspan="2">
�Z���P�ޯ��˩w</td>
  </tr>
  <tr>
    <td width="100%" colspan="2" bgcolor="#FFFFCC">
<font size="2">
<font color="#000000">
�� $AttPointShow-�� $ProPointShow-�R $SpdPointShow-�t $HitPointShow</font></font> 
</td>  
  </tr>  
  <tr>  
    <td width="100%" colspan="2" bgcolor="#FFCCCC"> 
<font size="2"> 
<font color="#000000">
$STATUS_NAME[10] $PL_VALUES[39] <br>  
$STATUS_NAME[11] $PL_VALUES[66]</font></font></td>  
  </tr>  
  <tr>  
    <td width="50%" bgcolor="#00CC99"> 
<font size="2"> 
�ƪZ1 $WN_sB[0] $WEX_sB[0] </font>
<font size="2">
 $WeaponbExp<br>
�ƪZ3 $WN_sD[0] $WEX_sD[0] </font><font size="2"> $WeapondExp</font></td> 
    <td width="50%" bgcolor="#00CC99">
<font size="2">
&nbsp;�ƪZ2 $WN_sC[0] $WEX_sC[0] $WeaponcExp<br> 
&nbsp;�ƪZ4 $WN_sE[0] $WEX_sE[0] $WeaponeExp<br>  
</font></td>  
  </tr>  
</table>  
  
</div>
---HTMLTAG----

#====================================================
#==================SHOW PERSONAL INFORMATION======================

$JIZHUISHU=int($PL_VALUES[24]/$CumNumber);

$AT=int(($PL_VALUES[19]/65)*30);
$DE=int(($PL_VALUES[20]/65)*30);
$SP=int(($PL_VALUES[21]/65)*30);
$MT=int(($PL_VALUES[22]/65)*30);
$NEXT=($PL_VALUES[29]+1)*200;
$PL_VALUES[5]='�ۥѾԤh' if !$PL_VALUES[5];
if (!$PL_VALUES[32]){$syouritu = 0;}
else{$syouritu=int(($PL_VALUES[33]/$PL_VALUES[32])*100);}
$CharacterShow=&STATUS_CONVERT("$PL_VALUES[12]",'c');
$TypeShow=&STATUS_CONVERT("$PL_VALUES[4]",'t');
$RankShow=&RANK($PL_VALUES[0],$PL_VALUES[5],$PL_VALUES[6]);


#=================================================================
#=================== MENU ========================================

print << "---HTMLTAG----";
<div id=OtherFeature style="position: absolute; visibility:hidden; z-index: 900; top:5; left:0;">
<input type=button value="����" $STYLE_B1 onClick="hidden_object('OtherFeature')">
<table width="57%" border="1" bgcolor="#00CC99">
<tr>
<td width="100%" bgcolor="#CCCC00">
<form action=$MAIN_SCRIPT name='FM1' method='POST' target="Sub">
<input type=hidden name=cmd value="">
<input type=hidden name=pname value=$FORM{'pname'}>
<input type=hidden name=pass value=$FORM{'pass'}>

<input type=submit name='b_mode' value='�԰�' $STYLE_B1 onClick="document.FM1.cmd.value='BATTLE_1';">
<input type=submit name="b_mode" value="�`�R" $STYLE_B1 onClick="document.FM1.cmd.value='BATTLE_1';">
<input type=submit name="b_mode" value="����" $STYLE_B1 onClick="document.FM1.cmd.value='BATTLE_1';">
<input type=submit name="custom" value="�S��" $STYLE_B1 onClick="document.FM1.cmd.value='SPC';">
<input type=button value="�դO" $STYLE_B1 onClick="parent.Sub.location.replace('ballance.cgi')">
<br>
<input type=button value="�˺�" $STYLE_B1 onClick="window.open('http://www.frwonline.com/ebs/item.htm', 'ItemManager', 'directories=yes,location=no,menubar=no,toolbar=no,scrollbars=yes,height=600,width=800,marginwidth=1 marginheight=1');"></a>
<input type=button value="�Z��" $STYLE_B1 onClick="parent.Sub.location.replace('weaponlist.pl')">
<input type=submit name="custom" value="��y" $STYLE_B1 onClick="document.FM1.cmd.value='CUSTOMING';">     
<input type=submit name="custom" value="���U" $STYLE_B1 onClick="document.FM1.cmd.value='BOUGU';">
<br>
<input type=button value="�걡" $STYLE_B1 onClick="parent.Sub.location.replace('kunijyouhou.cgi')">
<br>
<input type=button value="����" $STYLE_B1 onClick="parent.Sub.location.replace('repaircenter.pl')">

<input type=submit name="custom" value="���v" $STYLE_B1 onClick="document.FM1.cmd.value='HIS';">
<input type=button value="�O��" $STYLE_B1 onClick="parent.Sub.location.replace('member.cgi')">
<br>
<input type=submit name="custom" value="�o��" $STYLE_B1 onClick="document.FM1.cmd.value='COM';">
<input type=button value="ĳ�|" $STYLE_B1 onClick="parent.Sub.location.replace('bbs.cgi')">
<br>
<input type=button value="�ƦW" $STYLE_B1 onClick="parent.Sub.location.replace('ranking.cgi')">
<input type=submit name="custom" value="�y��" $STYLE_B1 onClick="document.FM1.cmd.value='FACE';">

<br>
<input type="submit" value="��ѫ�" $STYLE_B1 onClick="window.open('http://chris.oldtu.com/', 'chatroomwindow', 'directories=yes,location=no,menubar=yes,toolbar=yes,scrollbars=yes,height=170,width=170,screenX=600,screenY=400,marginwidth=1 marginheight=1');">
<input type=button value="��y" $STYLE_B1 onClick="window.open('$BBS_DIR');">
<input type="submit" value="�����H�C��" $STYLE_B1 onClick="window.open('badguylist.pl', 'badguylistwindow', '');">
<input type="submit" value="�h�X�C��" $STYLE_B1 onClick="parent.top.location.replace('safeout.cgi')">
</form>
<form action=$MAIN_SCRIPT method=POST target=_self name="autoref">
<input type=hidden name=cmd value=MAIN_FRAME>
<input type=hidden name=pname value=$FORM{'pname'}>
<input type=hidden name=pass value=$FORM{'pass'}>
<input type="submit" name="refpage" value="�W�h��s" $STYLE_B1 onClick="parent.Sub.location.replace('$MAIN_SCRIPT?LOGO');">
</form>
</td>
</tr>
</table>
</div>
---HTMLTAG----





#============== Show Character Name and Picture and Location========
if ($CurrentPlanetImg eq "")
{
$CurrentPlanetImg="earth.gif";
}	


#=================================================================
print << "---HTMLTAG----";

<table border="1" width="100%" height="160">
  <tr>
<td width="17%" valign="top" rowspan="3" height="0"> 
$PublishOnMain<hr>

<form action=$MAIN_SCRIPT name='FM2' method='POST' target="Sub">
<input type=hidden name=cmd >
<input type=hidden name=pname value=$FORM{'pname'}>
<input type=hidden name=pass value=$FORM{'pass'}>
<p>
<input type=submit name='b_mode' value='�԰�' $STYLE_B1 onClick="document.FM2.cmd.value='BATTLE_1';">
<input type=button value="����" $STYLE_B1 onClick="parent.Sub.location.replace('repaircenter.pl')">
<input type=button value="�޲z" $STYLE_B1 onClick="parent.Sub.location.replace('userselfdel.pl')">
<input type=button value="����" $STYLE_B1 onClick="parent.Sub.location.replace('newreport.pl')">
<input type=submit name="custom" value="��y" $STYLE_B1 onClick="document.FM2.cmd.value='CUSTOMING';">     
<input type=button value="�˺�" $STYLE_B1 onClick=\"window.open('http://www.frwonline.com/ebs/item.htm', 'ItemManager', 'width=800,height=600,top=50,left=50,toolbar=0,location=0,directories=0,status=0,menubar=0,scrollbars=1,resizable=1')\">
<input type=button value="���" $STYLE_B1 onClick=\"window.open('http://www.7era.com/cgi-bin/bigsell_cgi/search.pl?tw+list', 'ItemSell', 'width=800,height=600,top=50,left=50,toolbar=0,location=0,directories=0,status=0,menubar=0,scrollbars=1,resizable=1')\">

<input type=button value="�դO" $STYLE_B1 onClick="parent.Sub.location.replace('ballance.cgi')">
<input type=submit name="custom" value="���U" $STYLE_B1 onClick="document.FM2.cmd.value='BOUGU';">
<input type=button value="��s" $STYLE_B1 onClick="document.autoref.submit()">
<input type=button value="�䥦�\\��" $STYLE_B1 onClick="visible_object('OtherFeature')">
<input type=button value="�԰��O��" $STYLE_B1 onClick="visible_object('FightRecord')">
<input type=button value="�Z���ޯ�" $STYLE_B1 onClick="visible_object('WeaponSkillCheck')">
<input type=button value="�䥦��T" $STYLE_B1 onClick="visible_object('ShowOtherInf')">
</p>
</form>
<p>
<form action="repaircenter.pl?move" method=POST target=Sub>   
<input type=hidden name=pname value=$FORM{'pname'}>   
<input type=hidden name=pass value=$FORM{'pass'}>   
<input type=submit name="OK" value="�}���©����פ���" $STYLE_B1>   
</form>
<form action="countrylist.pl" method=POST target=Sub>   
<input type=hidden name=pname value=$FORM{'pname'}>   
<input type=hidden name=pass value=$FORM{'pass'}>   
<input type=submit name="mycountry" value="����" $STYLE_B1 >
<input type=submit name="info" value="����" $STYLE_B1 >
</form>
<hr>
�a�Ϩt�� :
<form action="intermove.pl?move" method=POST target=Sub>
<input type=hidden name=pname value=$FORM{'pname'}>
<input type=hidden name=pass value=$FORM{'pass'}>
<input type=submit name="movemode" value="�_" $STYLE_B1>
<input type=submit name="movemode" value="�n" $STYLE_B1>   
<input type=submit name="movemode" value="�F" $STYLE_B1>   
<input type=submit name="movemode" value="��" $STYLE_B1>   
</form>   
   </p>



</td>       
    <td valign="top" height="1" colspan="3">
<p align="center">
�ӤH��� ��Ū.<A href="$CL_VALUES[21]" target="_blank" ><font color="red">���ꤽ����</font></A><br>       
    </td>       
    <td width="20%" valign="top" style="text-indent: 0; word-spacing: 0; margin: 0" rowspan="3" height="154">       
<TABLE border="1" cellSpacing=0 cellPadding=0 bgcolor="#A7AE97"><TR>
<TD>�ثe�˳ƪZ�� </TD> 
  </TR><TR>  
<TD >  
<b><font color=#ccffcc>$WN_sA[0]</font></b><font color=#C0C0C0><small>  
$WEX_sA[0]<br> 
<B class=num>����EN: $WN_sA[4]</B><br>
</small></font><small>����</small><small>:$WLV_A:�g��</small><small>:$WEP_A</small><BR> 
<span style=\"$STYL1\">��\��\:��G$WeaponAttPower&nbsp;�R�G$WeaponHitPower�^�G$WN_sA[3]<BR>�S���ĪG:  
$ShowWeaponSpecial<br>  
  <b>���U���~:$BG_sA[0]</b><br>  
  ��\��\: ���G$BG_sA[1]���G$BG_sA[2]�R�ɡG$BG_sA[3]��ɡG$BG_sA[4]�@�[�G$BGT_A<br>  
</TD></TR></TABLE> 


�@       
</td>       
</tr>       
  <tr>
    <td width="17%" valign="top" height="0">
HP:<SPAN><b id=j_hp>$PL_VALUES[15]</b>/<B>$PL_VALUES[16]</B>[<span id=cond>$CONDITIONAL</span>]</span><br>
EN:<SPAN><b id=j_en>$PL_VALUES[17]</b>/<B>$PL_VALUES[18]</B></SPAN><br>
<img src=$IMG_FOLDER3/$PL_VALUES[100].gif>
<img src=$IMG_FOLDER2/$PL_VALUES[27].gif><br>       
$FORM{pname} $RankShow <font size=3>&nbsp;<b>$PL_VALUES[3]</b></font><br>


<img src="$IMG_FOLDER0/$CurrentPlanetImg"></td>       
    <td width="12%" valign="top" style="text-indent: 0; word-spacing: 0; margin: 0" height="0">       
<div style="font-size=10px;">       
�s�������P��:$PL_VALUES[24]<br>       
�i�ɥ@�N��:$JIZHUISHU<br>�@�N:$PL_VALUES[23]��<br>       
���y:$PL_VALUES[5]<br>       
�ӤH����:$PL_VALUES[29]<br>       
�g��:$PL_VALUES[30]/$NEXT<br>       
�ʮ�:$CharacterShow<br>       
�԰��^��:$PL_VALUES[32]<br>       
�ӧQ��:$PL_VALUES[33]<br>       
�Ӳv:$syouritu�H <br>       
����:$TypeShow��<br>       
���: $PL_VALUES[8]       
       
</div>       �@
</td>       
    <td width="9%" valign="top" style="text-indent: 0; word-spacing: 0; margin: 0" height="0">       
��:$AttPointShow<br>
��:$ProPointShow<br>
�R:$SpdPointShow<br>
�t:$HitPointShow<br>
�y��: $PL_VALUES[95],$PL_VALUES[96]
</td>       
</tr>       
</table>
---HTMLTAG----



#=================================================================

print << "---JAVASCRIPTCODE------";
<script LANGUAGE="JavaScript">
<!--
var autoreftime=$AutoRefTime;
var counter=autoreftime;
function autorefpage()
{
document.autoref.refpage.value=counter+"��s";
counter--;

if (counter <= 0)
{
counter=0;
document.autoref.submit();
}	


if (counter >0)
{
setTimeout('autorefpage()',1000);   
}


}

if (autoreftime != 0){autorefpage();}

//-->
</script>         

---JAVASCRIPTCODE------

#=================================================================


print "</tr><tr><td width=33%></td><td width=4%></td>";
if($CL_VALUES[7] > time){
	print "<br>&nbsp;&nbsp;<b>�� ��</b>&nbsp;&nbsp;&nbsp;&nbsp;<b style=\"color:$CL_VALUES[0];\">$CL_VALUES[5]</b> Limit:";
	print &DATE_DECORD("$CL_VALUES[7]")."<br>&nbsp;&nbsp;<b>����</b>&nbsp;&nbsp;";
	print "&nbsp;&nbsp;<b>$CL_VALUES[6] ���ꪺ�𲤤έn�몺�}�a</b>";
}


print "<script language=\"JavaScript\">location.href='#top';\n</script>\n" if $BANNER_DISPLAY;
print << "	-----END-----"if $ENV{'HTTP_USER_AGENT'} =~ m/MSIE/i;
	<script language="JavaScript">
	var h=$PL_VALUES[15];var e=$PL_VALUES[17];var timerID;
	myDate1 = new Date();
	var m_time=myDate1.getTime();
	HERepair();
	function HERepair(){
	myDate2 = new Date();
		n_time=myDate2.getTime();
		sasi = (m_time - n_time)/-1000;

		if (h < $PL_VALUES[16]){h = $PL_VALUES[15] + sasi*$HP_REPAIR;}else{h = $PL_VALUES[16];}
		if (e < $PL_VALUES[18]){e = $PL_VALUES[17] + sasi*$EN_REPAIR;}else{e = $PL_VALUES[18];}
		if (h >= $PL_VALUES[16] && cond.innerText=='��'){
			cond.innerText='��';cond.style.color='#143dc1';
		}
		j_hp.innerText=Math.round (h);
		j_en.innerText=Math.round (e);
		clearTimeout(timerID);
		timerID = setTimeout(\"HERepair()\",500);
		}
		</script>
	-----END-----
	exit;
}

sub CUSTOMIZE{
	&LOCK;
	&DBM_CONVERT('P',"$FORM{pname}");$flagp=1;
	&DBM_CONVERT('C',"$PL_VALUES[5]") if $PL_VALUES[5];
	&UNLOCK;
	$PL_VALUES[5]='' if $PL_VALUES[5] && !@CL_VALUES;
	$PL_VALUES[6]='0' if !$PL_VALUES[5];
	if ($PL_VALUES[28]){
		foreach ("$CL_VALUES[2]","$CL_VALUES[3]","$CL_VALUES[4]"){if ($PL_VALUES[28] eq "$_") {$DeleteFlag=1;}}
		if (!$DeleteFlag){$PL_VALUES[6]=$PL_VALUES[28]="";}
	}
$_="$FORM{'Cmode'}";

CheckPassword($FORM{'pass'},$PL_VALUES[2]);

CUSTOM:{
	/^CUSTOM��$/ && do{my($wk,$wl) = split(/!/,$PL_VALUES[9]);
		if ($FORM{'wname'} =~ m/^$wk/){$PL_VALUES[9]="$FORM{'wname'}!0";}last CUSTOM;
	};
/^���U�ʤJ$/ && do{my @www=split(/\,/,$BOUGU_LIST{"$FORM{'buyb'}"}); 
$PL_VALUES[8]-=$www[5];$PL_VALUES[41]="$FORM{'buyb'}!$www[9]"; 
last CUSTOM;}; 
/^���U�˸m�X��$/ && do{$SB=$PL_VALUES[41]; 
my($bk,$bl)= split(/!/,$SB);my@www=split(/\,/,$BOUGU_LIST{"$bk"}); 
if ($PL_VALUES[41])
{
 $PL_VALUES[41]='';$PL_VALUES[8]+=int $www[5]/3;
 &record_fight($FORM{'pname'}," ","���U�˸m�X��,�ثe��$PL_VALUES[8]G");
}  

	last CUSTOM;};
	/^Custom$/ && 
	do{
		if ($PL_VALUES[24] < $CumNumber)
		{
		 $PL_VALUES[23]-=2;
		 $PL_VALUES[8]-=200000;
		}
		$PL_VALUES[24]=$PL_VALUES[24]-$CumNumber;$PL_VALUES[8]-=20000;$PL_VALUES[23]++;$PL_VALUES[27]=$FORM{'icon'};
		$PL_VALUES[13]=$FORM{'MsColor'};$PL_VALUES[4]=$FORM{'MsType'};$PL_VALUES[3]=$FORM{'MsName'};
	
	
	last CUSTOM;
	
	};
	/^�y���ܧ�$/ && do{$PL_VALUES[100]=$FORM{'icon'};last CUSTOM;};
	/^HP�p�q�ɯ�$/ && do{$PL_VALUES[8]-=$PL_VALUES[16]+5000;$PL_VALUES[16]+=200 if $PL_VALUES[16] < $MAX_HP;$PL_VALUES[16]=$MAX_HP if $PL_VALUES[16] > $MAX_HP;last CUSTOM;};
	/^EN�p�q�ɯ�$/ && do{$PL_VALUES[8]-=$PL_VALUES[18]*10+5000;$PL_VALUES[18]+=5 if $PL_VALUES[18] < $MAX_EN;$PL_VALUES[18]=$MAX_EN if $PL_VALUES[18] > $MAX_EN;last CUSTOM;};
	/^HP���q�ɯ�$/ && do{$PL_VALUES[8]-=($PL_VALUES[16]+5000)*5;$PL_VALUES[16]+=1000 if $PL_VALUES[16] < $MAX_HP;$PL_VALUES[16]=$MAX_HP if $PL_VALUES[16] > $MAX_HP;last CUSTOM;};
	/^EN���q�ɯ�$/ && do{$PL_VALUES[8]-=($PL_VALUES[18]*10+5000)*5;$PL_VALUES[18]+=25 if $PL_VALUES[18] < $MAX_EN;$PL_VALUES[18]=$MAX_EN if $PL_VALUES[18] > $MAX_EN;last CUSTOM;};
	/^HP�j�q�ɯ�$/ && do{$PL_VALUES[8]-=($PL_VALUES[16]+5000)*7;$PL_VALUES[16]+=1400 if $PL_VALUES[16] < $MAX_HP;$PL_VALUES[16]=$MAX_HP if $PL_VALUES[16] > $MAX_HP;last CUSTOM;};
	/^EN�j�q�ɯ�$/ && do{$PL_VALUES[8]-=($PL_VALUES[18]*10+5000)*7;$PL_VALUES[18]+=35 if $PL_VALUES[18] < $MAX_EN;$PL_VALUES[18]=$MAX_EN if $PL_VALUES[18] > $MAX_EN;last CUSTOM;};

	/^�ܧ�$/ && do{$PL_VALUES[7]="$FORM{'com'}";last CUSTOM;};
	/^�Z���j��$/ && do{my @www=split(/\,/,$WEAPONEX_LIST{"$FORM{'buyww'}"});
	&LOCK;&DBM_CONVERT('P',"$FORM{pname}");&UNLOCK;
	local($WN_A,$WLV_A,$WEX_A) = split(/!/,$PL_VALUES[9]);
	@WN_sA=split(/\,/,$WEAPON_LIST{"$WN_A"});
$PL_VALUES[8]-=100000;$PL_VALUES[24]=300;
		if ($PL_VALUES[9]){$PL_VALUES[9]="$WN_A!0!$FORM{'buyww'}";}
	last CUSTOM;};
/^����$/ && do{$PL_VALUES[39]="$FORM{'hicom'}";last CUSTOM;};
/^�W��$/ && do{$PL_VALUES[66]="$FORM{'cicom'}";last CUSTOM;};
/^?�U�ʤJ$/ && do{my @www=split(/\,/,$BOUGU_LIST{"$FORM{'buyb'}"}); 
$PL_VALUES[8]-=$www[5];$PL_VALUES[41]="$FORM{'buyb'}!$www[9]"; 
last CUSTOM;}; 
/^���U�˸m�X��$/ && do{$SB=$PL_VALUES[41]; 
my($bk,$bl)= split(/!/,$SB);my@www=split(/\,/,$BOUGU_LIST{"$bk"}); 
if ($PL_VALUES[41]){$PL_VALUES[41]='';$PL_VALUES[8]+=int $www[5]/3;} 
last CUSTOM;}; 
/^�x��$/ && do{$PL_VALUES[31]="$FORM{'bacom'}";last CUSTOM;}; 




/^�`�R$/ && do{

if($FORM{'boumeiC'} ne '')
{
my$c_cnt = 0;&DBM_INPORT(P);
if(($PL_VALUES[5] eq $PRISON_NATIONALITY) or  ($PL_VALUES[5] eq $ENEMY_NATIONALITY))
{
&ERROR("�A�w�Q�����ʵL�k�`�R");
}

while (($C_Name,$C_Value) =each %C) 
{
@C_VALUES = split(/\s/,$C_Value);
while(my($key,$value) = each %P)
{
my@MEMBER_VALUE = split(/\s/,$value);
if($FORM{'boumeiC'} eq "$MEMBER_VALUE[5]" && ++$c_cnt >= $C_VALUES[14])
	{
	&ERROR("$FORM{'boumeiC'}��a�̤j�H�ƨ�F�B�`�R���O�L�ġC");
	}
}

}
}
$PL_VALUES[5]="$FORM{'boumeiC'}";$PL_VALUES[28]='';$PL_VALUES[0]=$PL_VALUES[6]=0;
last CUSTOM;
};
	/^�J��$/ && do{$PL_VALUES[28]="$FORM{'inunit'}";last CUSTOM;};
	/^����$/ && do{$PL_VALUES[28]="";$PL_VALUES[6]="0";last CUSTOM;};
	/^�����s��$/ && do{&ERROR('�����W�|����J') if !$FORM{'uname'};
		&DBM_INPORT(C);&ERROR('�o�Ӱ�a���s�b') if !$C{"$PL_VALUES[5]"};
		$flagc=1;
		$PL_VALUES[8]-=$MAKE_TEAM;$PL_VALUES[28]="$FORM{'uname'}";$PL_VALUES[6]=-1;
		UNIT:for ($i=2;$i <= 4; $i++){if (!$CL_VALUES[$i]){$CL_VALUES[$i]="$FORM{'uname'}";last UNIT;}}
	last CUSTOM;};
	
	
	$FORM{'cname'} =~ s/\"//g;    
	
	/^�ذ�$/ && do{&DBM_INPORT(C);&ERROR('�M�w�إߪ���a���W') if ($C{"$FORM{'cname'}"} or ($FORM{'cname'} eq "$NONE_NATIONALITY"));
	        
	        
	        if (! -e "$EventRecordDir/countrymenu.dat")
	        {
		@CountryMenu[0]="";
	        write_file("$EventRecordDir/countrymenu.dat",@CountryMenu);
		}
		
	        @CountryMenu=read_file("$EventRecordDir/countrymenu.dat");
	        foreach $SerachCountry(@CountryMenu)
	        {
	         $Buffer=$SerachCountry;
	         chop($Buffer);
	         if ($Buffer eq $FORM{'cname'})
	         {
	          &ERROR('����a�w���`! �L�k�A�ذ�!');
	         }	
	        }	
	        
	        @CountryMenu[@CountryMenu+0]="$FORM{'cname'}\n";
	        write_file("$EventRecordDir/countrymenu.dat",@CountryMenu);
	        
		&ERROR(noName) if $FORM{'cname'} eq '';@CL_VALUES='';$Moto="$PL_VALUES[5]" if $PL_VALUES[5];
                $PL_VALUES[8]-=$MAKE_COUNTRY;$PL_VALUES[5]="$FORM{'cname'}";$PL_VALUES[0]=200;$PL_VALUES[6]=1;
		$CL_VALUES[0]='#'.$FORM{'cl'};$CL_VALUES[1]=10000;$CL_VALUES[7]=0;
		$CL_VALUES[11]="$YOUSAI_HP!$YOUSAI_HP!$DATE";$CL_VALUES[12]="1!1!1!$FORM{'cname'}���ín��";$CL_VALUES[14]=20;$flagc=1;
		$CL_VALUES[16]=$YOUSAI_PRO;
		$CL_VALUES[19]=(time);
		$HISTORY="$FORM{'pname'} �ذ� $FORM{'cname'}�C�̰����ɪ�$FORM{'pname'}�P�ɴN��" if !$Moto;
		$HISTORY="$FORM{'pname'} �إ�$FORM{'cname'}�P�ɫŧG�W�ߡC��$Moto�o�G�F�W�߫Ũ�" if $Moto;
	last CUSTOM;};
/^����$/ && $PL_VALUES[5] && $PL_VALUES[6] == 1 && do{&DBM_INPORT(C);&ERROR('��a�ä��s�b�C') if !$C{"$PL_VALUES[5]"};
$flagc=1;
$CL_VALUES[14]="$FORM{'ckisei'}";
$CL_VALUES[1]-=5000;
last CUSTOM;};
	/^�Ѵ�$/ && $PL_VALUES[5] && $PL_VALUES[6] == 1 && do{$flagc=1;$flagp=0;
		&DBM_INPORT(C);&ERROR('�o�Ӱ�a���s�b') if !$C{"$PL_VALUES[5]"};
		$CL_VALUES[2]='' if $FORM{'delunit'} eq "$CL_VALUES[2]";
		$CL_VALUES[3]='' if $FORM{'delunit'} eq "$CL_VALUES[3]";
		$CL_VALUES[4]='' if $FORM{'delunit'} eq "$CL_VALUES[4]";
	last CUSTOM;};
	/^�o��$/ && $PL_VALUES[5] && $PL_VALUES[6] == 1 && $CL_VALUES[7] < time && do{
		&DBM_INPORT(C);&ERROR('�o�Ӱ�a���s�b') if !$C{"$PL_VALUES[5]"};
		$flagc=1;$flagp=0;
		$CL_VALUES[7]=time+7200*$FORM{'kikan'};$CL_VALUES[1]-=$FORM{'dmmy'};
		$CL_VALUES[6]="$FORM{'main'}";$CL_VALUES[5]="$FORM{'mname'}";
		$CL_VALUES[8]="$FORM{'u1'}";$CL_VALUES[9]="$FORM{'u2'}";$CL_VALUES[10]="$FORM{'u3'}";
		$HISTORY="$PL_VALUES[5]�ŧG$FORM{'mname'}�}�l�C" if $FORM{'mname'} =~ /�@��$/ ;
		$HISTORY="$PL_VALUES[5]��$FORM{'mname'}�@�Եo��,�ﹳ�O$CL_VALUES[6]���n$CL_VALUES[8]�C" if !$HISTORY;
	last CUSTOM;};
	$FORM{'yousaiCheck'} && $PL_VALUES[6] != 0 && $PL_VALUES[5] && do{
		&DBM_INPORT(C);&ERROR('�o�Ӱ�a���s�b') if !$C{"$PL_VALUES[5]"};
		@Y_HP=split(/!/,$CL_VALUES[11]);
		@Y_ST=split(/!/,$CL_VALUES[12]);$flagc=1;$flagp=0;
		if ($FORM{'Cmode'} eq "�^�Фj"){$Y_HP[0]+=int($Y_HP[1]*0.2);$CL_VALUES[1]-=1000;}
		if ($FORM{'Cmode'} eq "�^�Ф�"){$Y_HP[0]+=int($Y_HP[1]*0.5);$CL_VALUES[1]-=10000;}
		if ($FORM{'Cmode'} eq "HP�j��"){$Y_HP[1]+=5000;$CL_VALUES[1]-=50000;}
		if ($FORM{'Cmode'} eq "�����O�j��"){$Y_ST[0]++;$CL_VALUES[1]-=10000;}
		if ($FORM{'Cmode'} eq "���m�O�j��"){$Y_ST[1]++;$CL_VALUES[1]-=10000;}
		if ($FORM{'Cmode'} eq "�R���O�j��"){$Y_ST[2]++;$CL_VALUES[1]-=10000;}
		
		$CountryMoney=$CL_VALUES[1];
		
		if ($FORM{'Cmode'} eq "�n��Z���ɯ�") 
		{
		
		if (($CountryMoney-10000000) <0 ) {&ERROR('�������!');}
		
		$CL_VALUES[20].="";
		if (length($CL_VALUES[20]) < 6)
		{
		$CL_VALUES[20].="z";
		$CL_VALUES[1]-=20000000;
		}
		else
		{
		&ERROR('�o�w�O�̲תZ��');
		}
		
		}
		
		$CL_VALUES[11]="$Y_HP[0]!$Y_HP[1]!$Y_HP[2]";
		$CL_VALUES[12]="$Y_ST[0]!$Y_ST[1]!$Y_ST[2]!$Y_ST[3]";
	last CUSTOM;};
	/^�Z����y$/ && do{my($wa,$waa)= split(/!/,$PL_VALUES[9]);my($wb,$wbb)= split(/!/,$PL_VALUES[10]);@PW_A=split(/\,/,$WEAPON_LIST{"$wb"});if ($PW_A[8] && $PW_A[8]!=1) {$PL_VALUES[9]="$PW_A[8]!0";$PL_VALUES[10]='';}last CUSTOM;};
	/^���$/ && do{if ($PL_VALUES[29]>299 && $PL_VALUES[8]>$PL_VALUES[29]*10000) {$PL_VALUES[8]-=$PL_VALUES[29]*10000;$PL_VALUES[29]=1;$PL_VALUES[30]=0;$PL_VALUES[19]=int($PL_VALUES[19]*0.9);$PL_VALUES[20]=int($PL_VALUES[20]*0.9);$PL_VALUES[21]=int($PL_VALUES[21]*0.9);$PL_VALUES[22]=int($PL_VALUES[22]*0.9);}last CUSTOM;};

/^�~��$/ && do
{
&DBM_INPORT(P);
		while (my($key,$value) = each %P)
		{
			my @VS_VALUE = split(/\s/,$value);
			if(($PL_VALUES[5] eq $VS_VALUE[5]) && ($VS_VALUE[0] eq '200')){&ERROR('�w�g���䥦���a�N���F�o�Ӧ�m');}
			if(($PL_VALUES[5] eq $VS_VALUE[5]) && ($VS_VALUE[6] eq '1')){&ERROR('�w�g���䥦���a�N���F�o�Ӧ�m');}
		}


while (my($key,$value) = each %P){my@VS_VALUE = split(/\s/,$value);
if ($FORM{'atotugi'} eq $key) {$VS_VALUE[6]='1';$VS_VALUE[28]='';$PL_VALUES[0]=0;$PL_VALUES[6]=0;
$HISTORY="<font color=white> $PL_VALUES[5]</font>���`��<font color=blue>$FORM{'pname'} </font>�Q�w�F�s���~�ӤH�C�s���~�ӤH<font color=blue>$FORM{'atotugi'}</font>�~�Ӥ���C";
dbmopen (%PL,"$DBM_P",0666);$PL{"$FORM{'atotugi'}"}="@VS_VALUE";dbmclose %PL;
}
}
last CUSTOM;};
	/^�Ѷ�$/ && $PL_VALUES[5] && $PL_VALUES[6] == 1 && do{&DBM_INPORT(P);

while (my($key,$value) = each %P){my@VS_VALUE = split(/\s/,$value);
if ($FORM{'delunit'} eq $key) {
$VS_VALUE[5]='';
$VS_VALUE[6]='0';
$VS_VALUE[28]='';
dbmopen (%PL,"$DBM_P",0666);$PL{"$FORM{'delunit'}"}="@VS_VALUE";dbmclose %PL;
}
}
last CUSTOM;};

    /^�Z���اe$/ && do{&DBM_INPORT(P);
if($PL_VALUES[67] eq 1){&ERROR("�]�H�W�Q��L�k�Z���اe!");}
if($VS_VALUES[67] eq 1){&ERROR("�]�H�W�Q��L�k�Q�Z���اe!");}
if($PL_VALUES[16] < $NoSpecialHP){&ERROR("�]HP���� $NoSpecialHP �L�k�Z���اe!");}
@spwnID=split(/!/,$PL_VALUES[9]);
@spwn=split(/\,/,$WEAPON_LIST{@spwnID[0]});
my $WeaponName=@spwn[0];
my $WeaponType=@spwn[9];
if (rindex ($WeaponName,'�]��') ne -1){&ERROR("�]�k�ޯ�L�k�اe!�и��]�k�v�žǲ�");}

         while (my($key,$value) = each %P){my@VS_VALUE = split(/\s/,$value);
             if ($FORM{'hito'} eq $key){
                 if (!$VS_VALUE[10])
                 {
                 $VS_VALUE[10]=$PL_VALUES[9];$GiveWeaponID=$PL_VALUES[9];
                 $PL_VALUES[9]=$PL_VALUES[10];$PL_VALUES[10]=$PL_VALUES[11];
                 $PL_VALUES[11]=$PL_VALUES[98];$PL_VALUES[98]=$PL_VALUES[99];
                 $PL_VALUES[99]="";
                 }
                     elsif (!$VS_VALUE[11]){$VS_VALUE[11]=$PL_VALUES[9]; $GiveWeaponID=$PL_VALUES[9];$PL_VALUES[9]=$PL_VALUES[10];$PL_VALUES[10]=$PL_VALUES[11];$PL_VALUES[11]=$PL_VALUES[98];$PL_VALUES[98]=$PL_VALUES[99];$PL_VALUES[99]="";}
                   else {&ERROR("$FORM{'hito'}�ƪZ\�ŵL�@��,�����ذe�L�H");}
                     #$PL_VALUES[9]="66";
                     
                     ($ItemID,$ItemPoint)= split(/!/,$GiveWeaponID);
			@ItemName=split(/\,/,$WEAPON_LIST{"$ItemID"});
                     $HISTORY="<font color=red> $PL_VALUES[5] </font>��<font color=red>$FORM{'pname'} </font><font color=red> $VS_VALUE[5] </font>��<font color=red></font>�� @ItemName[0] �Z���اe �� $FORM{'hito'}";
                     
$proxyip = $ENV{HTTP_X_FORWARDED_FOR};
if ($proxyip){$proxyip="�u��IP:".$proxyip;}

                     &record_fight($FORM{'pname'},"","$HISTORY");
                 dbmopen (%PL,"$DBM_P",0666);$PL{"$FORM{'hito'}"}="@VS_VALUE";dbmclose %PL;
            }
        }
    last CUSTOM;};

	/^�����N��$/ && $PL_VALUES[5] && !$PL_VALUES[6] && do{&DBM_INPORT(P);
		while (my($key,$value) = each %P){my@VS_VALUE = split(/\s/,$value);
			if($FORM{'team'} eq "$VS_VALUE[28]" && $VS_VALUE[6] == -1){&ERROR("�w�g��$key���a�N���F�o�Ӧ�m");}
		}
		$PL_VALUES[6]='-1';$PL_VALUES[28]="$FORM{'team'}";
	last CUSTOM;};
	/^�`�ӴN��$/ && $PL_VALUES[5]  && do{&DBM_INPORT(P);
		while (my($key,$value) = each %P)
		{
			my @VS_VALUE = split(/\s/,$value);
			if(($PL_VALUES[5] eq $VS_VALUE[5]) && ($VS_VALUE[0] eq '200')){&ERROR('�w�g���䥦���a�N���F�o�Ӧ�m');}
			if(($PL_VALUES[5] eq $VS_VALUE[5]) && ($VS_VALUE[6] eq '1')){&ERROR('�w�g���䥦���a�N���F�o�Ӧ�m');}
		}
		$PL_VALUES[6]='1';$PL_VALUES[0]='200';
		$HISTORY="$FORM{'pname'} ���`�ӬӫҴN���g�L $PL_VALUES[5]��ĳ�|�ӻ{$FORM{'pname'}�e���䧹�������v";
	last CUSTOM;};
}
	&ERROR('�������') if $PL_VALUES[8] < 0 || $CL_VALUES[1] < 0;
	&LOCK;
	if($flagp){dbmopen (%PL,"$DBM_P",0666);$PL{"$FORM{'pname'}"}="@PL_VALUES";dbmclose %PL;}
	if($flagc){dbmopen (%CL,"$DBM_C",0666);$CL{"$PL_VALUES[5]"}="@CL_VALUES";dbmclose %CL;}
	if($HISTORY){dbmopen (%DH,"$DBM_H",0666);$DH{"$DATE"}="$HISTORY";dbmclose %DH;}
	&UNLOCK;
}



1;