
$cfsq01="frwonline.com";#MYSQL HOST
$cfsq02="ebsdebug";#MYSQL USER
$cfsq03="Sdfs34hy6572@";#MYSQL PASSWORD
$cfsq04="ebsdebug";#MYSQL DATABASE 資料庫名稱
$cfsq05="storage09052007";#MYSQL個人資訊帳號資料 TABLE
$cfsq06="230";#MYSQL完整 資料筆數 申請個人資訊帳號資料
$cfsq07="200";#MYSQL基本序列資料筆數 申請個人資訊帳號資料
#==========外加========


#MYSQL 設定 END
$MainFieldLen=255;
$MaxIDLength=32;
$StringFieldLen=65534;
$pageMaxList = 3;#x=0-x=x+1



sub A8
{
my $Vr0,$Vr1,$Vr2,$Vr3,@Vra0,@Vra1;
if ($ENV{'REQUEST_METHOD'} eq 'POST')
   {
    read(STDIN, $Vr0, $ENV{'CONTENT_LENGTH'});
   }
   else
      {
       $Vr0=$ENV{'QUERY_STRING'};
      }
@Vra0=split(/&/,$Vr0);
foreach $Value(@Vra0) 
   {
    ($Vr1,$Vr2)=split (/=/,$Value,2);
    $Vr2=~tr/+/ /;
    $Vr2=~ s/%(..)/pack("c",hex($1))/ge;
    $FORM{$Vr1}=$Vr2;
   }
    if ($_[0] ne "")
       {
        foreach (0 .. (length($_[0])-1))
        {
         if (rindex($Vr2,substr($_[0],$_,1)) ne -1) 
             {print "This String Contents Illgle characters!";exit;}
        }
       }

$Vr3 = "$ENV{'QUERY_STRING'}";
$Vr3 =~ s/\+/ /g;
@Vra1=split(/ /,$Vr3);
return(@Vra1);
}





1;
