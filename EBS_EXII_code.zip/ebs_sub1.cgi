use AnyDBM_File;
use Fcntl;
# require 'c:/newmacross7/ebs/jcode.pl';
require 'config.cgi';
require 'debug_sub.pl';


$HASH_DATA = 'weapondata.pl';
$VER='<a target="_blank" href="http://www.7era.com/free/debug">DEBUG</a>�j��<br>(EBS EX��II PRO �ʵe����+����+¾�~+�a�Ϫ�1.2)<br>';
$MAIN_SCRIPT = 'ebs.cgi';
$STYLE_B1='style="BORDER-RIGHT: #5F9EE6 1px outset; BORDER-TOP: #fedede 1px outset; FONT-SIZE: 12px; BACKGROUND: #5F9EE6; BORDER-LEFT: #5F9EE6 1px outset; CURSOR: hand; COLOR: #000000; BORDER-BOTTOM: #5F9EE6 1px outset; HEIGHT: 16px"';
# $STYLE_B2='onMouseOver=\"style.color='#000000';style.background='#adff2f';\" onMouseOut=\"this.style.color='#adff2f';style.background='#00550c';\"';
$STYLE_L = "style=\"height:21px; color:#ffffff; font-size:12px; background:#000000; border:1 solid white; border-style:solid;\"";
$DATE=time;
$NONE_NATIONALITY="�ۥѾԤh";


$DBM_P="$LOG_FOLDER/$DB_ID1";
$DBM_C="$LOG_FOLDER/$DB_ID2";
$DBM_H="$LOG_FOLDER/$DB_ID3";
$DBM_L="$LOG_FOLDER/$DB_ID4";

@TIME = localtime(time);
#foreach (@MAINTE_TIME){if ($TIME[2] == $_) {&ERROR('�W���ɶ���');exit;}}

#if ($ENV{'HTTP_USER_AGENT'} !~ m/MSIE/i){&ERROR('�u���L�nIE�M��');exit;}

if ($ENV{'REQUEST_METHOD'} eq "POST") {
	read(STDIN, $QUERY_DATA, $ENV{'CONTENT_LENGTH'});@pairs = split(/&/,$QUERY_DATA);
	foreach (@pairs) {
		($key, $value) = split(/=/, $_);
		$value =~ tr/+/ /;$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
		$value =~ s/</&lt;/g;$value =~ s/>/&gt;/g;$value =~ s/\n//g;$value =~ s/\s//g;
		$value =~ s/\,//g;$value =~ s/=/3/g;$value =~ s/&/1/g;
		#&jcode'convert(*value,'sjis');
		$FORM{$key} = $value;
	}
	$FORM{'cmd'} && ($SUB="$FORM{'cmd'}");
}elsif($ENV{'QUERY_STRING'}){$SUB="$ENV{'QUERY_STRING'}";}

sub UpFrameMax
{
print << "-----END-----";
<script LANGUAGE="JavaScript">
<!--
top.document.all.fs1.rows = '100%, *';
//-->
</script>         
-----END-----
}	

sub DownFrameMax
{
print << "-----END-----";
<script LANGUAGE="JavaScript">
<!--
top.document.all.fs1.rows = '5%, *';
//-->
</script>         
-----END-----
}	

sub HEADER {
	print "Content-type: text/html\n\n";


	print << "	-----END-----";


	<html><head>
<meta http-equiv="Content-Language" content="zh-tw">
<meta http-equiv="Content-Type" content="text/html; charset=big5">
<title>$THIS_Title</title></head>
<LINK href=$CSSFile type=text/css rel=stylesheet>
<body background="$BackgroundImage">

<script>
<!--
function winopen(){
var targeturl="$THIS_DIR"
newwin=window.open("","top","scrollbars")
newwin.location=targeturl
}
//-->
</script>
<body bgproperties="fixed" text=#FFFFFF topmargin=0 oncontextmenu="return false;">
<style type="text/css">
<!--
#master {position:absolute; width: 200px; top: 10px; left: -145px; z-index:2; visibility:visible;}
#menu	{position:absolute; width: 18px; top: 0px; left: 145px; z-index:5; visibility:visible;}
#top	{position:absolute; width: 145px; top: 0px; left: 0px; z-index:5; visibility:visible;}
#screen {position:absolute; width: 145px; top: 6px; left: 0px; z-index:5; visibility:visible;}
#screenlinks	{position:absolute; width: 145px; top: 6px; left: 0px; z-index:5; visibility:visible;}
-->
</style>
<script language = "javascript">
<!--
var ie = document.all ? 1 : 0
var ns = document.layers ? 1 : 0
var master = new Object("element")
master.curLeft = -145;	master.curTop = 10;
master.gapLeft = 0;		master.gapTop = 0;
master.timer = null;
function moveAlong(layerName, paceLeft, paceTop, fromLeft, fromTop){
clearTimeout(eval(layerName).timer)
if(eval(layerName).curLeft != fromLeft){
if((Math.max(eval(layerName).curLeft, fromLeft) - Math.min(eval(layerName).curLeft, fromLeft)) < paceLeft){eval(layerName).curLeft = fromLeft}
else if(eval(layerName).curLeft < fromLeft){eval(layerName).curLeft = eval(layerName).curLeft + paceLeft}
else if(eval(layerName).curLeft > fromLeft){eval(layerName).curLeft = eval(layerName).curLeft - paceLeft}
if(ie){document.all[layerName].style.left = eval(layerName).curLeft}
if(ns){document[layerName].left = eval(layerName).curLeft}
}
if(eval(layerName).curTop != fromTop){
if((Math.max(eval(layerName).curTop, fromTop) - Math.min(eval(layerName).curTop, fromTop)) < paceTop){eval(layerName).curTop = fromTop}
else if(eval(layerName).curTop < fromTop){eval(layerName).curTop = eval(layerName).curTop + paceTop}
else if(eval(layerName).curTop > fromTop){eval(layerName).curTop = eval(layerName).curTop - paceTop}
if(ie){document.all[layerName].style.top = eval(layerName).curTop}
if(ns){document[layerName].top = eval(layerName).curTop}
}
eval(layerName).timer=setTimeout('moveAlong("'+layerName+'",'+paceLeft+','+paceTop+','+fromLeft+','+fromTop+')',30)
}
function setPace(layerName, fromLeft, fromTop, motionSpeed){
eval(layerName).gapLeft = (Math.max(eval(layerName).curLeft, fromLeft) - Math.min(eval(layerName).curLeft, fromLeft))/motionSpeed
eval(layerName).gapTop = (Math.max(eval(layerName).curTop, fromTop) - Math.min(eval(layerName).curTop, fromTop))/motionSpeed
moveAlong(layerName, eval(layerName).gapLeft, eval(layerName).gapTop, fromLeft, fromTop)
}
var expandState = 0
function expand(){
if(expandState == 0){setPace("master", 0, 10, 10); if(ie){document.menutop.src = "$IMG_FOLDER4/menu.gif"}; expandState = 1;}
else{setPace("master", -145, 10, 10); if(ie){document.menutop.src = "$IMG_FOLDER4/menu.gif"}; expandState = 0;}
}
//-->
</script>
	-----END-----
}

sub HEADER2 {
	print "Content-type: text/html\n\n";
	print << "	-----END-----";
	<html><head>
<meta http-equiv="Content-Language" content="zh-tw">
<meta http-equiv="Content-Type" content="text/html; charset=big5">
<title>$THIS_Title</title></head>
<LINK href="$CSSFile" type=text/css rel=stylesheet>
<body text=#FFFFFF bgcolor=#000000 topmargin=0 oncontextmenu="return false;">
	-----END-----
}

sub FOOTER	{
#�H�U�O�����t�쪩�v���D�A�Ф��n���ܡI
	print << "	-----END-----";
<br>
<center>�@��:<a href=http://members.jcom.home.ne.jp/masimaro/ target=_blank>MASIMARO</a>����$VER�x�����:<a href="http://www.ngcoms.net/" target=_blank>NET GAME.</a>�ײz:���F�b�u
	-----END-----
	print "<br>�����{���� <a href=$THIS_DIR target=_blank>$FIX_NAME </a>Last Update 2002.11.20</center>" if $FIX_NAME;
	print "</span>";
}

sub DBM_INPORT {
	$DBM = "DBM_$_[0]";
	$HASH=$_[0];
	tie %NOTE,AnyDBM_File,"$$DBM",O_RDONLY,0666;
		%$HASH=%NOTE;
	untie %NOTE;
}
sub DBM_CONVERT {
	$DBM = "DBM_$_[0]";
	$DBM_TYPE1="$_[0]L_VALUES";
	$DBM_KEY1="$_[1]";

	($DBM_TYPE2="$_[2]_VALUES",$DBM_KEY2="$_[3]") if $_[2];

	tie %NOTE,AnyDBM_File,"$$DBM",O_RDONLY,0666;
		@$DBM_TYPE1 = split(/\s/,$NOTE{"$DBM_KEY1"});
		@$DBM_TYPE2 = split(/\s/,$NOTE{"$DBM_KEY2"}) if $_[2];
	untie %NOTE;
}

sub REPAIR {
	my $DatHp=$Result=0;
	my $REPType = "$_[0]_VALUES";
	my ($DatHp,$Result) = split(/\!/,$$REPType[1]);	#?   ?   ?!�[
	$$REPType[15]+=int(($DATE-$DatHp)*$HP_REPAIR);
	if($$REPType[15] >= $$REPType[16]){
		$$REPType[15]=$$REPType[16];$$REPType[25]=0 if $$REPType[25] == 1;
	}
	$$REPType[17]+=int(($DATE-$DatHp)*$EN_REPAIR);
	if($$REPType[17] >= $$REPType[18]){$$REPType[17]=$$REPType[18];}
}

sub RANK{
my $r=int $_[0]/10;
my $K_C=('#808080','#8000ff','#8000ff','#a000e5','#00518b','#00518b','#0470a5','#0470a5','#559494','#559494','#80b280','#80b280','#80b280','#2a980b','#2a980b','#2a980b','#c0c54d','#c0c54d','#c0c54d','#c0c54d','#d27880','#d27880')[$r];

my $K_N=('���L','�G���L','�@���L','�W���L','�L��','���','�x��','���','�G����L','�@����L','�ֱL','���L','�j�L','�֦�','����','�j��','��N','�ֱN','���N','�j�N','�W�Ťj�N','����')[$r];

	my $kaikyu="<font color=$K_C>$K_N</font>";
	if ($_[2] == -3){$kaikyu='';}
	if ($_[2] == 1){$kaikyu='<font color=#f7e957>�`��</font>';}
	if ($_[2] == -1){$kaikyu.='<font color=#f7e957>�]�����^</font>';}
	if ($_[1] eq '�ۥѾԤh' || !$_[1]){$kaikyu='';}
	return $kaikyu;
}
sub STATUS_CONVERT{
	$_[1] eq 's' && do {
my $c=int $_[0]/5;$c=0 if $c < 0;$c=17 if $c > 17;
my $C_C=('#5000CC','#8000ff','#a000e5','#bf00cc','#df00a6','#ff0080','#f7e957',
'#f7e957','#f7e957','#ff0080','#ff0080','#ff0080','#ff0080','#ff0080')[$c];
my $C_R=('F','E','D','C','B','A','S','SS','SSS','ACE','NT','NT1','NT2','NT3','NT4','NT5','NT6','NT6+')[$c];
	return "<b style=\"color:$C_C;\">$C_R</b>";
	last STATUS_CONVERT;
	};
	$_[1] eq 't' && do {
		my $c=$_[0];
		my $C_C=('#ffffff','#ff0080','#f7e957','#bf00cc','#8000ff')[$c];
		my $C_R=('���q','����','���m','�ӱ�','�R��')[$c];
	return "<font face=\"Verdana\" color=$C_C>$C_R</font>";
	last STATUS_CONVERT;
	};
	$_[1] eq 'c' && do {
		my $c=$_[0];
		my $C_C=('#e20a16','#0470a5','#ffffff','#eaaaaa','#a4aaf9','#8025da','#dc143c','#D432EC','#26F710')[$c];
		my $C_R=('����','���z','���q','�E��','�N�R','�N��','ı��','�j�ƤH','New Type')[$c];
	return "<font face=\"Verdana\" color=$C_C>$C_R</font>";
	last STATUS_CONVERT;
	};
	$_[1] eq 'j' && do {
		my $c=$_[0]/100;$c=17 if $c > 17;
		my $C_C=(	'#5000CC','#8000ff','#a000e5','#bf00cc','#df00a6','#ff0080','#f7e957',
					'#f7e957','#f7e957','#ff0080','#ff0080')[$c];
		my $C_R=('F','E','D','C','B','A','S','SS','SSS','ACE','NT','NT1','NT2','NT3','NT4','NT5','NT6','NT6+')[$c];
	return "<font face=\"Verdana\" color=$C_C>$C_R</font>";
	last STATUS_CONVERT;
	};
	
}
sub DATE_DECORD	{
	my @lt = localtime($_[0]);
	$lt[4]++;
	$lt[2] = sprintf("%02d", $lt[2]);
	$lt[1] = sprintf("%02d", $lt[1]);
	return "$lt[4]��$lt[3]�� ($lt[2]:$lt[1])";
}
sub ERROR		{
	&HEADER;
	print "<script language=\"JavaScript\">\nalert('$_[0]\\n$_[1]')\;\n\n</script>";
	&FOOTER;exit;
}
sub checkserver {
$server="www.frwonline.com��frwonline.com��http://www.frwonline.com��http://frwonline.com"; #�ۤv�K�[�i�H�q�L�����} �H���Ϲj
@validserver=split(/��/, $server);
foreach $validserver(@validserver){
return if($ENV{'HTTP_REFERER'} =~ /$validserver/i);
}
print "Content-type: text/html;charset=big5\n\n";
print "�Хѥ��T���}�i�J! <a href=http://www.frwonline.com>http://www.frwonline.com</a>";
exit 0;
}
sub LOCK 	{open (LOCK, "eb.lock");flock(LOCK,2);}
sub UNLOCK  {flock(LOCK,8);close(LOCK);}

sub JScfm {
	$fct=$_[0];
	$msg=$_[1];
	print << "	END_OF_HTML";
	<script language="JavaScript">
	<!--
	function $fct (){
		if (confirm('$msg') == true){return true;}else{return false}
	}
	//-->
	</script>
	END_OF_HTML
}
sub LOGIN_CHECK{
my($char_name, $timer1, $timer2, @char_value, $login_flg, @log_data, %L_buff);
$char_name = $_[0];

$timer1 = 5; #�����w�]���^
$timer2 = 10; #�����w�]���^

if(!defined %P){ &DBM_INPORT(P); }

@char_value = split(/\s/,$P{"$char_name"});
if($char_value[26] >= time - $timer1 * 60){ $login_flg = 1; }
else{ $login_flg = 0; }

if($login_flg == 0){
if(!defined %L){ &DBM_INPORT(L); }
%L_buff = %L;
foreach $login_time (sort {$b <=> $a} keys %L_buff){

if($login_time < time - $timer2 * 60){ last; }
@log_data=split(/!/, $L_buff{"$login_time"});
if($log_data[0] eq $char_name){ $login_flg = 1;}
}
}
return $login_flg;
}


1;