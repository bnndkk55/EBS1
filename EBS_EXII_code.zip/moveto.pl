#!/usr/bin/perl
#���L���a�I���ӱN��Ʈ���
require "ebs_sub1.cgi";
require "debug_sub.pl";

sub WriteSNGMsg
    {
    my ($Message)=@_;
    $MeetTas=1;
    $AttackTime=localtime(time);
    if (!-e "tas.htm") {@tasvalue2[0]="\n\n\n\n\n\n";write_file("tas.htm",@tasvalue);}
    @tasvalue=read_file("tas.htm");
    $tasi=14;
    foreach(1..$tasi)
    {
    	@tasvalue2[$tasi]=@tasvalue[$tasi-1];
    	$tasi--;
    }	
    @tasvalue2[0]="document.write('($ENV{TZ}�ɶ� $month/$mday/$year $hours:$minutes:$second) $Message <br>');\n";
    write_file("tas.htm",@tasvalue2);
    }



print "Content-type: text/html;\n\n";
print "<html>";
&pre_get_value;
$EachMoveTimeSet=5;
$FightDeny=1;
$EarnMoneyLimit=100;
$EarnExpLimit=100;
$MeetTas=0;
$CurrentPeople="";
if ($parm1 eq ""){return;}

if ($parm1 eq "move")
{

$MoveWay=$FORM{'movemode'};
$GetUserName=$FORM{'pname'};
$GetUserPassword=$FORM{'pass'};
}
&DBM_INPORT(P);
@PL_VALUES = split(/\s/,$P{"$FORM{'pname'}"});

(@PL_VALUES[15],@PL_VALUES[25])=AutoRepair("HP",@PL_VALUES[15],@PL_VALUES[16],@PL_VALUES[25],@PL_VALUES[26]);
(@PL_VALUES[17],@PL_VALUES[25])=AutoRepair("EN",@PL_VALUES[17],@PL_VALUES[18],@PL_VALUES[25],@PL_VALUES[26]);
($PlCurrentWeaponID,$None)= split(/!/,@PL_VALUES[9]);

#if ($FORM{'pname'} eq "LORAS")

if ($PlCurrentWeaponID eq "gmspecial001")
{
@PL_VALUES[25]=0;
@PL_VALUES[10]="wya0001!0!a";
@PL_VALUES[11]="hpkubiki!0!a";
@PL_VALUES[19]=100000;
@PL_VALUES[20]=100000;
@PL_VALUES[21]=100000;
@PL_VALUES[22]=100000;
$EachMoveTimeSet=0;
#WritePldata($FORM{'pname'},@PL_VALUES);
}	

$SelfAtt=@PL_VALUES[19];
$SelfPro=@PL_VALUES[20];
$SelfSpd=@PL_VALUES[21];
$SelfHit=@PL_VALUES[22];

CheckPassword($GetUserPassword,@PL_VALUES[2]);
@ReadMoveData=read_file("movedata.dat");
#chomp (@ReadMoveData);

@ReadMapData=read_file("ebsmap1.dat");
#chomp (@ReadMapData);

$MaxIndex=@ReadMapData-1;
$MaxX=49;$MaxY=49;
$MinX=0;
$MinY=0;
$OutputMessage="";
$i=0;
$FindUser=0;
$MapPeopleDatai=0;
$MapPeopleData="";

	foreach (@ReadMoveData)
        	{
          	$userdata_line=@ReadMoveData[$MapPeopleDatai];
          	$userdata_line=mychomp($userdata_line);
        	($UserName,$UserX,$UserY) = split(/,/,$userdata_line);
             	@UserValues = split(/\s/,$P{"$UserName"});
             	($WID,$WPoint)= split(/!/,@UserValues[11]);
             	if ($WID eq "hpkubiki")
             	{
             	$MapPeopleData.="$UserName,$UserX,$UserY\n";
             	}
             	$MapPeopleDatai++;
		}

$Tda=@ReadMoveData;
$FlashUse="TotalData=$Tda";
$ix=0;

	foreach (@ReadMoveData)
        	{
          	$userdata_line=@ReadMoveData[$i];
          	$userdata_line=mychomp($userdata_line);
		($AllUserName,$AllUserX,$AllUserY) = split(/,/,$userdata_line);
		if ($AllUserName eq $GetUserName)
             	   {          	
             	    $UserName=$AllUserName;$UserX=$AllUserX;$UserY=$AllUserY;
             	    @UserValues = split(/\s/,$P{"$UserName"});
		    if ((time)-@PL_VALUES[26]< $EachMoveTimeSet) 
		    	{$NoMove=1;$OutputMessage.="���ʳt�פӧ�..����L�k�Ө�! ";}
             	    if (@PL_VALUES[25] == 1) 
             	    	{$NoMove=1;$OutputMessage.="����ײz��..�L�k����! ";}
             	    if ($NoMove eq 1) 
             	    {}
             	    else
             	    {
             	    if ($MoveWay eq "�F") {$UserX++;$IsWall=0;if ($UserX > $MaxX) {$UserX = $MaxX;$IsWall=1;}}
             	    if ($MoveWay eq "��") {$UserX--;$IsWall=0;if ($UserX < $MinX) {$UserX = $MinX;$IsWall=1;}}
             	    if ($MoveWay eq "�_") {$UserY--;$IsWall=0;if ($UserY < $MinY) {$UserY = $MinY;$IsWall=1;}}
             	    if ($MoveWay eq "�n") {$UserY++;$IsWall=0;if ($UserY > $MaxY) {$UserY = $MaxY;$IsWall=1;}}
             	    if ($MoveWay eq "��a�A��") {$IsWall=0;}
             	    
             	    if ($UserX eq "") {$UserX=0;}
             	    if ($UserY eq "") {$UserY=0;}
             	    if ($UserX > $MaxX ) {$UserX=0;}
             	    if ($UserY > $MaxY ) {$UserY=0;}
             	    $AllUserName=$UserName;$AllUserX=$UserX;$AllUserY=$UserY;
             	    }
             	    $FindUser=1;
             	   }
             	@ReadMoveData[$i]="$AllUserName,$AllUserX,$AllUserY\n";
             	$FlashUse.="&USN$ix=$AllUserName&USX$ix=$AllUserX&USY$ix=$AllUserY";
             	$i++;
            	$ix++;
       		} 
if ($FindUser ne 1)
{
@ReadMoveData[$i]="$GetUserName,0,0\n";
}	  	

@FlashUserA[0]=$FlashUse;
write_file("moveflash.dat",@FlashUserA);
write_file("movedata.dat",@ReadMoveData);
    

$OutputMessage.=SetFontAttr("2","#f105ab",0,"$GetUserName���ʨ�y��,X=$UserX,Y=$UserY ");
if ($IsWall eq 1) 
{
 $OutputMessage.=SetFontAttr("2","#ff6699",0,"$GetUserName�I��@�ӫܤj����ê��,�L�k�e�i! ");
 print"<body background=\"$IMG_FOLDER4/wall.jpg\" bgproperties=\"fixed\">";
 }
CheckOtherEnemyAndFight();
$MapIndex=($UserX*50)+$UserY;

$userdata_line=@ReadMapData[$MapIndex];
$userdata_line=mychomp($userdata_line);
local($mapx,$mapy,$PlaceAttr,$status) = split(/,/,$userdata_line);
if ($NoMove ne 1) {CheckStatus();}
($CurrentItem1ID,$None)= split(/!/,@PL_VALUES[9]);
($UBItem1ID,$None)= split(/!/,@PL_VALUES[10]);
($UBItem2ID,$None)= split(/!/,@PL_VALUES[11]);
($UBItem3ID,$None)= split(/!/,@PL_VALUES[98]);
($UBItem4ID,$None)= split(/!/,@PL_VALUES[99]);


@UBItem1Data=split(/\,/,$WEAPON_LIST{$UBItem1ID});
@UBItem2Data=split(/\,/,$WEAPON_LIST{$UBItem2ID});
@UBItem3Data=split(/\,/,$WEAPON_LIST{$UBItem3ID});
@UBItem4Data=split(/\,/,$WEAPON_LIST{$UBItem4ID});

$AttPlus=0;
$ProPlus=0;
$SpdPlus=0;
$HitPlus=0;

if (@UBItem1Data[7] eq 100) {$SpdPlus=@UBItem1Data[8];}
if (@UBItem2Data[7] eq 101) {$ProPlus=@UBItem2Data[8];}
if (@UBItem3Data[7] eq 102) {$AttPlus=@UBItem3Data[8];}
if (@UBItem4Data[7] eq 103) {$HitPlus=@UBItem4Data[8];}

$SelfAtt=@PL_VALUES[19]+$AttPlus;
$SelfPro=@PL_VALUES[20]+$ProPlus;
$SelfSpd=@PL_VALUES[21]+$SpdPlus;
$SelfHit=@PL_VALUES[22]+$HitPlus;

if (@PL_VALUES[25] == 1) 
{
$IsCanFight="����ײz��";
}
   else 
   {$IsCanFight="�i�@��!"};

$OutputMessage.=SetFontAttr("2","#f105ab",1,"$GetUserName �ثe���A:$IsCanFight ��:@PL_VALUES[8]�� HP:@PL_VALUES[15]/@PL_VALUES[16]  EN:@PL_VALUES[17]/@PL_VALUES[18] ��:$SelfAtt ��:$SelfPro �t:$SelfSpd �R:$SelfHit");

@GetOutMessage=split(/<br>/,$OutputMessage);



$MessageSize=@GetOutMessage;

$ShowMessage="var TheOutMessage = new Array($MessageSize),MaxMessageSize=$MessageSize-1,ShowIndex=0;";
$i=0;
foreach $ReadMessageData(@GetOutMessage)
{
 $ShowMessage.="TheOutMessage[$i]='$ReadMessageData';";
 $i++;
}	

$ShowMessage.="
function ShowNextMessage() 
{
  
  if (ShowIndex < MaxMessageSize) 
  {
  showallwords.innerHTML=TheOutMessage[ShowIndex]+\" ��..\";
  }
  if (ShowIndex >= MaxMessageSize) 
  {
  ShowIndex=MaxMessageSize;
  showallwords.innerHTML=TheOutMessage[ShowIndex]+\" ��\";;
  }
  ShowIndex++;
  
}
ShowNextMessage();
";

#$OutputMessage="<textarea style=\"filter: Alpha(opacity=70); rows=\"4\" name=\"showmessage\" cols=\"104\" style=\"border-style: solid\">$OutputMessage</textarea>";
print "<div id=messagescreen style=\"position: absolute; visibility: visible; z-index: 90; top: 20; left: 70;\"><table OnClick=\"ShowNextMessage()\" style=\"filter: Alpha(opacity=70); border: 1px solid #3366cc\" border=\"1\" width=\"645\" bordercolor=\"#000000\" cellspacing=\"0\" cellpadding=\"2\" height=\"72\" bordercolorlight=\"#FFFFFF\" bordercolordark=\"#C0C0C0\" bgcolor=\"#FFFDEC\"><tr><td><SPAN id=showallwords>DEBUG�]�p.</SPAN></td></tr></table></div>";
print UseJavaScript($ShowMessage);
print "</body></html>";       

sub CheckStatus
{
	 if ($status eq '�ĤH') 
	    {
	    local($mapx,$mapy,$PlaceAttr,$status,$EnemyName,$HitRate,$SayWords,$EnemyHP,$EnemyEN,$EnemyAtt,$EnemyPro,$EnemySpd,$EnemyHit,$EnemyWeapon) = split(/,/,$userdata_line);
       	    @Nothing=ShowPlaceBackground($PlaceAttr,1); 

            #$CurrentEnemyHP=1;
            ProcessMeetEnemy();
	    }
	    

	 if ($status eq '�p��') 
	    {
	    local($mapx,$mapy,$PlaceAttr,$status,$MoneyAmount) = split(/,/,$userdata_line);
       	    
       	    @Nothing=ShowPlaceBackground($PlaceAttr); 
	    $OutputMessage.=SetFontAttr("2","#f105ab",1,"$GetUserName �b$PlaceAttr �J��p�� �l��$MoneyAmount G");
	    @PL_VALUES[8]-=$MoneyAmount;
	    WritePldata($GetUserName,@PL_VALUES);
	    }

	 if ($status eq '�H') 
	    {
	    
	    local($mapx,$mapy,$PlaceAttr,$status,$CharacterName,$Words1,$Words2,$Words3) = split(/,/,$userdata_line);
       	    
       	    
       	    @Nothing=ShowPlaceBackground($PlaceAttr); 
	    $Words="�L�{�b���Q����..";
	    $GetRndNumber=int rand(5);
	    if ($GetRndNumber eq 1) {$Words=$Words1;}
	    if ($GetRndNumber eq 2) {$Words=$Words2;}
	    if ($GetRndNumber eq 3) {$Words=$Words3;}
	    
	    if ($CharacterName eq "�˳ưӤH")
	    {
	    	($CurrentItem1ID,$None)= split(/!/,@PL_VALUES[9]);
	
	     if ($CurrentItem1ID eq "3333333333")
	     {
		@PL_VALUES[9]="wsa!0!a";	     
	       $OutputMessage.=SetFontAttr("2","#f105ab",1,"�˳ưӤH ��F���q���i���� $GetUserName");
	       WriteSNGMsg("�O��GM01�{���S�O����: �˳ưӤH ��F�@�M�˳Ƶ� $GetUserName");
	    	WritePldata($GetUserName,@PL_VALUES);   
	     }	

	     if ($CurrentItem1ID eq "33333333333333")
	     {
		@PL_VALUES[9]="htlock!0!a";	     
	       $OutputMessage.=SetFontAttr("2","#f105ab",1,"�˳ưӤH ��F�ܮw�굹 $GetUserName");
	       WriteSNGMsg("�O��GM01�{���S�O����: �˳ưӤH ��F�@�M�˳Ƶ� $GetUserName");
	    	WritePldata($GetUserName,@PL_VALUES);   
	     }	
	    }	
	    
	    $OutputMessage.=SetFontAttr("2","#f105ab",1,"$GetUserName �b$PlaceAttr �J��$CharacterName $Words");
	    }
        
	 if ($status eq '�L') 
	    {
	    local($mapx,$mapy,$PlaceAttr,$status) = split(/,/,$userdata_line);
            local($IsMeet,$ExpMin,$ExpMax,$MoneyMin,$MoneyMax,$EnemyName,$HitRate,$SayWords,$EnemyHP,$EnemyEN,$EnemyAtt,$EnemyPro,$EnemySpd,$EnemyHit,$EnemyWeapon) =ShowPlaceBackground($PlaceAttr); 
            if ($IsMeet eq 1)
               {
               ProcessMeetEnemy();
               }	
	    
	    }


}	

sub ProcessMeetEnemy
{
	    $MeetRand=int(rand(100));
	    if ($MeetRand < $HitRate)
	    #if ($MeetRand < 100)
	    {
	    $WeaponName=GetItemName($EnemyWeapon);
   	    $OutputMessage.=SetFontAttr("2","#f105ab",1,"�b$PlaceAttr �J��$status $EnemyName ,HP=$EnemyHP,EN=$EnemyEN,��:$EnemyAtt,��:$EnemyPro,�t:$EnemySpd,��:$EnemyHit,�Z��:$WeaponName");
	    $OutputMessage.=SetFontAttr("2","#f105ab",1,"$EnemyName �� $SayWords");
            $NoFight=0;
	    if (@PL_VALUES[25] == 1)
	       {
	       $OutputMessage.=SetFontAttr("2","#f105ab",1,"$GetUserName ����ײz��,�L�k�԰�!");
	       $NoFight=1;
	       }
	
	   if ($NoFight eq 0)
	      {
	       $OutputMessage.=SetFontAttr("2","#f105ab",1,"$EnemyName ���� $GetUserName...�g�L�@�}��������.");
               ($SelfHPLose,$EnemyHPLose,$SelfMoney,$EnemyMoney)=CaculateFight($SelfAtt,$SelfPro,$SelfSpd,$SelfHit,$SelfWeapon,$EnemyAtt,$EnemyPro,$EnemySpd,$EnemyHit,$EnemyWeapon);
	       $CurrentEnemyHP=$EnemyHP-$EnemyHPLose;
	       @PL_VALUES[15]-=$SelfHPLose;
	       @PL_VALUES[8]+=$SelfMoney;
	       #@VS_VALUES[8]+=$EnemyMoney;
	       $CurrentTime=(time);
	       @PL_VALUES[26]=$CurrentTime;

	       if (@PL_VALUES[15] <=0) 
	     	{
     		$SelfGetExp=$ExpMin+ int rand($ExpMax/$EarnExpLimit);
     		$SelfMoney=$MoneyMin+int rand($MoneyMax/$EarnMoneyLimit);

	    	@PL_VALUES[25] = 1;
	    	@PL_VALUES[15] =0;
		$OutputMessage.=SetFontAttr("2","#f105ab",0,"$GetUserName �Q�j�}�F. �]���A�ѼĤH���W��� $SelfMoney G �g���$SelfGetExp. ");
	    	@PL_VALUES[30]+=$SelfGetExp;
	    	@PL_VALUES[8]+=$SelfMoney;
	    	}

	       if ($CurrentEnemyHP <=0) 
	        {
	       	
     		$SelfGetExp=$ExpMin+ int rand(int ($ExpMax/$EarnExpLimit));
     		$SelfMoney=$MoneyMin+int rand(int ($MoneyMax/$EarnMoneyLimit));
     		$OutputMessage.=SetFontAttr("2","#f105ab",0,"$EnemyName �Q�j�}�F. �]���A�ѼĤH���W��� $SelfMoney G �g���$SelfGetExp. ");
     		@PL_VALUES[30]+=$SelfGetExp;
	    	@PL_VALUES[8]+=$SelfMoney;
	       	}
	       $OutputMessage.=SetFontAttr("2","#f105ab",1," $GetUserName �l�� $SelfHPLose �IHP �����԰��`�@ì�o�� $SelfMoney G �g��� $SelfGetExp �I, $EnemyName �l�� $EnemyHPLose �IHP ì�o$EnemyMoney G $EnemyName�]���F!");

	      }
	    
	    #&record_fight($FORM{'pname'},$FORM{'vsname'},"$ResultTag.�ثe��$PL_VALUES[8]G $BodyharmInfo");
	    if ($MoveRecore eq 1)
	    {
	    RecordMoveFight($FORM{'pname'},$OutputMessage);
	    }
	        
	    
	    WritePldata($GetUserName,@PL_VALUES);
	   } 
}
sub ShowPlaceBackground
{
my @GetEnemyData,$RndValue;
my ($PlaceAttr,$DefaultEnemy)=@_;
if ($PlaceAttr eq "��a") 
{
 print"<body bgcolor=\"#CCFFCC\" background=\"$IMG_FOLDER4/grass.jpg\" bgproperties=\"fixed\" >";
if ($DefaultEnemy eq 1) {return;}
 $RndValue=int rand(2);
 if ($RndValue eq 1) {@GetEnemyData=MeetEnemyType(0);}
 else { @GetEnemyData=MeetEnemyType(1);}
}
if ($PlaceAttr eq "�۰�") 
{
 print"<body bgcolor=\"#D0D0D0\" background=\"$IMG_FOLDER4/rock.jpg\" bgproperties=\"fixed\">";
 if ($DefaultEnemy eq 1) {return;}
 @GetEnemyData=MeetEnemyType(3);
}
if ($PlaceAttr eq "��L") 
{
 print"<body bgcolor=\"#12DE17\" background=\"$IMG_FOLDER4/forest.jpg\" bgproperties=\"fixed\">";
if ($DefaultEnemy eq 1) {return;}
 @GetEnemyData=MeetEnemyType(4);
}
if ($PlaceAttr eq "����") 
{
 
 print"<body bgcolor=\"#FF00AA\" background=\"$IMG_FOLDER4/town.jpg\" bgproperties=\"fixed\">";
 if ($DefaultEnemy eq 1) {return;}
 }

if ($PlaceAttr eq "�s��") 
{
 print"<body bgcolor=\"#050a00\" background=\"$IMG_FOLDER4/mountain.jpg\" bgproperties=\"fixed\">";
 if ($DefaultEnemy eq 1) {return;}
 @GetEnemyData=MeetEnemyType(5);
}
return (@GetEnemyData);
}	

sub MeetEnemyType
{
my $IsMeet,$ExpMin,$ExpMax,$MoneyMin,$MoneyMax,$EnemyName,$HitRate,$SayWords,$EnemyHP,$EnemyEN,$EnemyAtt,$EnemyPro,$EnemySpd,$EnemyHit,$EnemyWeapon;
my ($EnemyNumber)=@_;
$IsMeet=0;
if ($EnemyNumber eq 0)
{
$EnemyName="�̦̦h";
$HitRate=90;$SayWords="�ڬO$EnemyName!�n��N�ӧa!����!";$EnemyHP=6000;$EnemyEN=500;
$EnemyAtt=20;$EnemyPro=10;$EnemySpd=30;$EnemyHit=10;$EnemyWeapon="aa!0";
$ExpMin=10;$ExpMax=500;
$MoneyMin=5;$MoneyMax=500;

$IsMeet=1;
}	
if ($EnemyNumber eq 1)
{
$EnemyName="�b�~�H";
$HitRate=20;$SayWords="�ڬO$EnemyName!���ߧګr�A��!";$EnemyHP=9000;$EnemyEN=100;
$EnemyAtt=30;$EnemyPro=70;$EnemySpd=90;$EnemyHit=30;$EnemyWeapon="bb!0";
$ExpMin=30;$ExpMax=700;
$MoneyMin=50;$MoneyMax=700;
$IsMeet=1;
}	
if ($EnemyNumber eq 3)
{
$EnemyName="�۩��~";
$HitRate=50;$SayWords="�ڬO$EnemyName!�ڪ����Y�i�O�ܵw��!";$EnemyHP=12000;$EnemyEN=200;
$EnemyAtt=80;$EnemyPro=170;$EnemySpd=30;$EnemyHit=30;$EnemyWeapon="ccc!0";
$ExpMin=50;$ExpMax=1000;
$MoneyMin=50;$MoneyMax=1500;

$IsMeet=1;
}	

if ($EnemyNumber eq 4)
{
$EnemyName="��";
$HitRate=70;$SayWords="�ڬO$EnemyName!���ߧڹ�A�I�k!";$EnemyHP=22000;$EnemyEN=2200;
$EnemyAtt=180;$EnemyPro=270;$EnemySpd=230;$EnemyHit=230;$EnemyWeapon="eee!0";
$ExpMin=250;$ExpMax=1500;
$MoneyMin=55;$MoneyMax=2500;

$IsMeet=1;
}	
if ($EnemyNumber eq 5)
{
$EnemyName="�i���~";
$HitRate=80;$SayWords="�ڬO$EnemyName!";$EnemyHP=52000;$EnemyEN=3200;
$EnemyAtt=280;$EnemyPro=370;$EnemySpd=330;$EnemyHit=330;$EnemyWeapon="ffff!0";
$ExpMin=450;$ExpMax=2500;
$MoneyMin=100;$MoneyMax=4500;
$IsMeet=1;
}	



return ($IsMeet,$ExpMin,$ExpMax,$MoneyMin,$MoneyMax,$EnemyName,$HitRate,$SayWords,$EnemyHP,$EnemyEN,$EnemyAtt,$EnemyPro,$EnemySpd,$EnemyHit,$EnemyWeapon);
}	



sub pre_get_value
{
# ���Φr��Χ�r��ѽX�^��Ӫ��r��
if ($ENV{'REQUEST_METHOD'} eq 'POST')
{
    read(STDIN, $temp, $ENV{'CONTENT_LENGTH'});
}
else
{
    $temp=$ENV{'QUERY_STRING'};
}

@key_value=split(/&/,$temp);

foreach $item(@key_value) 
{
    ($key,$value)=split (/=/,$item,2);
    $value=~tr/+/ /;
    $value=~ s/%(..)/pack("c",hex($1))/ge;
    $FORM{$key}=$value;
}

$buff = "$ENV{'QUERY_STRING'}";
$buff =~ s/\+/ /g;

($parm1,$parm2,$parm3)=split(/ /,$buff);
}


sub WritePldata
{
my($UserName,@DataValue)=@_;
&LOCK;
dbmopen (%P,"$DBM_P",0666);
$P{"$UserName"}="@DataValue";
dbmclose %P;
&UNLOCK;
}	

sub ReadPldata
{
my @DataValue;
my($UserName)=@_;
&LOCK;
dbmopen (%V,"$DBM_P",0666);
@DataValue= split(/\s/,$V{"$UserName"});
dbmclose %V;
&UNLOCK;
return @DataValue;
}	

sub GetItemName
{
my $ItemID,$ItemPoint,@CurrentHandItem;
($GetOneItemData)=@_;
require "$LOG_FOLDER/$HASH_DATA";
($ItemID,$ItemPoint)= split(/!/,$GetOneItemData);
@ItemName=split(/\,/,$WEAPON_LIST{"$ItemID"});
return @ItemName[0];
}

sub CaculateFight
{
my $SelfHPLose,$EnemyHPLose,$SelfMoney,$EnemyMoney;
my($SelfAtt,$SelfPro,$SelfSpd,$SelfHit,$SelfWeapon,$EnemyAtt,$EnemyPro,$EnemySpd,$EnemyHit,$EnemyWeapon)=@_;

$SelfHPLose=(($EnemyAtt+1)*($EnemySpd+1)*(int rand($EnemyHit)+1))-(($SelfPro+1)*($SelfSpd+1)*(int rand($SelfHit+1)));
$EnemyHPLose=(($SelfAtt+1)*($SelfSpd+1)*(int rand($SelfHit)+1))-(($EnemyPro+1)*($EnemySpd+1)*(int rand($EnemyHit+1)));
if ($SelfHPLose < 0) {$SelfHPLose=0;}
if ($EnemyHPLose < 0) {$EnemyHPLose=0;}
#$SelfWeapon
#$EnemyWeapon
$SelfMoney=int ($EarnMoneyLimit-$SelfHPLose);
$EnemyMoney=int ($EarnMoneyLimit-$EnemyHPLose);

if ($SelfMoney < 0) {$SelfMoney =10;}
if ($EnemyMoney < 0) {$EnemyMoney =10;}

#$SelfWeaponName=GetItemName($SelfWeapon);
$SelfWeaponName=GetItemName($SelfWeapon);

if ($SelfWeaponName eq "�����C(�K�X�Z)")
{
$EnemyHPLose = (int rand($SelfHit)+1)*1000;
$SuperHit=int rand(10);
$MaxDouble=50;

if ($SuperHit eq 2)
{
$HitAddDoub=(int rand($MaxDouble))+10;
$EnemyHPLose = $EnemyHPLose*$HitAddDoub;
$SpecialAttack="DEBUG ��X���~ ��U �� $GetUserName �W�[ $HitAddDoub �������O!";
$OutputMessage.=SetFontAttr("2","#f505ab",1,$SpecialAttack);
WriteSNGMsg("<font color=\"blue\">�O��GM01�{���S�O����: $SpecialAttack</font>");
($VSWID,$VSWPoint)= split(/!/,@VS_VALUES[9]);
	if (($HitAddDoub > $MaxDouble/1.5) && (($VSWID eq "wxa0001") or ($VSWID eq "wya0003")))
	{
	$MoveUserX=(int rand(40))+1;
	$MoveUserY=(int rand(40))+1;
	($WID,$WPoint)= split(/!/,@PL_VALUES[11]);
	if ($WID ne "hpkubiki") 
		{
		MoveLocate($GetUserName,$MoveUserX,$MoveUserY);
		$OverAttackMsg="�ѩ�$RealEnemyName����$GetUserName������..��O�ܼ��㪺�ϥζW��O�N�ͩR�O����Z�������ͥ��j���W��q! �F�M�@�n..�N$GetUserName�u��y�� $MoveUserX,$MoveUserY";
		}
		else
		{
		$OverAttackMsg="�ѩ�$RealEnemyName����$GetUserName������..��O�ܼ��㪺�ϥζW��O�N�ͩR�O����Z�������ͥ��j���W��q! �F�M�@�n..�t�I�N�N$GetUserName�u��y�� $MoveUserX,$MoveUserY ���L�٦n�L���W�˳ƭ��O�_��..�ҥH����Q�T�w�b�a�W�@�L�ʷn!";
		}	

	if ($HitAddDoub > $MaxDouble/1.1)
		{
		@ClearMoveData[0]="$MapPeopleData";
		$SpecialBuffer=@ClearMoveData[0];
		$SpecialBuffer =~ s/\n/ /g;
		$OverAttackMsg="�ѩ�DEBUG ����ӱj..�ĤH�����F�p���j�� ��O���U�@�����N�W��O�o���췥����J�Z����..����X�@���W��q! �ѼĤH�����X���}..�N�Ҧ��H����a���O�_�۪��H�u�X�a�y...���W�t�����O�۪� $SpecialBuffer �h�T�w����";
		write_file("movedata.dat",@ClearMoveData);
		}

	$OutputMessage.=SetFontAttr("2","#f505ab",1,$OverAttackMsg);
	WriteSNGMsg("<font color=\"blue\">�O��GM01�{���S�O����: $OverAttackMsg</font>");
	}

}	


#if ((@PL_VALUES[15]-$EnemyHPLose) < ($EnemyHPLose*20)) 
#{
#$MoveEnemyX=(int rand(20)+15);
#$MoveEnemyY=(int rand(10)+7);
#MoveLocate($RealEnemyName,$MoveEnemyX,$MoveEnemyY);
#$OverAttackMsg="$RealEnemyName ���� �֭n�ԱѤF..��O�k��y�� X:$MoveEnemyX,Y:$MoveEnemyY.";
#WriteSNGMsg("<font color=\"blue\">�O��GM01�{���S�O����: $OverAttackMsg</font>");
#}

$RandWords=int rand(15);
@RndWord[0]="$GetUserName ���t�I����ڻ�...";
@RndWord[1]="$RealEnemyName �� $GetUserName �����o�����O!";
@RndWord[2]="�n�ֳ�..���S��..���Ԧa�O�̯u�M�I�S���W!";
@RndWord[3]="....zzzZZZz";
@RndWord[4]="�ڭn�[�~��!";
@RndWord[5]="$RealEnemyName �n�ڻ������}..�n���M����ڤ��t�d..";
@RndWord[6]="�ثe�{�����[�̦� $CurrentPeople";
@RndWord[7]="���[���H�Y���ѾԪ��ܽ����Գ����@�I..�H�K����i��.";
@RndWord[8]="...";
if ($RandWords > 9)
{
$ChooseWords=(int rand(8));
WriteSNGMsg("�O��GM01���o����:@RndWord[$ChooseWords]");
}

}	




return ($SelfHPLose,$EnemyHPLose,$SelfMoney,$EnemyMoney);
}	






sub CheckOtherEnemyAndFight
{
$i=0;
$pl_x=380;
$pl_y=170;
$vs_x=0;
$vs_y=$pl_y-100;

print "<div id=psbody style=\"position: absolute; visibility: visible; z-index: 9999; top: $pl_y; left: $pl_x;\"><img src=\"$IMG_FOLDER2/$PL_VALUES[27].gif\" name=\"plimg\" alt=\"$GetUserName\"style=\"filter:fliph();\"></div>";
$FightResult="";
foreach (@ReadMoveData)
       	{
       	$userdata_line=@ReadMoveData[$i];
       	($RealEnemyName,$RealEnemyX,$RealEnemyY) = split(/,/,$userdata_line);
#=====================        
	if (($RealEnemyX eq $UserX) && ($RealEnemyY eq $UserY) && ($RealEnemyName ne  $GetUserName))
           {          	
	    $WriteToPl=0;
            @VS_VALUES = split(/\s/,$P{"$RealEnemyName"});
            
            $CurrentPeople.=" $RealEnemyName ,";
            if (@VS_VALUES[1] ne "")
            {
	   (@VS_VALUES[15],@VS_VALUES[25])=AutoRepair("HP",@VS_VALUES[15],@VS_VALUES[16],@VS_VALUES[25],@VS_VALUES[26]);
	   (@VS_VALUES[17],@VS_VALUES[25])=AutoRepair("EN",@VS_VALUES[17],@VS_VALUES[18],@VS_VALUES[25],@VS_VALUES[26]);
   	if (@VS_VALUES[15] < 0) {@VS_VALUES[15] = 0;}
   	if (@VS_VALUES[17] < 0) {@VS_VALUES[17] = 0;}
	    $VSAtt=@VS_VALUES[19];
	    $VSPro=@VS_VALUES[20];
	    $VSSpd=@VS_VALUES[21];
	    $VSHit=@VS_VALUES[22];
            $VSWeapon=@VS_VALUES[9];
            $NoFight=0;

          if (@VS_VALUES[27] eq "enemy1")
          {
           $FightResult.="<img src=\"$IMG_FOLDER4/$VS_VALUES[27].gif\" alt=\"$RealEnemyName\" name=\"vsimg$i\">";
          }
          else
          {
           $FightResult.="<img src=\"$IMG_FOLDER2/$VS_VALUES[27].gif\" alt=\"$RealEnemyName\" name=\"vsimg$i\">";
	  }
            $PLNoFight=0;
	    if (@PL_VALUES[25] == 1) 
	       {
	       	$IsPLCanFight="����ײz��";
	       	$PLNoFight=1;
	       }
   		else 
   		{
   		 $IsPLCanFight="�i�@��!";
   		}

            $VSNoFight=0;
	    if (@VS_VALUES[25] == 1) 
	       {
	       	$IsVSCanFight="����ײz��";
	       	$VSNoFight=1;
	       	$FightResult.=UseJavaScript("document.images['vsimg$i'].src=\"$IMG_FOLDER0/diebody.gif\"");
	       }
   		else 
   		{
   		 $IsVSCanFight="�i�@��!";
   		}

	    
	    
	    $OutputMessage.=SetFontAttr("2","#f105ab",0,"�J�� @VS_VALUES[5] �� $RealEnemyName, $RealEnemyName �ثe$IsVSCanFight HP:@VS_VALUES[15]/@VS_VALUES[16]  EN:@VS_VALUES[17]/@VS_VALUES[18] ��:$VSAtt ��:$VSPro �t:$VSSpd �R:$VSHit .");
            
	    if ((@VS_VALUES[5] eq @PL_VALUES[5]) && (@PL_VALUES[5] ne $NONE_NATIONALITY) && (@PL_VALUES[5] ne ""))
	    {
	     $VSNoFight=1;
	     $PLNoFight=1;
             $OutputMessage.=SetFontAttr("2","#f105ab",0,"...��ӬO�ۤv�H�r!���O�P@VS_VALUES[5]��..�԰�����..");	     
	    }	

	    @PL_HandWEAPONINFO=split(/!/,@PL_VALUES[9]);

	    if (($RealEnemyName eq "�{�ҰӤH") && (@PL_HandWEAPONINFO[0] eq "3"))
	    {
	     @PL_VALUES[9] = @VS_VALUES[9];
	     $OutputMessage.=SetFontAttr("2","#f105ab",0," $GetUserName��$RealEnemyName�R�F�F�� ");	     
	     WriteSNGMsg("�O��GM01�{������:$GetUserName��$RealEnemyName�R�F�F��");
	    }	
	    
	    @PL_WEAPON3INFO=split(/!/,@PL_VALUES[12]);
	    @VS_WEAPON3INFO=split(/!/,@VS_VALUES[12]);
	    if ((@PL_WEAPON3INFO[0] eq "hqkubiki") && (@VS_WEAPON3INFO[0] eq "hqkubiki") )
	    {
	     if (int (@PL_WEAPON3INFO[0]/$WEAPON_LVUP) eq int (@VS_WEAPON3INFO[0]/$WEAPON_LVUP))
	     {
	     $VSNoFight=1;
	     $PLNoFight=1;
             $OutputMessage.=SetFontAttr("2","#f105ab",0,"...��ӬO�B�ͧr!..�԰�����..");	     
             }
	    }	

            
            if (($VSNoFight eq 0) && ($PLNoFight eq 0))
            {
            ($SelfHPLose,$VsHPLose,$SelfMoney,$VSMoney)=CaculateFight($SelfAtt,$SelfPro,$SelfSpd,$SelfHit,@PL_VALUES[9],$VSAtt,$VSPro,$VSSpd,$VSHit,@VS_VALUES[9]);
            

            @VS_VALUES[15]-=$VsHPLose;
	    $CurrentTime=(time);
	    #@VS_VALUES[26]=$CurrentTime;

if (($RealEnemyName eq "���d���~") && (@VS_VALUES[25] eq 0))
    {
	WriteSNGMsg("<font color=\"#FF00FF\">�̷s��D$RealEnemyName�D��:$GetUserName ���ĤH $VsHPLose �I���ˮ`,���d���~�ثe HP �� @VS_VALUES[15] �I </font>");

	if (@PL_VALUES[25] == 1) 
	{
	 WriteSNGMsg("�O��GM01�{������:$GetUserName�P�ĤH�g�L�@�f�D��ľԤ���Q�j�}�F..�u�i��");
	}
    }


            $SelfWeaponName=GetItemName(@PL_VALUES[10]);
		if (($SelfWeaponName eq '������(�K�X�Z)') &&(@VS_VALUES[5] eq $ENEMY_NATIONALITY))
			{
			
			$ProHp=$SelfHPLose-int($SelfHPLose/1000000);
			$SelfHPLose = int($SelfHPLose/1000000);
			$OutputMessage.=SetFontAttr("2","#f105ab",0,"������(�K�X�Z)�u�N��������������� $ProHp �I�������O..");
			}	

	

	    $OutputMessage.=SetFontAttr("2","#f105ab",0,"�b$RealEnemyName ���� $GetUserName...�g�L�@�}��������.");
	    if ((@VS_VALUES[15] <=0) && (@VS_VALUES[25] ne 1))
	    {
	    	$OutputMessage.=SetFontAttr("2","#f105ab",0,"$RealEnemyName �Q�j�}�F. ");
	    	
	    	if (($RealEnemyName eq '���d���~') or ($RealEnemyName eq '�B���~'))
	    	{
	    	$OutputMessage.=SetFontAttr("2","#f105ab",0,"�A����a�o�� $RealEnemyName ���Ҧ����� @VS_VALUES[8] G. ");
	    	
		CountryIncreseMoneyValue(@PL_VALUES[5],@VS_VALUES[8]);
		WriteSNGMsg("�O��GM01�{���S�O��������: �a�a�@����$RealEnemyName �g�L�h���ϧܲש�b�@�n�G�s�n���� �Q $GetUserName �@�� ����.. @PL_VALUES[5] ����O�W�[�� @VS_VALUES[8] ");


	    	$AttackTime=localtime(time);
	    	@tasvalue[0]="document.write('�̷s��D$RealEnemyName�i��:$GetUserName ,$RealEnemyName�ثe HP �� @VS_VALUES[15] �I $RealEnemyName �Q�j�}�F.,��a�o��$RealEnemyName���Ҧ����� @VS_VALUES[8] G. (�D���ɶ�($ENV{TZ}) $AttackTime)');\n";
    		write_file("tas.htm",@tasvalue);

	    	@VS_VALUES[8] = 0;
	    	@VS_VALUES[25] = 1;

	    	@VS_VALUES[25] = 1;
	    	@VS_VALUES[15] = 0;
	    	
	    	}	


	    	if ($RealEnemyName eq '�����s') 
	    	{
	    	$IncreasePoint=2;
	    	$OutputMessage.=SetFontAttr("2","#f105ab",0,"�A����O�ȤW�ɤF. ");
		WriteSNGMsg("�O��GM01�{���S�O��������: $GetUserName �@�� ����..$RealEnemyName.....$GetUserName ���Ҧ������W�ɤF $IncreasePoint �I !");
	    	@VS_VALUES[25] = 1;
	    	@VS_VALUES[25] = 1;
	    	@VS_VALUES[15] = 0;
	    	@PL_VALUES[19]+= $IncreasePoint;
	    	@PL_VALUES[20]+= $IncreasePoint;
	    	@PL_VALUES[21]+= $IncreasePoint;
	    	@PL_VALUES[22]+= $IncreasePoint;
	    	$AttackTime=localtime(time);
		WritePldata($GetUserName,@PL_VALUES);
	    	}	

	    	$FightResult.=UseJavaScript("document.images['vsimg$i'].src=\"$IMG_FOLDER0/diebody.gif\";");
	    	
    	    }
   	    $OutputMessage.=SetFontAttr("2","#0005ab",1,"$GetUserName �l�� $SelfHPLose �IHP ì�o�� $SelfMoney G, $RealEnemyName �l�� $VsHPLose�IHP ì�o$VSMoney G ! $RealEnemyName �ثe HP�ѤU@VS_VALUES[15]  EN�|�l@VS_VALUES[17]<br>");
   	    
   	    WritePldata($RealEnemyName,@VS_VALUES);
   	    
   	      	
   	    }
  	    
           }
           }
#=====================
       	
        $i++;
        } 

$FightResult="<center><table border=\"0\" width=\"100%\" height=\"23\" cellspacing=\"0\" cellpadding=\"0\"><tr><td width=\"100%\" align=\"center\">$FightResult</td></tr></table></center>";

print "<div id=vsbody style=\"position: absolute; visibility: visible; z-index: 3; top: $vs_y; left: $vs_x;\"><center>$FightResult</center></div>";

}	


sub SetFontAttr
{
$ReturnString;
my ($FontSize,$FontColor,$IsBreakLine,$Content)=@_;
$ReturnString="<font color=\"$FontColor\" size=\"$FontSize\">$Content</font>";
if ($IsBreakLine eq 1) {$ReturnString.='<br>';}
return $ReturnString;
}	

sub UseJavaScript
{
my $OutputString;
my($ScritpContent)=@_;
$OutputString="<script LANGUAGE=\"JavaScript\">\n<!-- \n $ScritpContent \n //-->\n</script>\n";
return $OutputString;
}	

sub AutoRepair()
{
my $ReturnHP,$ReturnEN,$CurrentTime;
my($Mode,$CurrentValue,$LimitValue,$CurrentStatus,$LastFightTime)=@_;
$CurrentTime=(time);
if ($Mode eq "HP")
{
$ReturnHP=$CurrentValue+($CurrentTime-$LastFightTime)*$HP_REPAIR;
if ($ReturnHP > $LimitValue) 
   {$ReturnHP = $LimitValue;return ($ReturnHP,0);}
   else 
   {return ($ReturnHP,$CurrentStatus);}
}	

if ($Mode eq "EN")
{
$ReturnEN=$CurrentValue+($CurrentTime-$LastFightTime)*$EN_REPAIR;
if ($ReturnEN > $LimitValue) 
   {$ReturnEN = $LimitValue;return ($ReturnEN,$CurrentStatus);}
   else 
   {return ($ReturnEN,$CurrentStatus);}
}	

}	




sub RecordMoveFight
{
 my($pname,$happen)=@_;
 my $creatfile,$message,@fightdata;
 $creatfile="evenrecord/move$mday.htm";
 $message="IP $Ipaddress:$happen<br>\n";
 
 if (-e $creatfile)
 {
 @fightdata=&read_file("$creatfile");
 }
 
 @fightdata[@fightdata+1]=$message;

 &write_file("$creatfile",@fightdata);
}


sub MoveLocate
{
my ($TargetUserName,$MoveUserX,$MoveUserY)=@_;
my @ReadMoveData=read_file("movedata.dat");
my $i=0;
	foreach (@ReadMoveData)
        	{
          	$userdata_line=@ReadMoveData[$i];
          	
		if ((rindex $userdata_line,$GetUserName) ne -1)
             	   {          	
             	    
             	    ($UserName,$UserX,$UserY) = split(/,/,$userdata_line);
             	    if ($UserName eq $TargetUserName)
             	    {
             	    @ReadMoveData[$i]="$TargetUserName,$MoveUserX,$MoveUserY\n";
             	    }
             	    
             	   }
             	$i++;
             	}   
             	    
write_file("movedata.dat",@ReadMoveData);

}             

sub CountryIncreseMoneyValue
{
my ($CountryName,$Money)=@_;
#@CL_VALUES=($Color,$Money,$Term1,$Term2,$Term3,$WarName,$TargetCountry,$FightTime,$Term1TargetCountry,$Term2TargetCountry,$Term3TargetCountry,$BotaHp,$BoatName,$none,$none2,$Picture,$CountryLocation);
dbmopen (%CL,"$DBM_C",0666);
@CL_VALUES=split(/\s/,$CL{"$CountryName"});
@CL_VALUES[1]+=$Money;
$CL{"$CountryName"}="@CL_VALUES";
dbmclose %CL;
}	


sub mychomp
{
($str1)=@_;
my $ca1=chr(10),$ca2=chr(13);
$str1=~ s/$ca1//g;
$str1=~ s/$ca2//g;
return $str1;
}	