sub LOGIN2{
		@pair = split(/;/, $ENV{'HTTP_COOKIE'});
		foreach (@pair) {my($key, $value) = split(/=/, $_);$DUMMY{$key} = $value;}
	@pairs = split(/,/, $DUMMY{EB});
		foreach (@pairs) {my($key, $value) = split(/:/, $_);$COOKIE{$key} = $value;}

	
	
	print "Content-type: text/html\n\n";

	
	print << "	-----END-----";
	
	
	
	<html><head>

	<SCRIPT language=JavaScript1.2>
	function high(which2){
	theobject=which2
	highlighting=setInterval("highlightit(theobject)",50)
	}
	function low(which2){
	clearInterval(highlighting)
	which2.filters.alpha.opacity=30
	}
	function highlightit(cur2){
	if (cur2.filters.alpha.opacity<100)
	cur2.filters.alpha.opacity+=10
	else if (window.highlighting)
	clearInterval(highlighting)
	}

	</SCRIPT>
	<script language="JavaScript">
		function showform(){login.style.visibility='visible';}
		function hideform(){login.style.visibility='hidden';}
		function showdata(){data.style.visibility='visible';}
		function hidedata(){data.style.visibility='hidden';}
	</script>
	<style type="text/css">
		a:link    {font-size: 17px; text-decoration:none; color:#707070; }
		a:visited {font-size: 17px; text-decoration:none; color:#707070; }
		a:active  {font-size: 17px; text-decoration:none; color:#707070; }
		a:hover   {font-size: 17px; text-decoration:none; color:#dcdcdc; }
	</style>
	<meta http-equiv="Content-Type" content="text/html; charset=big5">
	<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<body background=$IMG_FOLDER4/star_bg.jpg bgproperties="fixed" text=#FFFFFF topmargin=0 oncontextmenu="return false;">
<style>
<!--
BODY {SCROLLBAR-FACE-COLOR: #000000; SCROLLBAR-HIGHLIGHT-COLOR: #000000; SCROLLBAR-SHADOW-COLOR: #808000; SCROLLBAR-3DLIGHT-COLOR: #FFFFFF; SCROLLBAR-ARROW-COLOR:  #FF6600; SCROLLBAR-TRACK-COLOR: #333333; SCROLLBAR-DARKSHADOW-COLOR: #000000; }
-->
</style>
<LINK href=$CSSFile type=text/css rel=stylesheet>
<a name=#top>
	<table width=100% height=100% id="login" style="position:absolute;visibility:hidden;"><tr><td align=center>
		<table border=0 cellpadding=0 cellspacing=0 $center>
		<form action=$MAIN_SCRIPT method=POST name=frm1 style=\"margin:0px 0px 0px 0px;\">
		<tr><td $center $bg_top><input type=hidden name="cmd" value="MAIN_FRAME">
		<input type=hidden name="login" value="$DATE">
		<b>�Τ�W</b></td>
		<td>&nbsp;<input type=text name="pname" value="$COOKIE{'pname'}" style="height:21px; color:#ffffff; font-size:16px; background:#000000; border:1 inset #c0c0c0;"></td><td>&nbsp;&nbsp;<a href="Javascript:hideform();"><img src=$IMG_FOLDER4/out.gif border=0></A></td></tr>
		<tr><td $center $bg_top><b>�K&nbsp;&nbsp;�X</b></td>
		<td>&nbsp;<input type=password name="pass" value="$COOKIE{'pass'}" style="height:21px; color:#ffffff; font-size:16px; background:#000000; border:1 inset #c0c0c0;">
		</td><td>&nbsp;&nbsp;<input type=image src="$IMG_FOLDER4/log.gif" name=lgn>
		</td></tr></form></table>
	</td></tr></table>
	<table width=100% height=100% id="data" style="position:absolute;visibility:hidden;"><tr><td align=center>
		<table border=0 cellpadding=0 cellspacing=0 $center style="border:0px solid;">
		<tr><td $bg_top $center $middle><font><a href="userselfdel.pl" target="_blank">�b���޲z</a></td><td><a href="Javascript:hidedata();"><img src=$IMG_FOLDER4/close.gif border=0></td>
		</tr>
		<tr><td $bg_top $center><a href="$MAIN_SCRIPT?DELETE2" target="_top">�Τ�۱�</a></td>
			</tr>
	-----END-----
	print << "	-----END-----"if $SATELLITE_FLAG;
		<tr><td $bg_top $center $middle><a href="$MAIN_SCRIPT?EXPORT" target="_top">��ƾɥX</a></td>
			</tr>
		<tr><td $bg_top $center $middle><a href="$MAIN_SCRIPT?INPORT" target="_top">��ƾɤJ</a></td>
			</tr>
	-----END-----
	print << "	-----END-----";
		<tr><td $bg_top $center $middle><a href="./weaponlist.pl" target="_blank">�Z�����</a></td>
			</tr>
		<tr><td $bg_top $center $middle><a href="$MAIN_SCRIPT?ICON" target="_blank">�Ԥh�Ϯw</a></td>
			</tr>
		</table>
	</td></tr></table>

	<table border=0 width=100% height=100%>
	<tr><td $center $middle>
	


	<img src=$IMG_FOLDER4/logo.gif><br>
	$PublishOnLOGIN
	-----END-----
	$js1="";
	print "<a href=\"Javascript:showform();\"><img border=\"0\" src=\"$IMG_FOLDER4/star_03h.gif\" onMouseOver=high(this) onMouseOut=low(this) style='filter: alpha(opacity=30); border-style: solid; border-width: 0'></a>";

	if (!$COOKIE{'pname'} && !$COOKIE{'pass'}){
	print "&nbsp;<a href=\"$MAIN_SCRIPT?ENTRY\" target=\"_top\"><img border=\"0\" src=\"$IMG_FOLDER4/star_05h.gif\" onMouseOver=high(this) onMouseOut=low(this) style='filter: alpha(opacity=30); border-style: solid; border-width: 0'></a>";
	}
	print "&nbsp;<a href=\"Javascript:showdata();\"><img border=\"0\" src=\"$IMG_FOLDER4/star_07h.gif\" onMouseOver=high(this) onMouseOut=low(this) style='filter: alpha(opacity=30); border-style: solid; border-width: 0'></a>";
	print "</td></tr></table></body></html>";

	print "<script language=\"JavaScript\">location.href='#top';\n</script>\n" if $BANNER_DISPLAY;

}
#########################
#     �U�ج[�]�m        #
#########################
sub LOG01{
	&HEADER2;
	
	


if ($CONFIG_DISPLAY){
	print "<LINK href=$CSSFile type=text/css rel=stylesheet>";
	print "<table align=center border=0 cellspacing=0 cellpadding=0>";
	print "<tr><td colspan=2></td>";
	print "<td rowspan=8 $top width=500 $center>";
	print "<br><iframe src=history.cgi name=history width=95% height=150 marginheight=0 marginwidth=0 frameborder=0 scrolling=NO></iframe>";
	print "<CENTER>";
	print << "	-----END-----";
       
        <center>
�@��:<a href=\http:/members.jcom.home.ne.jp/masimaro/\ target=_blank>MASIMARO</a>����$VER�x�����:<a href="http://www.ngcoms.net/" target=_blank>NET GAME.</a>��ײz:���F�b�u<br> ����+�ʵe+����EX���i�ƭץ�:<a href="http://www.7era.com/free/debug" target=_blank>DEBUG</a>
	-----END-----
	print "<br>���A�]�w:�԰O($FightRecordSwitch):���O($MoveRecore):�ȿ�($GiveVsMoneyInFight): �ײz $FIX_NAME </a>Last Update 05.05.2003</center>" if $FIX_NAME;
	print "��O�W��:$MaxCountryMoney <br>";
	print "</span>";
	print "</td><td colspan=2 $right></td></tr><tr>";
	print "<td $buttonl $middle>$left_c�޲z�H��</td><td $right><a href=\"mailto:$OWNER_EMAIL?subject=EBS�b�u�H��\">$OWNER_NAME</a></td>";
	print "<td $bottom>\$$MAKE_COUNTRY</td>";
        print "<td $buttonr $middle $right>�ذ�O��$left_b</td></tr>";
	print "<tr><td $buttonl $middle>$left_c���ҹϤ�</td><td $right>$ICON";
	print "" if $SPECIAL_ICON;print "</td>";
	dbmopen (%P,"$DBM_P",0666);	@ENTRy=keys %P;	dbmclose %L;
	$ENTRYS=@ENTRy;
	print "<td $middle>\$$MAKE_TEAM</td>";
	print "<td $buttonr $middle $right>�����s��$left_b</td></tr>";
	print "<tr><td $buttonl $middle>$left_c�n���W�� (�H)</td><td $right>$ENTRY_MAX</td>";
	print "<td $middle>$COUNTRY_MAX</td>";
	print "<td $buttonr $middle $right>��a�ƥ�$left_b</td></tr>";
	print "<tr><td $buttonl valign=\"middle\">$left_c�{���H�� (�H)</td><td $right>$ENTRYS</td>";
	print "<td></td>";
	print "<td $buttonr $middle $right><a href=$BBS_DIR target=_blank>�C���׾�</a>$left_b</td></tr>";
	print "<tr><td $buttonl $middle>$left_c�ɮ׫O�d (��)</td><td $right>$COOKIE_KEEP</td>";
	print "<td></td>";
	print "<td $buttonr $middle $right><a href=info.html target=_blank>�C������</a>$left_b</td></tr>";
	print "<tr><td $buttonl $middle>$left_c HP�^�_ (�C��)</td><td $right>$HP_REPAIR</td>";
	print "<td></td>";
	print "<td $buttonr $middle $right><a href=http://www.ltb.idv.tw target=_blank>�����q��</a>$left_b</td></tr>";
	print "<tr><td $buttonl $middle>$left_c EN�^�_ (�C��)</td><td $right>$EN_REPAIR</td>";
	print "<td></td>";
	print "<td $buttonr $middle $right><a href=#>���v�H��</a>$left_b</td></tr>";
	print "</table>";
}
	print "$COMMENT_2" if $COMMENT_2;

}
sub LOGO2{
	&HEADER;

#&UpFrameMax;


	print "$COMMENT_3" if $COMMENT_3;
	&FOOTER;
}

sub ICON_LIST{
&HEADER;$c=$FORM{'start'};
print "<table width=100% height=100%><tr><td align=center><img src=$IMG_FOLDER4/logo_war.gif></div><table bgcolor=#000000 cellpadding=4 cellspacing=4 style=\"border:1px solid #808080;\">";
foreach($FORM{'start'}..$ICON){$c++;
print "<tr>" if $c%7==1;
print "<td><img src=$IMG_FOLDER2/$_.gif><div align=center style=\"font-size:10pt;\">No.$_</div></td>";
print "</tr>" if $c%7==0;
last if $c>=$FORM{'start'}+35;
}
print "</table><table><tr>";
$Next=$FORM{'start'}+35;
$Back=$FORM{'start'}-35;

print << "-----END-----" if $Back >= 0;
<td><form action="$MAIN_SCRIPT" method="POST">
<input type=hidden name=cmd value="ICON">
<input type=hidden name=start value="$Back">
<input type="submit" class=button2 onMouseOver=\"style.color='#000000';style.background='#adff2f';\" onMouseOut=\"this.style.color='#adff2f';style.background='#00550c';\" value="<<�W�@��">
</form></td>
-----END-----

print << "-----END-----" if $Next <= $ICON;
<td><form action="$MAIN_SCRIPT" method="POST">
<input type=hidden name=cmd value="ICON">
<input type=hidden name=start value="$Next">
<input type="submit" class=button2 onMouseOver=\"style.color='#000000';style.background='#adff2f';\" onMouseOut=\"this.style.color='#adff2f';style.background='#00550c';\" value="�U�@��>>">
</form></td>
-----END-----
}

sub FACE_LIST{
&HEADER2;$c=$FORM{'start'};
print "<table width=100% height=100%><tr><td align=center><img src=$IMG_FOLDER4/logo_face.gif></div><table bgcolor=#000000 cellpadding=4 cellspacing=4 style=\"border:1px solid #808080;\">";
foreach($FORM{'start'}..$ICON2){$c++;
print "<tr>" if $c%7==1;
print "<td><img src=$IMG_FOLDER3/$_.gif><div align=center style=\"font-size:10pt;\">No.$_</div></td>";
print "</tr>" if $c%7==0;
last if $c>=$FORM{'start'}+35;
}
print "</table><table><tr>";
$Next=$FORM{'start'}+35;
$Back=$FORM{'start'}-35;

print << "-----END-----" if $Back >= 0;
<td><form action="$MAIN_SCRIPT" method="POST">
<input type=hidden name=cmd value="ICON2">
<input type=hidden name=start value="$Back">
<input type="submit" class=button2 onMouseOver=\"style.color='#000000';style.background='#adff2f';\" onMouseOut=\"this.style.color='#adff2f';style.background='#00550c';\" value="<<�W�@��">
</form></td>
-----END-----

print << "-----END-----" if $Next <= $ICON2;
<td><form action="$MAIN_SCRIPT" method="POST">
<input type=hidden name=cmd value="ICON2">
<input type=hidden name=start value="$Next">
<input type="submit" class=button2 onMouseOver="style.color='#000000';style.background='#adff2f';" onMouseOut="this.style.color='#adff2f';style.background='#00550c';" value="�U�@��>>">
</form></td>
-----END-----

}
1;