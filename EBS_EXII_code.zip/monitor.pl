#!/usr/bin/perl
#DEBUG ��@..�ۧ@�v,���v�Ҧ�
print "Content-type: text/html;\n\n";
require "debug_sub.pl";
require "ebs_sub1.cgi";
require 'config.cgi';
print '�Y�ɪ��p�ʵ��Y��V1.0 XP<a href="http://www.7era.com/free/debug/" target="_blank">DEBUG</a> �s�@..�ۧ@�v,���v�Ҧ�<br>';
$BossName="�ʵ�����";
&pre_get_value;
$GetUserName=$FORM{'pname'};
$GetUserPassword=$FORM{'pass'};
$Mode=$parm1;
#$GetUserName=$parm2;
if ($GetUserPassword eq "")
{
print << "-- --ENDINPUT-- - -";
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=big5">
</head>
<form method="POST" action="monitor.pl?show">
�b�� <input type="text" name="pname" size="20">
�K�X <input type="password" name="pass" size="20">
<input type="submit" value="����" name="B1">
</form>

-- --ENDINPUT-- - -

exit;
}	








$WatchSecond=5;
$WatchMoney=20;

if ($Mode eq "show")
{
MonitorNews();
}

sub MonitorNews
{
&DBM_INPORT(P);
@PL_VALUES = split(/\s/,$P{"$GetUserName"});
@Boss_VALUES = split(/\s/,$P{"$BossName"});

print "$GetUserName ��".localtime(time) ."���b�[��!";
CheckPassword($GetUserPassword,@PL_VALUES[2]);
(@CurrentFightStatus)=  split(/!/,@PL_VALUES[1]);
$CurrentFightStatus='<font size="2">';

$Tempi=0;
foreach $Value(@CurrentFightStatus)
{
 if (($Tempi % 2) eq 0) { $CurrentFightStatus.= localtime($Value)."--".((time)-$Value)."�����e<br>";}
 if (($Tempi % 2) eq 1) { $CurrentFightStatus.="$Value<BR>";}
$Tempi++;
}	
$CurrentFightStatus.='</font>';

@Repair=('�i�԰�','�ײz��');
$RepairStatus=@PL_VALUES[25];
#<iframe src=allinone.pl?showhistory name=history width=95% height=125 marginheight=0 marginwidth=0 frameborder=0 scrolling=NO></iframe>
$LastFightTime=@PL_VALUES[26];
$LastFightTimeDate=localtime($LastFightTime);
$CurrentTime=(time);
$FightBeforeSecond=$CurrentTime-$LastFightTime;
$NowAddHP=@PL_VALUES[15]+($HP_REPAIR*$FightBeforeSecond);
$NowAddEN=@PL_VALUES[17]+($EN_REPAIR*$FightBeforeSecond);

@PL_VALUES[8]-=$WatchMoney;
@Boss_VALUES[8]+=$WatchMoney;
if (@PL_VALUES[8] < 0) { print "�A�S���F!...�X�h�a!";exit;}

if ($NowAddHP > @PL_VALUES[16]) 
{
 $NowAddHP = @PL_VALUES[16];
 @PL_VALUES[25]=0;
}
if ($NowAddEN > @PL_VALUES[18]) {$NowAddEN = @PL_VALUES[18];}
WriteDataToUserDataBase($GetUserName,@PL_VALUES);
WriteDataToUserDataBase($BossName,@Boss_VALUES);

print << "-- --ENDINPUT-- - -";

<p align="center">
�i�J�Y�ɺʵ����߮ɪ����A&nbsp;
<div align="center">
  <center>
  <table border="1" width="700" bgcolor="#F0F0F0">
    <tr>
      <td width="18%">
�̫�԰��ɶ�</td>
      <td width="82%"> $LastFightTimeDate �Z���ثe $FightBeforeSecond ��</td>   
    </tr>   
    <tr>   
      <td width="18%">��W���</td>  
      <td width="82%">  @PL_VALUES[8] G</td>   
    </tr>   
    <tr>  
      <td width="18%"><font color="#800080">�Y�ɾԪp</font></td>
      <td width="82%">  <font color="#800080">  $CurrentFightStatus</font></td> 
    </tr>
  </table>
  </center>
</div>
<div align="center">
  <center>
  <table border="0" width="700" bgcolor="#EBF0E8" height="38">
    <tr>
      <td width="22" height="12">
HP</td>
      <td width="87" align="right" height="12"> $NowAddHP</td>
      <td width="12" height="12">/&nbsp;</td>
      <td width="124" height="12"> @PL_VALUES[16]</td>
      <td width="427" height="12"> &nbsp;�ײz���A�� @Repair[@PL_VALUES[25]]</td>
    </tr>
    <tr>
      <td width="22" height="18">
EN</td>
      <td width="87" align="right" height="18"> $NowAddEN</td>
      <td width="12" height="18"> /</td>
      <td width="124" align="left" height="18"> @PL_VALUES[18]</td>
      <td width="427" align="left" height="18"> �@</td>
    </tr>
  </table>
  </center>
</div>

<div align="center">
  <center>
  <table border="1" width="700" bgcolor="#F0F0F0">
    <tr> 
      <td width="18%">
����:</td>
      <td width="82%">�o�جO�Y�ɺʵ�����..�C��$WatchSecond�����ᱼ$WatchMoney  
        G �ЫȤH�ۦ�ʤ�...�h�I�����@�ߤ��h..����..<br> �������]��:@Boss_VALUES[8]</td>
    </tr>
  </table>
  </center>
</div>


<form method="POST" action="monitor.pl?show" name="AutoSendForm">
<input type="hidden" name="pname" value="$GetUserName" size="20">
<input type="hidden" name="pass" value="$GetUserPassword" size="20">
</form>


<script> 
<!-- 
function AutoRefresh()
{
setTimeout('SentSubmit()',$WatchSecond*1000);
}	

function SentSubmit()
{
document.AutoSendForm.submit();
}

AutoRefresh();
//--> 
</script>



-- --ENDINPUT-- - -

}


sub pre_get_value
{
# ���Φr��Χ�r��ѽX�^��Ӫ��r��
if ($ENV{'REQUEST_METHOD'} eq 'POST')
{
    read(STDIN, $temp, $ENV{'CONTENT_LENGTH'});
}
else
{
    $temp=$ENV{'QUERY_STRING'};
}

@key_value=split(/&/,$temp);

foreach $item(@key_value) 
{
    ($key,$value)=split (/=/,$item,2);
    $value=~tr/+/ /;
    $value=~ s/%(..)/pack("c",hex($1))/ge;
    $FORM{$key}=$value;
}

$buff = "$ENV{'QUERY_STRING'}";
$buff =~ s/\+/ /g;

($parm1,$parm2,$parm3)=split(/ /,$buff);
}

sub WriteDataToUserDataBase
{
local($UserName,@GetRealUserData)=@_;
&LOCK;
	dbmopen (%P,"$DBM_P",0666);
		$P{"$UserName"}="@GetRealUserData";
	dbmclose %P;
&UNLOCK;
}	
