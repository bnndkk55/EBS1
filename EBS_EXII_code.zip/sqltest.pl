#!/usr/bin/perl
use DBI;
print "Content-type: text/html;\n\n";
#MYSQL �]�w START


$cfsq01="frwonline.com";#MYSQL HOST
$cfsq02="ebsdebug";#MYSQL USER
$cfsq03="Sdfs34hy6572@";#MYSQL PASSWORD
$cfsq04="ebsdebug";#MYSQL DATABASE ��Ʈw�W��


#================new table===========================
print "start..";

$dbh = DBI->connect("DBI:mysql:database=$cfsq04;host=$cfsq01",$cfsq02,$cfsq03, {RaiseError => 1});
print "connect<br>";


print "PERL MYSQL OK!";
