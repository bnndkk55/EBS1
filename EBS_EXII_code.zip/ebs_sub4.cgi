require "debug_sub.pl";
@CompareBadguyData=read_file("badguy.txt");


sub BATTLE1{
	&DBM_INPORT(P);
	@PL_VALUES = split(/\s/,$P{"$FORM{'pname'}"});
	&REPAIR(PL);
	&ERROR('�ۥѾԤh���v���ऺ��') if $FORM{'b_mode'} eq '����' && !$PL_VALUES[5];
	#&ERROR('�����Ϊ��`�Ӥ����\����') if $FORM{'b_mode'} eq '����' && $PL_VALUES[6]!=0;
        if ($PL_VALUES[5] eq $PRISON_NATIONALITY) {&ERROR('�ǤH�O�L�k�p�ۦ�ʪ�...�K�K');}
        if ($DisableCountry{$PL_VALUES[5]} eq 1) {&ERROR('����a�O�T���ʪ�...�K�K');}
        CheckPassword($FORM{'pass'},$PL_VALUES[2]);
$StopGame = 0;
if ($PL_VALUES[5] eq $NoFightPlace){$StopGame=1;}
if ($PL_VALUES[5] eq $KeepAccountCountry){$StopGame=1;}
if ($PL_VALUES[5] eq $WaitDiePlace){&ERROR('�]�S�O�z��..�A�Q���F..����ID�Q�R����..�ߤ@���|�N�O���ݯ����S�j!');}

if ($StopGame == 1)
{
print "Content-type: text/html;\n\n";
print "<html>";

print '�]�S�O�z��..�A�ȮɳQ�B��F..�o�q�ɶ�..�L�k���';
print "</html>";
exit;
}


	if ($PL_VALUES[67] eq 1)
	{
	print "Content-type: text/html\n\n";
	print "�ϥ�BUG�Q�T�F";
	exit;
	}
	
	if ($PL_VALUES[25]==1)
	{
	if (($PL_VALUES[66] =~ m/MO3/) && ($PL_VALUES[66] =~ m/HI2/))
	{
	print "Content-type: text/html\n\n";
	print "���e���԰��٦b�p�⤧���A�A����P�ɶi��⦸�԰�";
	exit;
	}
	else
	{
	&ERROR('�b�ײz��'); 
	}
	}

	
	&HEADER;


#&DownFrameMax;

print << "-----END-----";
<body bgcolor="#003399">
      
-----END-----




	require "$LOG_FOLDER/$HASH_DATA";
	require "$LOG_FOLDER/_ex.data";

	local($WN_A,$WLV_A,$WEX_A) = split(/!/,$PL_VALUES[9]);
	@WN_sA=split(/\,/,$WEAPON_LIST{"$WN_A"});
	@PEX_A=split(/\,/,$WEAPONEX_LIST{"$WEX_A"});
#======== WEAPON _PROVE========    
    if ($PEX_A[1] eq "e"){$WN_sA[4]=int($WN_sA[4]*1.2);}
    if ($PEX_A[1] eq "f"){$WN_sA[4]=int($WN_sA[4]*0.8);}
	$PL_VALUES[17] < $WN_sA[4] && do{print "EN����";exit;};
	&DBM_INPORT(C);

	@pair = split(/;/, $ENV{'HTTP_COOKIE'});
		foreach (@pair) {my($key, $value) = split(/=/, $_);$DUMMY{$key} = $value;}
	@MISSION=('���q����,0','����,5','���m,18','���u����,25',
				'����,30','�{��,40','����,50','���u��X,70','�îg,120','�߲�,200','���g�T�s,300','�@�I����,500','�t�̤���,550','��������,700');
	$Sakusen="�@�ԫ��O <select size=1 name=\"mode\" $STYLE_L>\n";
	
	
	
	foreach (@MISSION){$c++;
		my($M,$R)=split(/\,/,$_);
		if($PL_VALUES[29] >= $R){
			$Sakusen .= "<option value=\"$c\"";
			$Sakusen .= "selected"if $c ==  $DUMMY{' EBMISSON'};
			$Sakusen .= ">$M \n";
		}
	}
	$Sakusen .= "</select>";
	

	print "<span style=\"font-size:35px;\">$FORM{'b_mode'}</span>" if $FORM{'b_mode'} ne '�԰�';

	if ($FORM{'b_mode'} eq '�԰�' ||!$FORM{'b_mode'}){
		print << "		-----END-----";
			<form action=$MAIN_SCRIPT method=POST target=Sub>
			<input type=hidden name="cmd" value="BATTLE_1">
			<input type=hidden name="pname" value="$FORM{'pname'}">
			<input type=hidden name="pass" value="$FORM{'pass'}">
		-----END-----
		while (($C_Name,$C_Value) =each %C) {
			@C_VALUES = split(/\s/,$C_Value);
			if ($PL_VALUES[5] ne "$C_Name"){
				print "<input type=submit name=CNTRY value=\"$C_Name\"";
				print " style=\" background:$C_VALUES[0];color:black\">\n";
			}
		}
		print "<input type=submit name=CNTRY value=\"�ۥѾԤh\"";
		print " style=\" background:#808080;color:black\"></form>\n";
	}
	if ($FORM{'b_mode'} eq '�`�R'){
		$boumeiTag="&nbsp;�`�R�h<select name=\"boumeiC\" $STYLE_L>";
		while (($C_Name,$C_Value) =each %C) {
		@C_VALUES = split(/\s/,$C_Value);
		my $c_cnt = 0;


#$ListAllBadGuy=BadGuyList();

#=== Fight List
while(my($key,$value) = each %P){
my@MEMBER_VALUE = split(/\s/,$value);
if($C_Name eq "$MEMBER_VALUE[5]" && ++$c_cnt >= $C_VALUES[14]){
last;
}
}
if ($PL_VALUES[5] ne "$C_Name" && $c_cnt < $C_VALUES[14]){$boumeiTag.="<option value=\"$C_Name\">$C_Name\n";$bf=1;}
		}
		$boumeiTag.="<option value=\"\">�ۥѾԤh\n"if $PL_VALUES[5];
		$boumeiTag.="</select>";
		$boumeiTag='' if !$bf;
	}
	
	$VS_COUNTRY="$FORM{'CNTRY'}" if $FORM{'CNTRY'};
	$VS_COUNTRY="$PL_VALUES[5]" if !$FORM{'CNTRY'};
	@CL_VALUE = split(/\s/,$C{"$VS_COUNTRY"});
	@CL_VALUE2 = split(/\s/,$C{"$PL_VALUES[5]"}) if $PL_VALUES[5];

#	$RYMove=rand(60);
#        $RXMove=rand(100);

#	<div id=psbodydata style="position: absolute; visibility: visible; z-index: 900; top:$RYMove; left:$RXMove;">
#	<input type=submit value="�}�l�԰�" class=button2 onClick="location.replace('$MAIN_SCRIPT?LOGO');">
#	</div> 

	print << "	-----END-----" if $FORM{'b_mode'} ne '�԰�';

		<center><table><tr><td style=\"background-color:$CL_VALUE[0];font-size:40px;color:#000000;\" colspan=4>
			$VS_COUNTRY</td><form action=$MAIN_SCRIPT method=POST target=Sub></tr>

	
	-----END-----





	$FORM{'CNTRY'}='' if $FORM{'CNTRY'} eq '�ۥѾԤh';
	while (($Key,$Value) = each %P){
		@VS_VALUES = split(/\s/,$Value);
		&REPAIR(VS);
		($VSCurrentWeaponID,$None)= split(/!/,@VS_VALUES[9]);
		if ($Key ne "$FORM{'pname'}"){
			&FILTING if $VS_VALUES[5] eq "$FORM{'CNTRY'}" && !$FORM{'b_mode'} && !$VS_VALUES[25];
			&FILTING if $VS_VALUES[5] eq "$PL_VALUES[5]" && $PL_VALUES[5] && $FORM{'b_mode'} eq'�`�R' && $VS_VALUES[0] >$PL_VALUES[0];
			(&FILTING,$sousuiCh++) if $VS_VALUES[5] eq "$PL_VALUES[5]" && $FORM{'b_mode'} eq '����' && $VS_VALUES[6] ==1 && $PL_VALUES[0] >=170;
			if ($VS_VALUES[5] eq "$PL_VALUES[5]" && $FORM{'b_mode'} eq '����' && $PL_VALUES[6] ==0 && $VS_VALUES[6] ==-1 && $CL_VALUE2[2] && $CL_VALUE2[2] eq "$VS_VALUES[28]" && $PL_VALUES[0] >=100){&FILTING;$flagta=1;}
			if ($VS_VALUES[5] eq "$PL_VALUES[5]" && $FORM{'b_mode'} eq '����' && $PL_VALUES[6] ==0 && $VS_VALUES[6] ==-1 && $CL_VALUE2[3] && $CL_VALUE2[3] eq "$VS_VALUES[28]" && $PL_VALUES[0] >=100){&FILTING;$flagtb=1;}
			if ($VS_VALUES[5] eq "$PL_VALUES[5]" && $FORM{'b_mode'} eq '����' && $PL_VALUES[6] ==0 && $VS_VALUES[6] ==-1 && $CL_VALUE2[4] && $CL_VALUE2[4] eq "$VS_VALUES[28]" && $PL_VALUES[0] >=100){&FILTING;$flagtc=1;}
		}
	}
	if($PL_VALUES[5] && !$PL_VALUES[28]){$M_AITE="$CL_VALUE2[6]";}
	elsif($PL_VALUES[5] && $PL_VALUES[28] eq "$CL_VALUE2[2]" && $CL_VALUE2[2]){$M_AITE="$CL_VALUE2[8]";}
	elsif($PL_VALUES[5] && $PL_VALUES[28] eq "$CL_VALUE2[3]" && $CL_VALUE2[3]){$M_AITE="$CL_VALUE2[9]";}
	elsif($PL_VALUES[5] && $PL_VALUES[28] eq "$CL_VALUE2[4]" && $CL_VALUE2[4]){$M_AITE="$CL_VALUE2[10]";}

	if ($FORM{'b_mode'} eq '' && !$PlMs){
		print "<tr><td bgcolor=\"$CL_VALUE[0]\">&nbsp;</td><td bgcolor=#000000 colspan=3>No-PLAYER</td></tr>"
		if $CL_VALUE2[7] < time || $M_AITE ne "$VS_COUNTRY";
		print << "		-----END-----"if $CL_VALUE2[7] > time && $M_AITE eq "$VS_COUNTRY";
			<tr><td bgcolor=$CL_VALUE[0] align=center>&nbsp;&nbsp;</td>
			<td bgcolor=#000000><input type=radio name=vsname checked value=\"$VS_COUNTRY\">
			<input type=hidden name=yousai value="true">
			$VS_COUNTRY���ín��<br>&nbsp;&nbsp;�{�b�i�H���������ĭx�n�륻���F�C</td>
			<td bgcolor=#000000><img src=$IMG_FOLDER2/1000.gif></td><td bgcolor=#000000>�|</td></tr>
		-----END-----
		$PlMs++ if $CL_VALUE2[7] > time && $M_AITE eq "$VS_COUNTRY";
	}
	$HiddenTag="<form action=$MAIN_SCRIPT method=POST target=Main><input type=hidden name=\"cmd\" value=\"CUSTOM\"><input type=hidden name=\"pname\" value=\"$FORM{'pname'}\"><input type=hidden name=\"pass\" value=\"$FORM{'pass'}\">";

	sub HiddenTAG{"
			<tr></form><td bgcolor=\"$CL_VALUE[0]\">&nbsp;</td>
				$HiddenTag<td bgcolor=#000000 colspan=3>
				��$_[0]����  $_[1]�ثe�S�������A����O���ܭȱo�����C
				<input type=hidden name=\"team\" value=\"$_[1]\">
				<input type=submit name=\"Cmode\" value=\"�����N��\" $STYLE_B1
				onClick=\"location.replace('$MAIN_SCRIPT?LOGO');\">
			</td></tr>
		";
	}

	if ($FORM{'b_mode'} eq '�`�R' && !$PlMs && $boumeiTag){
		print << "		-----END-----";
			<tr></form><td bgcolor=\"$CL_VALUE[0]\">&nbsp;</td>
				$HiddenTag<td bgcolor=#000000 colspan=3>$boumeiTag
				�`�R�ܭW���@�A�T�w�ܡH
				<input type=submit name="Cmode" value="�`�R" class=button2 
				onClick="location.replace('$MAIN_SCRIPT?LOGO');">
			</td></tr>
		-----END-----
	}elsif($FORM{'b_mode'} eq '�`�R' && !$boumeiTag)
		{
		print "<tr></form><td bgcolor=\"$CL_VALUE[0]\">&nbsp;</td><td bgcolor=#000000 colspan=3>�}�l�`�R�ͲP�C</td></tr>";
		}
	
	if ($FORM{'b_mode'} eq '����' && !$sousuiCh && $PL_VALUES[0] >=170){$PlMs2=1;
		$hanran.= << "		-----END-----";
			<tr></form><td bgcolor=\"$CL_VALUE[0]\">&nbsp;</td>
				$HiddenTag<td bgcolor=#000000 colspan=3>
				�ثe��a�S���`�ӤF�Aĳ�|�M�w�e���A���v�����v�Q�A�A�����ܡH
				<input type=submit name="Cmode" value="�`�ӴN��" $STYLE_B1
				onClick="location.replace('$MAIN_SCRIPT?LOGO');">
			</td></tr>
		-----END-----
	}
	if ($FORM{'b_mode'} eq '����' && !$flagta && $PL_VALUES[0] >=100 && $PL_VALUES[6] ==0 && $CL_VALUE2[2]){$PlMs2=1;
		$hanran.= &HiddenTAG('�@',$CL_VALUE2[2]);
	}
	if ($FORM{'b_mode'} eq '����' && !$flagtb && $PL_VALUES[0] >=100 && $PL_VALUES[6] ==0 && $CL_VALUE2[3]){$PlMs2=1;
		$hanran.= &HiddenTAG('�G',$CL_VALUE2[3]);
	}
	if ($FORM{'b_mode'} eq '����' && !$flagtc && $PL_VALUES[0] >=100 && $PL_VALUES[6] ==0 && $CL_VALUE2[4]){$PlMs2=1;
		$hanran.= &HiddenTAG('�T',$CL_VALUE2[4]);
	}
	
	$RYMove=rand(100);
        $RXMove=rand(500);
#<div id=psbodydata style="position: absolute; visibility: visible; z-index: 900; top:$RYMove; left:$RXMove;">	
	print << "	-----END-----" if $FORM{'b_mode'} ne '�԰�' && $PlMs;
		<tr><td bgcolor=\"$CL_VALUE[0]\"><a name=sbm>&nbsp;</td>
			<td colspan=4 bgcolor=\"#000000\">
			$Sakusen$boumeiTag
			<input type=hidden name="cmd" value="BATTLE_2">
			<input type=hidden name="pname" value="$FORM{'pname'}">
			<input type=hidden name="pass" value="$FORM{'pass'}">
			<input type=hidden name="b_mode" value="$FORM{'b_mode'}">
			<input type=hidden name="check" value="$DATE">

			<input type=submit value="�}�l�԰�" class=button2 onClick="location.replace('$MAIN_SCRIPT?LOGO');">

			
			
		</td></tr>
	
	-----END-----


	print $hanran if $FORM{'b_mode'} ne '�԰�' && $PlMs2;
	print << "	-----END-----" if $FORM{'b_mode'} eq '����' && !$PlMs2;
			<tr></form><td bgcolor=\"$CL_VALUE[0]\">&nbsp;</td><td bgcolor=#000000 colspan=3>
				�ثe�S���M�A���Ŭ۷������A�L�k�i��԰�
			</td></tr>
	-----END-----

	print "</table></form><br><br>";
	&FOOTER;
exit;
}
sub FILTING {
	@AddationwnID=split(/!/,$VS_VALUES[99]);
	$VSAddationItemID=@AddationwnID[0];
	($BadGuyName,$AttPlaying,$DestoryPlayer)=CompareBadGuy($Key,@CompareBadguyData);
	$PlMs++;
	$IconTag=$Guarder='';
	if ($PlMs==1){$rc='checked';}else{$rc='';}
	$NickName=$VS_VALUES[3];
	$ChooseType="<input type=radio name=vsname value=\"$Key\" $rc onClick=\"location.replace('#sbm')\">";
	if ($VSAddationItemID eq "magic000x"){$Key='����';$ChooseType='';$NickName='�]�k��..';}

	$IconTag="<img src=\"$IMG_FOLDER2/$VS_VALUES[27].gif\" style=\"filter:fliph();\"><img src=$IMG_FOLDER3/$VS_VALUES[100].gif >";
	print "<tr><td bgcolor=\"$CL_VALUE[0]\" align=center>&nbsp;&nbsp;</td>";
	print "<td bgcolor=\"$VS_VALUES[13]\">$ChooseType";
	print "<span style=\"font-size:18px;color:#000000;\">$Key</span>";
	print "<span style=\"font-size:15px;\"><b>".&RANK($VS_VALUES[0],$VS_VALUES[5],$VS_VALUES[6])."</b></font></td>";
	print "<td bgcolor=\"$VS_VALUES[13]\">$IconTag<font color=\"#000000\">$NickName</font></td>";
	print "<td bgcolor=\"$VS_VALUES[13]\" style=\"FONT-SIZE: 20px\">".&STATUS_CONVERT("$VS_VALUES[24]",'j');
	print "<td bgcolor=\"#0000ff\">";
	

	if ($VSAddationItemID eq "magic000x")
	{
	print "�����]�k";
	}	

	if ($VSCurrentWeaponID eq "die")
	{
	print "�_���S�F";
	}	
	print "HP:$VS_VALUES[15] <br>";
	if ($VS_VALUES[77] == 1)
	{
	if ($VS_VALUES[99] ne "")
	{	
	 @spwnID=split(/!/,$VS_VALUES[99]);
	 @spwn=split(/\,/,$WEAPON_LIST{@spwnID[0]});
		print "�e@spwn[0]";
	}
	}	
	if ($VS_VALUES[77] == 3)
	{
	print "�e��O$VS_VALUES[8]<br> ";
	}	

	print "X:$VS_VALUES[95],Y:$VS_VALUES[96]";
	if ($VSCurrentWeaponID eq "gmspecial001")
	{
	print "����GM�v��(�S��)";
	}	

	if ($VS_VALUES[67] eq 1)
	{
	 print "<center>�H�W�Q�T�D��P�ؤ��v</center>";
	 
	}

        if ($VS_VALUES[69] >0)
	{
	 print "<center>���W�l��$VS_VALUES[69]�T���K���u</center>";
	}
        
	if(LOGIN_CHECK($Key)){ print "�ť�<img src=\"$IMG_FOLDER4/on.gif\">�H"; }
	else{ print "�i��<img src=\"$IMG_FOLDER4/off.gif\">�H"; }
	
	if ($Key eq $BadGuyName)
	{
	 print "<B><font color=\"#FF0000\">$AttPlaying</font>:<font color=\"#9900FF\">$DestoryPlayer</font></B>";
	}
	
	#print "$Key = $BadGuyName,$AttPlaying,$DestoryPlayer</td></tr>";
	print "</td>";

	print "</td></tr>";
}

sub BATTLE2{


	
		SET_COOKIE:{
		my @gmt = gmtime(time + $COOKIE_KEEP*24*60*60);
		$gmt[0] = sprintf("%02d", $gmt[0]);$gmt[1] = sprintf("%02d", $gmt[1]);$gmt[2] = sprintf("%02d", $gmt[2]);
		$gmt[3] = sprintf("%02d", $gmt[3]);$gmt[5] += 1900;
		$gmt[4] = ('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')[$gmt[4]];
		$gmt[6] = ('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday')[$gmt[6]];
		my $date_gmt = "$gmt[6], $gmt[3]\-$gmt[4]\-$gmt[5] $gmt[2]:$gmt[1]:$gmt[0] GMT";
		print "Set-Cookie:EBMISSON=$FORM{'mode'}; expires=$date_gmt\n";
	}
	&LOCK;
		&DBM_CONVERT('P',"$FORM{pname}") if $FORM{'yousai'};
		&DBM_CONVERT('P',"$FORM{pname}",'VS',"$FORM{vsname}") if !$FORM{'yousai'};
		&DBM_CONVERT('C',"$PL_VALUES[5]",'VC',"$VS_VALUES[5]") if !$FORM{'yousai'};
		&DBM_CONVERT('C',"$PL_VALUES[5]",'VC',"$FORM{'vsname'}") if $FORM{'yousai'};
	&UNLOCK;


if($DisableNPC{$FORM{'pname'}} eq 1 )
{
&record_fight(""," ","$FORM{'pname'} �Q��NPC ID ")
&ERROR('NameError','�Τ�W�����D�A�n������');

}	

#$QuestionRate=int(rand(10)+1);
#if ($QuestionRate eq 2)
#{
#$X1=int(rand(30)+1);
#$X2=int(rand(20)+1);
#print "<script>alert('�u�O�n�T�w�z�b�{��:�а�$X1+$X2=?');</script>";
#}	



	if ($FORM{'yousai'}){
			if(!$PL_VALUES[28]){$M_AITE="$CL_VALUE2[6]";}
			elsif($PL_VALUES[28] eq "$CL_VALUE2[2]" && $CL_VALUE2[2]){$M_AITE="$CL_VALUE2[8]";}
			elsif($PL_VALUES[28] eq "$CL_VALUE2[3]" && $CL_VALUE2[3]){$M_AITE="$CL_VALUE2[9]";}
			elsif($PL_VALUES[28] eq "$CL_VALUE2[4]" && $CL_VALUE2[4]){$M_AITE="$CL_VALUE2[10]";}
			&ERROR('�w�g�Q�O��i���') if $M_AITE ne "$VS_Country";
			&ERROR('�W�L�@�Դ���') if time > $CL_VALUES[7];
			&ERROR('�o�Ӱ�a�w�g���`�F') if !@VC_VALUES;

		@Y_HP=split(/!/,$VC_VALUES[11]);
		@Y_ST=split(/!/,$VC_VALUES[12]);$Y_ST[0]+=50;$Y_ST[1]+=50;$Y_ST[2]+=50;
		if ($VS_Country eq $PRISON_NATIONALITY)
		{
                 $Y_ST[0]+=250;$Y_ST[1]+=250;$Y_ST[2]+=250;
                 $Y_HP[0]+=1000000;$Y_HP[1]+=1000000;
                 }			
	
	if ($VC_VALUES[20] eq "")
	{
	@VS_VALUES=("300","$Y_HP[2]!0","","$Y_ST[3]","AL","$FORM{'vsname'}","99","","0","zzzz","zzzz","zzzz","6","$VC_VALUES[0]","0","$Y_HP[0]","$Y_HP[1]","9999","9999","$Y_ST[0]","$Y_ST[1]","0","$Y_ST[2]","99","999","0","$DATE","1000","0","99","0");
	}
	else
	{
	$SIWeaponID="zzzz".$VC_VALUES[20];
	@VS_VALUES=("300","$Y_HP[2]!0","","$Y_ST[3]","AL","$FORM{'vsname'}","99","","0","$SIWeaponID","$SIWeaponID","$SIWeaponID","6","$VC_VALUES[0]","0","$Y_HP[0]","$Y_HP[1]","9999","9999","$Y_ST[0]","$Y_ST[1]","0","$Y_ST[2]","99","999","0","$DATE","1000","0","99","0");
	}
	
	}

	&REPAIR(PL);&REPAIR(VS);
	if (@CL_VALUES){$PL_Country="$PL_VALUES[5]";}else{$PL_Country='�ۥѾԤh';$CL_VALUES[0]='#808080';}
	if (@VC_VALUES){$VS_Country="$VS_VALUES[5]";}else{$VS_Country='�ۥѾԤh';$VC_VALUES[0]='#808080';}

	&ERROR('SystemError','�t�ήɶ��o�Ͱ��D') if $FORM{'check'} < $PL_VALUES[26];
	

	CheckPassword($FORM{'pass'},$PL_VALUES[2]);

$VSOrgiUPHP=$VS_VALUES[15];
@GetVSAns=split(/!/,$VS_VALUES[11]);
$VSOrgiProtect=@GetVSAns[1];
	
if ($VS_Country eq $BADGUY_NATIONALITY)
{
if (($PL_VALUES[19]>=30) || ($PL_VALUES[19]>=30) || ($PL_VALUES[19]>=30) || ($PL_VALUES[19]>=30))
{ 
 &ERROR("�o�O�s��V�m��,�A�w�g���O�s��F");
}
}

if (rindex($PL_VALUES[10],"�W�X�]") ne -1)
{
&ERROR('Mmmm...����γo?�W�r��!');
}

if ($VS_VALUES[5] eq $NoFightPlace){&ERROR('�]�S�O�z��..���H�ȮɳQ�B��F..�o�q�ɶ�..�L�k���..�A�]���ॴ�L');}
if ($VS_VALUES[5] eq $KeepAccountCountry){&ERROR('�]�S�O�z��..���H�ȮɳQ�B��F..�o�q�ɶ�..�L�k���..�A�]���ॴ�L');}

if ($PL_VALUES[5] eq $NoFightPlace){&ERROR('�]�S�O�z��..�A�ȮɳQ�B��F..�o�q�ɶ�..�L�k���');}
if ($PL_VALUES[5] eq $WaitDiePlace)
{
 rename "$StorageDir/$FORM{'pname'}.dat","$StorageDir/$FORM{'pname'}.bakdat";
 &ERROR('�]�S�O�z��..�A�Q���F..����ID�Q�R����..�ߤ@���|�N�O���ݯ����S�j!');
}
if ($PL_VALUES[5] eq $PRISON_NATIONALITY) {&ERROR('�ǤH�O�L�k�p�ۦ�ʪ�...�K�K');}
if ($DisableCountry{$PL_VALUES[5]} eq 1) {&ERROR('����a�O�T���ʪ�...�K�K');}
if (($PL_Country eq $VS_Country)&&($FORM{'b_mode'} eq '�԰�'))
{
  if ($VS_Country ne "�ۥѾԤh"){Warning("���i���ۤv��a���H (�R���Ҧ�)");}
}		
	if ($PL_VALUES[67] eq 1)
	{
	print "Content-type: text/html\n\n";
	print "�ϥ�BUG�Q�T�F";
	exit;
	}

	if($PL_VALUES[16] < $NoFightlHP){&ERROR("�]HP���� $NoFightlHP �L�k�@��!");}
	
        if ( $PL_VALUES[26] >= time - $FigthInv)
        {
	if (($PL_VALUES[66] =~ m/MO3/) && ($PL_VALUES[66] =~ m/HI2/))
	{
        Warning("�C���V�m�ɶ����o�p��$FigthInv �� (�R���Ҧ�)");
	}
        else
        {
         &ERROR("�C���V�m�ɶ����o�p��$FigthInv �� (���n�Ҧ�)");
        }
        }	

	if ($PL_VALUES[25] || $VS_VALUES[25])
	{
	if (($PL_VALUES[66] =~ m/MO3/) && ($PL_VALUES[66] =~ m/HI2/))
	{
	Warning("���e���԰��٦b�p�⤧���A�A����P�ɶi��⦸�԰�(�R���Ҧ�)");
	}
	else
	{
	&ERROR('Repair','���e���԰��٦b�p�⤧���A�A����P�ɶi��⦸�԰�(���n�Ҧ�)');
	}
	}
	&ERROR('NeiLuanError','���å����b�ꤺ�i�}') if (($FORM{'b_mode'} eq '����') && ($PL_VALUES[5] != $VS_VALUES[5]));
	require "$LOG_FOLDER/_ex.data";
    local($PL_WN,$PL_WLV,$PL_WEX) = split(/!/,$PL_VALUES[9]);
	local($VS_WN,$VS_WLV,$VS_WEX) = split(/!/,$VS_VALUES[9]);
	require "$LOG_FOLDER/$HASH_DATA";
	@PEX_sA=split(/\,/,$WEAPONEX_LIST{"$PL_WEX"});
	@VEX_sA=split(/\,/,$WEAPONEX_LIST{"$VS_WEX"});
        if (!$PL_WEX){$PEX_sA[1]="a";}
	@Pl_W=split(/\,/,$WEAPON_LIST{"$PL_WN"});
	@Vs_W=split(/\,/,$WEAPON_LIST{"$VS_WN"});
	local($PL_BG,$PL_BGT) = split(/!/,$PL_VALUES[41]); 
local($VS_BG,$VS_BGT) = split(/!/,$VS_VALUES[41]); 
require "$LOG_FOLDER/_bougu.data"; 
@Pl_B=split(/\,/,$BOUGU_LIST{"$PL_BG"}); 
@Vs_B=split(/\,/,$BOUGU_LIST{"$VS_BG"}); 

$JoinFight=0;
$IsHitJoin="";
if(LOGIN_CHECK($FORM{'vsname'}))
{
$JoinFight=1;
$IsHitJoin="�ѾԤ�";
}	
$UseDistoryWeapon=0;
$IsUseDistoryWeapon="";
if ($Pl_W[7] == 1)
{
$UseDistoryWeapon=1;
$IsUseDistoryWeapon="�ϥ��z�Z";
}	

	if (($Pl_W[7] == 25) || ($PL_VALUES[66] =~ m/EP9/))
	{
	if($JoinFight eq 1)
        {
	Warning("���Z�����m�ߤ��Τ��i�����ɤ��H(�R���Ҧ�)");
	}
	}



if ($VS_VALUES[76] eq ""){$VS_VALUES[76] = 0;}
if ($PL_VALUES[76] eq ""){$PL_VALUES[76] = 0;}

if ($PL_VALUES[76]>=$MaxBadPoint)
{$PL_VALUES[5]=$WaitDiePlace;}
if ($VS_VALUES[76]>=$MaxBadPoint)
{$VS_VALUES[5]=$WaitDiePlace;}
$AddationDieMsg="";

@GetAns=split(/!/,$PL_VALUES[9]);
@GetAnsVS=split(/!/,$VS_VALUES[9]);
if (@GetAns[0] eq 'wya0004')
{
Warning("���i���˳Ʈ��b��W�ϥ�(�R���Ҧ�)");exit;
}	





if (@GetAnsVS[0] eq 'wya0004')
{
@GetAnsVS[1]--;
$VS_VALUES[9]="@GetAnsVS[0]!@GetAnsVS[1]!@GetAnsVS[2]";
$ResultTag.=".�ĤH��W�˳Ʒl���@�I!";
}	


# ($Pl_W[7] == 1)
if (($FORM{'vsname'} eq '�K�K') && ($CanRepWeapon{"$Pl_W[7]"} >= 1) )
{
my @GetAnsPL=split(/!/,$PL_VALUES[9]);
if (@GetAnsPL[1]<$WEAPON_LVUP)
{
if ($PL_VALUES[8] > 0)
{
$RepNeedMoney=$CanRepWeapon{"$Pl_W[7]"};
@GetAnsPL[1]+=10;
$PL_VALUES[9]="@GetAnsPL[0]!@GetAnsPL[1]!@GetAnsPL[2]";
$PL_VALUES[8]-=$RepNeedMoney;
$ResultTag.=".�A��W�˳ƭ״_10�I!�ᱼ$RepNeedMoney G";
}
else
{
$ResultTag.=".�A��������H�I���˳ƭ״_.";
}	


}
else
{
$ResultTag.=".�A��W�ˤ��ݭ״_. ";
}	

}	

if (@GetAnsPL[1]<-10)
{
Warning("���Z���w�Y�����l�L�k�ϥΤF�Ч��K�K����(�R���Ҧ�)");
}	







if (@GetAns[0] eq "enboom1")
{
$ThrowBoomRate=int(rand(7)+1);
$BoomCost=2000;
$ResultTag.=" �A��$BoomCost���ʤJ�s���K���u�¹��o�g.. ";
if ($ThrowBoomRate eq 3)
{
if ($VS_VALUES[69] eq ""){$VS_VALUES[69]=0;}
$PL_VALUES[8]-=$BoomCost;
if ($PL_VALUES[8] <= 0)
{
$PL_VALUES[8]=0;
&ERROR('�������');
}
else
{$VS_VALUES[69]++;$ResultTag.=' �A�w�N���u���\�l���b������W. ';}
}
else
{$ResultTag.=' �A�⬵�u�g���F. '; }

}

if (@GetAns[0] eq "whpdec")
{
$IsMeetDecHp=int(rand(15)+1);
if ($IsMeetDecHp eq 3)
{
$DecHpNum=int(rand(50)+1);
$SpecialReport=" $FORM{'pname'}�ίS�X�Z����$FORM{'vsname'}�Ϩ�HP�W����� $DecHpNum..,$FORM{'pname'}���Z�����l.";
$ResultTag.=$SpecialReport;
$PLWeaponDemage=1;
$VS_VALUES[16]-=$DecHpNum;
WriteSNGMsg("$SpecialReport");
}
}
	
if (((@GetAns[0] eq "wxa0001") || (@GetAns[0] eq "wya0003")) && (uc($FORM{'pname'}) ne "CHRIS"))
{
$PL_VALUES[9]="a!0!";
if (@GetAns[0] eq "wxa0001"){$Weaponkk='�¬}����';}
if (@GetAns[0] eq "wya0003"){$Weaponkk='�C�Ϥ��a';}
WriteSNGMsg("GM01�S�O����:$FORM{'pname'}��$Weaponkk�N�ۤv�����F..�|�د�O�� $PL_VALUES[19] $PL_VALUES[20] $PL_VALUES[21] $PL_VALUES[22]�U����0...�Z���]�z�F.. ");
$PL_VALUES[19]=0;
$PL_VALUES[20]=0;
$PL_VALUES[21]=0;
$PL_VALUES[22]=0;
}	



$w_i=0;
foreach(@WeaponAndLevel)
{
$WeaponChineseName=@WeaponAndLevel[$w_i];
$WeaponLevelLimit=@WeaponAndLevel[$w_i+1];

if ($Pl_W[0] eq $WeaponChineseName) 
{
if ($PL_VALUES[29] < $WeaponLevelLimit)
 {
  Warning("���Z�����ϥε��Ŭ� $WeaponLevelLimit (�R���Ҧ�)");
 }	
}	

if ($Vs_W[0] eq $WeaponChineseName) 
{
if ($VS_VALUES[29] < $WeaponLevelLimit)
 {
  $VS_Limit=1;
 }	
}	

$w_i+=2;
}


($VsBadGuyName,$VsAttPlaying,$VsDestoryPlayer)=CompareBadGuy($FORM{'vsname'},@CompareBadguyData);
$VsIsBadGuy=0;
if ($VsBadGuyName eq $FORM{'vsname'})
{
$VsIsBadGuy=1;
$TotalBadGuyMoney=($VsAttPlaying*10)+($VsDestoryPlayer*10);
if ($TotalBadGuyMoney > 3000)
{
$TotalBadGuyMoney=3000;
}	
$PL_VALUES[8]=$PL_VALUES[8]+$TotalBadGuyMoney;
$ResultTag.="�������Hì�o$TotalBadGuyMoney���";
}	

$AttPlayingFind=0;
$DestoryPlayerFind=0;

if (LOGIN_CHECK($FORM{'vsname'})) { $AttPlayingFind=1;}
if (($Pl_W[7] == 1) && ($Vs_W[7] != 10)) {$DestoryPlayerFind=1;}

$i=0;
if(($AttPlayingFind eq 1) || ($DestoryPlayerFind eq 1) && ($VsIsBadGuy eq 0))
  {
  	$searchword=$FORM{'pname'};
	@ReadBadguyData=read_file("badguy.txt");
	$FindBadGuy=0;
	foreach (@ReadBadguyData)
        	{
          	$userdata_line=@ReadBadguyData[$i];
          	chop ($userdata_line);
		if ((rindex $userdata_line,$searchword) ne -1)
             	   {          	
             	    local($BadGuyName,$AttPlaying,$DestoryPlayer) = split(/,/,$userdata_line);
             	    if ($AttPlayingFind eq 1) {$AttPlaying++;}
             	    if ($DestoryPlayerFind eq 1) {$DestoryPlayer++;}
             	    
             	    @ReadBadguyData[$i]="$BadGuyName,$AttPlaying,$DestoryPlayer\n";
             	    if (@GetAns[0] eq "wya0011"){@ReadBadguyData[$i]='';}
             	    $FindBadGuy=1;
             	   }
             	$i++;
       		} 
  	
  	if ($FindBadGuy eq 0)
  	{
       	if ($AttPlayingFind eq 1) {$AttPlaying=1;$DestoryPlayer=0;}
 	if ($DestoryPlayerFind eq 1) {$DestoryPlayer=1;$AttPlaying=0;}

  	$BadGuyName=$FORM{'pname'};
  	@ReadBadguyData[$i]="$BadGuyName,$AttPlaying,$DestoryPlayer\n";
  	}
        
        &write_file("badguy.txt",@ReadBadguyData);
  }





	$plbs=int ($PL_VALUES[20]+4) if $Pl_W[7] ==4;
	$vsbs=int ($VS_VALUES[20]+4) if $Vs_W[7] ==4;
	$Pl_AttPoint=int($Pl_W[1]*(($PL_WLV*0.0001)+1)*(($PL_VALUES[29]/1000)+1));
    if ($PEX_sA[1] eq "b"){$Pl_AttPoint=int($Pl_AttPoint*0.7);}
    if ($PEX_sA[1] eq "c"){$Pl_AttPoint=int($Pl_AttPoint*1.3);}
    if ($PEX_sA[1] eq "d"){$Pl_AttPoint=int($Pl_AttPoint*1.5);}
    if ($PEX_sA[1] eq "e"){$Pl_AttPoint=int($Pl_AttPoint*1.2);}
    if ($PEX_sA[1] eq "f"){$Pl_AttPoint=int($Pl_AttPoint*0.8);}
	$Pl_SpPoint=$PL_VALUES[21];$Pl_DefPoint=($PL_VALUES[20]+$plbs)*2-int($VS_VALUES[19]/3);$Pl_MisPoint=$PL_VALUES[22];  
	$Pl_Kaikyu=&RANK($PL_VALUES[0],$PL_VALUES[5],$PL_VALUES[6]);
	$pwl=int $PL_WLV/$WEAPON_LVUP;$Pl_WeaponNameA="$Pl_W[0](Level.$pwl)";
    if ($PEX_sA[1] eq "e"){int($Pl_W[4]*=1.2);}
    if ($PEX_sA[1] eq "f"){int($Pl_W[4]*=0.8);}
    if ($VEX_sA[1] eq "e"){int($Vs_W[4]*=1.2);}
    if ($VEX_sA[1] eq "f"){int($Vs_W[4]*=0.8);}
	&ERROR('noEnergy','EN������܂���B�') if $PL_VALUES[17] < $Pl_W[4];
	$Vs_AttPoint=int($Vs_W[1]*(($VS_WLV*0.0001)+1)*(($VS_VALUES[29]/1000)+1));
    
    if ($VEX_sA[1] eq "b"){$Vs_AttPoint=int($Vs_AttPoint*0.7);}
    if ($VEX_sA[1] eq "c"){$Vs_AttPoint=int($Vs_AttPoint*1.3);}
    if ($VEX_sA[1] eq "d"){$Vs_AttPoint=int($Vs_AttPoint*1.5);}
    if ($VEX_sA[1] eq "e"){$Vs_AttPoint=int($Vs_AttPoint*1.2);}
    if ($VEX_sA[1] eq "f"){$Vs_AttPoint=int($Vs_AttPoint*0.8);}
	$Vs_SpPoint=$VS_VALUES[21]-$Vs_B[2];$Vs_DefPoint=($VS_VALUES[20]+$vsbs+$Vs_B[1])*2-int($PL_VALUES[19]/3+$Pl_B[4]);$Vs_MisPoint=$VS_VALUES[22]+$Vs_B[3]; $Vs_Kaikyu=&RANK($VS_VALUES[0],$VS_VALUES[5],$VS_VALUES[6]);  
	$Vs_Kaikyu=&RANK($VS_VALUES[0],$VS_VALUES[5],$VS_VALUES[6]);
	$vwl=int $VS_WLV/$WEAPON_LVUP;$Vs_WeaponNameA="$Vs_W[0](Level.$vwl)";
	$Pl_SpPoint=int ($Pl_SpPoint*1.2) if $Pl_W[7] ==3;
	$Vs_SpPoint=int ($Vs_SpPoint*1.2) if $Vs_W[7] ==3;
    
    if ($PEX_sA[1] eq "b"){$Pl_SpPoint=int($Pl_SpPoint*1.2);}
    if ($PEX_sA[1] eq "c"){$Pl_SpPoint=int($Pl_SpPoint*0.8);}
    if ($PEX_sA[1] eq "d"){$Pl_SpPoint=int($Pl_SpPoint*0.6);}
    if ($VEX_sA[1] eq "b"){$Vs_SpPoint=int($Vs_SpPoint*1.2);}
    if ($VEX_sA[1] eq "c"){$Vs_SpPoint=int($Vs_SpPoint*0.8);}
    if ($VEX_sA[1] eq "d"){$Vs_SpPoint=int($Vs_SpPoint*0.6);}
	if ($PL_VALUES[16] > 50000){$Pl_SpPoint-=int(($PL_VALUES[16]-50000)/5000);}
	if ($VS_VALUES[16] > 50000){$Vs_SpPoint-=int(($VS_VALUES[16]-50000)/5000);}
	&SYUSEI('m',"$FORM{'mode'}",'Pl');
	$VsMsnNo=int(rand(12)+1);
	&SYUSEI('m',"$VsMsnNo",'Vs');
	&SYUSEI('s',"$PL_VALUES[12]",'Pl');
	&SYUSEI('s',"$VS_VALUES[12]",'Vs');
	$Pl_Times=$Vs_Times=0;	$Pl_Check=$Vs_Check=1;
	$hImg="<img src=\"$IMG_FOLDER1/hit.gif\">";
	$mImg="<img src=\"$IMG_FOLDER1/miss.gif\">";

	if (($Pl_W[7] ==18) && ($PL_VALUES[6] == 1))
	{
	$Pl_AttPoint=int($Pl_AttPoint*2);
	}
	if (($Vs_W[7] ==18) && ($Vs_VALUES[6] == 1))
	{
	$Vs_AttPoint=int($Vs_AttPoint*2);
	}


	if ($Pl_W[7] ==17) 
	{
	$Vs_AttPoint=1;
	}
	if (($Vs_W[7] ==17) && ($Pl_W[7] ne 26) )
	{
	$Pl_AttPoint=$Pl_AttPoint/200;
        }

($VSCurrentWeaponID,$None)= split(/!/,@VS_VALUES[9]);


if ($VSCurrentWeaponID eq "die")
{
$ResultTag.="���H�w�Q�ʦL�����L��";
&ERROR($ResultTag);
exit;
}

if ($VSCurrentWeaponID eq "gmspecial001")
{
$ResultTag.="����GM �������O!!";
@PL_VALUES[19]-=10;
@PL_VALUES[20]-=10;
@PL_VALUES[21]-=10;
@PL_VALUES[22]-=10;
}

if ($VS_VALUES[74] eq ""){$VS_VALUES[74] = 0;}
$VS_VALUES[74]+=1;
#====================== Special ==============================
if (($VS_VALUES[69] >0)&&(@GetAns[0] ne "enboom1"))
{
$BoomLoseHP=10000;
$TotalBoomLoseHP=$BoomLoseHP*$VS_VALUES[69];
$VS_VALUES[69]=0;
$VS_VALUES[15]-=$TotalBoomLoseHP;
$ResultTag.="�ĤH���W�����K���u�z��!!�l��$TotalBoomLoseHP HP.";
}	

#======================= NPC =================================
@NPC_VALUE=split(/\s/,$P{'�ӪŮ��s'});
$IsHitNPC=int(rand(12));
if ((@NPC_VALUE[25] eq 0) && (@NPC_VALUE[15] >10))
{
if ($IsHitNPC eq 3)
{
if ((@PL_VALUES[20]+@PL_VALUES[21])<(@NPC_VALUE[19]+@NPC_VALUE[21]))
{$NPCAttackHP=int(rand(10000));@PL_VALUES[15]-=$NPCAttackHP;$ResultTag.=" �D��ӪŮ��sŧ���l�� $NPCAttackHP HP. ";}
if (@PL_VALUES[21]<@NPC_VALUE[21])
{$NPCStoleMoney=int(rand(10000));@PL_VALUES[8]-=$NPCStoleMoney;$ResultTag.=" �D��ӪŮ��sŧ���Q�m$NPCStoleMoney ��. ";}
}

if ($IsHitNPC eq 4)
{
&ERROR("�ӪŮ��s�z�Z�A�@��..�����@�ԵL��");
}

}

#=========================AUTO ATTACK ===============================

&DBM_INPORT(C);
@PLCL_VALUE = split(/\s/,$C{"$PL_VALUES[5]"}); 
$CountryAutoAttackID='';
if ($PLCL_VALUE[7] > time) 
{
while (($Key,$Value) = each %P)
{
@ALLVS_VALUES = split(/\s/,$Value);
if ((@ALLVS_VALUES[5] eq @PL_VALUES[5])&&(@ALLVS_VALUES[25] != 1))
{$CountryAutoAttackID="$Key";last;}	
}		

@VSCL_VALUE = split(/\s/,$C{"$VS_VALUES[5]"});
#&ERROR("($PLCL_VALUE[6] eq $WaitDiePlace $PL_VALUES[5]) $PLCL_VALUE[7]");
@NPC_VALUE=split(/\s/,$P{'���`�����۽íx'});
$IsHitNPC=int(rand(3));
if ((@NPC_VALUE[25] eq 0) && (@NPC_VALUE[15] >10))
{
if ($IsHitNPC eq 1)
{
if ((@PL_VALUES[20]+@PL_VALUES[21])<(@NPC_VALUE[19]+@NPC_VALUE[21]))
{
$NPCAttackHP=int(rand(100000));@ALLVS_VALUES[15]-=$NPCAttackHP;
$ResultTag.=".$CountryAutoAttackID �D�즺�`�����۽íx�ϧ�l�� $NPCAttackHP HP. ";
$SpecialReport="$CountryAutoAttackID �D�즺�`�����۽íx�ϧ�l�� $NPCAttackHP HP. ";
if (@ALLVS_VALUES[15] <=0 )
{
$ResultTag.=".$CountryAutoAttackID �D�즺�`�����۽íx�ϧ�l�� $NPCAttackHP HP �j��. ";
$SpecialReport="$CountryAutoAttackID �D�즺�`�����۽íx�ϧ�l�� $NPCAttackHP HP �j��. ";
@ALLVS_VALUES[15]=-1;
@ALLVS_VALUES[25]=1;
}	
WriteSNGMsg("GM01����:$SpecialReport ");
}
if (@ALLVS_VALUES[21]<@NPC_VALUE[21])
{
$NPCStoleMoney=int(rand(10000));@ALLVS_VALUES[8]-=$NPCStoleMoney;
$ResultTag.=".$CountryAutoAttackID �D�즺�`�����۽íx�Q�m$NPCStoleMoney ��. ";
$SpecialReport="$CountryAutoAttackID �D�즺�`�����۽íx�m$NPCStoleMoney ��. ";
}
WriteSNGMsg("GM01����:$SpecialReport ");
}
}

}	
#========================================================



	for ($Plt=1;$Plt < 100; $Plt++ ){
		$Pl_Initiative=$Pl_SpPoint+int(rand(30));$Vs_Initiative=$Vs_SpPoint+int(rand(30));
		if($Pl_Initiative >= $Vs_Initiative){$Initiative=1;}else{$Initiative=0;}
		if($VS_W >= $Vs_W[3] && $PL_W >= $Pl_W[3]){last;}
		if ($Vs_AtPoint < $PL_VALUES[15] && $PL_W < $Pl_W[3] && ($Initiative || $VS_W >= $Vs_W[3])){
			$Pl_Check=int(rand(100)+$Vs_SpPoint/2-$Pl_MisPoint/2);$PL_W++;
			if ($Pl_Check < $Pl_W[2]){$PlResult.="$hImg";$Pl_Times++;
				$Pl_AtPoint=$Pl_AtPoint+int($Pl_AttPoint-int($Vs_DefPoint*(int(rand(50)+90))/$Pl_W[3]));
			}elsif ($Pl_Check >= $Pl_W[2]) {$PlResult.="$mImg";}
		unless($PL_W % 10){$PlResult.="";}
		next;
		}
		if ($Pl_AtPoint < $VS_VALUES[15] && $VS_W < $Vs_W[3] && (!$Initiative || $PL_W >= $Pl_W[3])){
			$Vs_Check=int(rand(100)+$Pl_SpPoint/2-$Vs_MisPoint/2);$VS_W++;
			if ($Vs_Check < $Vs_W[2]){$VsResult.="$hImg";$Vs_Times++;
				$Vs_AtPoint=$Vs_AtPoint+int($Vs_AttPoint-int($Pl_DefPoint*(int(rand(50)+90))/$Vs_W[3]));
			}elsif ($Vs_Check >= $Vs_W[2]){$VsResult.="$mImg";}
		unless($VS_W % 10){$VsResult.="";}
		next;
		}
	}


#================�԰����o�ͪ���=======
$StealMoney=50000;
$Event_hissatu=int(rand(150))+1;
		if ($Pl_Check < $Pl_W[2]){
		if ($Event_hissatu == 1){($ResultTag.= "<font color=$CL_VALUES[0]>$FORM{'pname'} �H2�������O..�ĤO�@��</font>");$Pl_AtPoint=int($Pl_AtPoint*2);}
		if ($Event_hissatu == 2){($ResultTag.= "<font color=$CL_VALUES[0]>$FORM{'pname'} ���u�դU�������O�L�Ī��I�v</font>");$Vs_AtPoint=int($Vs_AtPoint*0.2);}
		if ($Event_hissatu == 3){($ResultTag.= "<font color=$CL_VALUES[0]>$FORM{'pname'} ���u�դU�������w�g�Q�ڬݬ�F�v</font>");$Pl_AtPoint=int($Pl_AtPoint+$Vs_AtPoint/100);}
		if ($Event_hissatu == 4){($ResultTag.= "<font color=$CL_VALUES[0]>$FORM{'pname'} ��z�������I</font>");$Pl_AtPoint=int($Pl_AtPoint*0.5);}
		if (($Event_hissatu==5)&&($PL_VALUES[5])){($ResultTag.= "<font color=$CL_VALUES[0]><B>$PL_VALUES[5]�n��䴩����<B></font>");$Pl_AtPoint=int($Pl_AtPoint*5);}
		if (($Event_hissatu==6)&&($VS_VALUES[5])){($ResultTag.= "<font color=$VC_VALUES[0]><B>$VS_VALUES[5] �z�Z�����</B></font>");$Pl_AtPoint=int($Pl_AtPoint*0.001);}
		if ($Event_hissatu == 7){($ResultTag.= "<font color=$PL_VALUES[13]>$FORM{'pname'} �ϥΥ����I<br><b>$PL_VALUES[39]</b></font>");$Pl_AtPoint=int($Pl_AtPoint*3);}
		#if ($Event_hissatu == 8){($ResultTag.= "<font color=$CL_VALUES[0]>$FORM{'pname'} �Q�������] $StealMoney G�I�I�I�I(�N)</font>");if (($StealMoney - $PL_VALUES[8])>0) {$PL_VALUES[8]-=50000;$VS_VALUES[8]+=50000;} else {$ResultTag.="�i�c!!����֪���..�����F..��ڭ˾`.";}}
		if ($Event_hissatu == 9){($ResultTag.= "<font color=$CL_VALUES[0]>����$FORM{'vsname'} �Ӱ��@�Ӷ��e�B�ʦn�F�I</font>");$Pl_AtPoint=int($Pl_AtPoint*1.2);}
		if ($Event_hissatu == 10){($ResultTag.= "<font color=$CL_VALUES[0]>$FORM{'pname'} �ߨ�F�@���j���l�I300000G </font>");$PL_VALUES[8]+=300000}
		if (($Event_hissatu==11)&&($PL_VALUES[5])){($ResultTag.= "<font color=$CL_VALUES[0]><B>$PL_VALUES[5] ��a���ɵ������F<br>$FORM{'pname'}��EN�^�_ 50000<B></font>");$PL_VALUES[17]+=50000}
		if ($Event_hissatu == 12){($ResultTag.= "<font color=$CL_VALUES[0]>$FORM{'pname'} �@���J��,���m�פW��</font>");$PL_VALUES[24]+=30}
		if ($Event_hissatu == 13){($ResultTag.= "<font color=$CL_VALUES[0]>$FORM{'pname'} �������F 50000 G</font>");$PL_VALUES[8]-=50000;if($PL_VALUES[8] < 0){$PL_VALUES[8] = 0}}
		if ($Event_hissatu == 14){($ResultTag.= "<font color=$CL_VALUES[0]>$FORM{'pname'} �Q�����A���m�U��10�I!</font>");$PL_VALUES[24]-=10;if($PL_VALUES[24] < 0){$PL_VALUES[24] = 0}}
		if ($Event_hissatu == 15){($ResultTag.= "<font color=$CL_VALUES[0]>$FORM{'pname'} ��a�e�Ӫ��ɵ�����IHP�^�_ 10000</font>");$PL_VALUES[15]+=10000}
		if ($Event_hissatu == 16){($ResultTag.= "<font color=$PL_VALUES[13]>$FORM{'pname'} �ϥζW�����C�C<br><b>$PL_VALUES[66]</b></font>");$Pl_AtPoint=int($Pl_AtPoint*4.5);}
		if ($Event_hissatu == 17){($ResultTag.= "<font color=$CL_VALUES[0]>$FORM{'pname'} �ϥΨ��@�ޡA�j�j����C��誺����</font>");$Vs_AtPoint=int($VS_AtPoint*0.00001);}
		if ($Event_hissatu == 18){($ResultTag.= "<font color=$PL_VALUES[13]>$FORM{'pname'} �o�{�@���}���q��-EN�W������ 3 </font>");if($PL_VALUES[18] < 10000){$PL_VALUES[18]+=3}}
		if ($Event_hissatu == 19){($ResultTag.= "<font color=$PL_VALUES[13]>$FORM{'pname'} �ϥX�@�쯫����Ǯa�A���F�����A�A���A��y�˥ҡAHP�W������ 10 </font>");if($PL_VALUES[16] < 100000){$PL_VALUES[16]+=10}}
		if ($Event_hissatu == 20){($ResultTag.= "<font color=$PL_VALUES[13]>$FORM{'pname'} ���˥ҳQ������}�AHP�W����� 5 </font>");$PL_VALUES[16]-=5}
		if ($Event_hissatu == 21){($ResultTag.= "<font color=$PL_VALUES[13]>$FORM{'pname'} ���෽�˸m�Q�������A�෽�W����� 1</font>");$PL_VALUES[18]-=1}
}


	$Event_vshissatu=int(rand(150))+1;
		if ($Vs_Check < $Vs_W[2]){
		if ($Event_vshissatu == 1){($ResultTag.= "<font color=$VC_VALUES[0]>$FORM{'vsname'} �H2 ������..�ĤO�@��</font>");$Vs_AtPoint=int($Vs_AtPoint*2);}
		if ($Event_vshissatu == 2){($ResultTag.= "<font color=$VC_VALUES[0]>$FORM{'vsname'}�u�դU�������O�L�Ī��I�v���D�I</font>");$Pl_AtPoint=int($Pl_AtPoint*0.2);}
		if ($Event_vshissatu == 3){($ResultTag.= "<font color=$VC_VALUES[0]>$FORM{'vsname'}�u�դU�������w�g�Q�ڬݬ�F�v�s�D</font>");$Vs_AtPoint=int($Vs_AtPoint+$Pl_AtPoint/100);}
		if ($Event_vshissatu == 4){($ResultTag.= "<font color=$VC_VALUES[0]>$FORM{'vsname'} ��z�������I</font>");$Vs_AtPoint=int($Vs_AtPoint*0.5);}
  		if (($Event_vshissatu==5)&&($VS_VALUES[5])){($ResultTag.= "<font color=$VC_VALUES[0]><B>$VS_VALUES[5]�n��䴩����<B></font>");$Vs_AtPoint=int($Vs_AtPoint*5);}
		if (($Event_vshissatu==6)&&($PL_VALUES[5])){($ResultTag.= "<font color=$CL_VALUES[0]><B>$PL_VALUES[5] �z�Z�����</B></font>");$Vs_AtPoint=int($Vs_AtPoint*0.001);}
    		if ($Event_vshissatu == 7){($ResultTag.= "<font color=$VS_VALUES[13]>$FORM{'vsname'} �ϥΥ���!<br><b>$VS_VALUES[39]</b></font>");$Vs_AtPoint=int($Vs_AtPoint*3);}
		if ($Event_vshissatu == 8){($ResultTag.= "<font color=$VC_VALUES[0]>$FORM{'vsname'} $FORM{'pname'}(�N�^</font>");$Vs_AtPoint=int($Vs_AtPoint*0.5);}
		if ($Event_vshissatu == 9){($ResultTag.= "<font color=$VC_VALUES[0]>�n��$FORM{'pname'} ��1.2���O�����</font>");$Vs_AtPoint=int($Vs_AtPoint*1.2);}
		#if ($Event_vshissatu == 10){($ResultTag.= "<font color=$VC_VALUES[0]>$FORM{'vsname'} �ߨ�F�@���j���l�I200000 G</font>");$VS_VALUES[8]+=200000;}
	  	if (($Event_vshissatu==11)&&($VS_VALUES[5])){($ResultTag.= "<font color=$VC_VALUES[0]><B>$VS_VALUES[5] ��a���ɵ������F<br>$FORM{'vsname'}  EN�^�_ 10000<B></font>");$VS_VALUES[17]+=10000}
		if ($Event_vshissatu == 12){($ResultTag.= "<font color=$VC_VALUES[0]>$FORM{'vsname'} �j�����}, ���m�פW�� 30</font>");$VS_VALUES[24]+=30}
		#if ($Event_vshissatu == 13){($ResultTag.= "<font color=$VC_VALUES[0]>$FORM{'vsname'} ����F 50000 G</font>");$VS_VALUES[8]-=50000;if($VS_VALUES[8] < 0){$VS_VALUES[8] = 0}}
		if ($Event_vshissatu == 14){($ResultTag.= "<font color=$VC_VALUES[0]>$FORM{'vsname'} �Q�����A���m�U��10�I�I</font>");$VS_VALUES[24]-=10;if($VS_VALUES[24] < 0){$VS_VALUES[24] = 0}}
		if ($Event_vshissatu == 15){($ResultTag.= "<font color=$VC_VALUES[0]>$FORM{'vsname'} ��a�e�Ӫ��ɵ�����IHP�^�_200000</font>");$VS_VALUES[15]+=200000}
	  	if ($Event_vshissatu == 16){($ResultTag.= "<font color=$VS_VALUES[13]>$FORM{'vsname'} �ϥζW�����C�C<br><b>$VS_VALUES[66]</b></font>");$Vs_AtPoint=int($Vs_AtPoint*4.5);}
	  	if ($Event_vshissatu == 17){($ResultTag.= "<font color=$VC_VALUES[0]>$FORM{'vsname'} �ϥΨ��@�ޡA�j�j����C��誺����</font>");$Vs_AtPoint=int($Vs_AtPoint*0.000001);}
		#if ($Event_vshissatu == 18){($ResultTag.= "<font color=$VS_VALUES[13]>$FORM{'vsname'} �o�{�@���}���q��-EN�W������ 3 </font>");if($VS_VALUES[18] < 10000){$VS_VALUES[18]+=3}}
		#if ($Event_hissatu == 19){($ResultTag.= "<font color=$VS_VALUES[13]>$FORM{'vsname'} �ϥX�@�쯫����Ǯa�A���F�����A�A���A��y�˥ҡAHP�W������ 10 </font>");if($VS_VALUES[16] < 100000){$VS_VALUES[16]+=10}}
		if ($Event_hissatu == 20){($ResultTag.= "<font color=$VS_VALUES[13]>$FORM{'vsname'} ���˥ҳQ������}�AHP�W����� 5 </font>");$VS_VALUES[16]-=5}
		if ($Event_hissatu == 21){($ResultTag.= "<font color=$VS_VALUES[13]>$FORM{'vsname'} ���෽�˸m�Q�������A�෽�W����� 1</font>");$VS_VALUES[18]-=1}
	
	}
	





#========================================
@GetAns=split(/!/,$PL_VALUES[9]);
@Get3Ans=split(/!/,$PL_VALUES[98]);
@GetVSAns=split(/!/,$VS_VALUES[9]);
if (rindex($FORM{'vsname'},"�W�X�]") ne -1)
{

if (@GetAns[0] eq "wya0002")
{
$SpecialReport=" $FORM{'vsname'} ��:�Q�Φ����C����? �ڨ��W�����@�n�@��..$FORM{'pname'}�������C���l�F..";
$ResultTag.=$SpecialReport;
$PLWeaponDemage=1;
}	

if ($PL_VALUES[15] < 2000)
{
$SpecialReport="$FORM{'pname'}�b�P$FORM{'vsname'}�����L�{���Q�o�{�����z.��O�ĤH�κɥ��O�@��..";
$ResultTag.=$SpecialReport;
$PL_VALUES[15]=-1;
WriteSNGMsg("GM01����:$SpecialReport ");
}	

$SpecialDone=int(rand(12));
#$ResultTag.="===$SpecialDone===";



if ($SpecialDone eq 3)
{
if (@Get3Ans[0] eq 'hpkubiki')
{
$SpecialReport="GM01����:$FORM{'vsname'}�o�g..�ϥ��]������q�n�N$FORM{'pname'}�_�}.��$FORM{'pname'}�έ��O�_�۩w���b��a.";
}
else	
{
   @PL_VALUES[95]=int rand(100);
   @PL_VALUES[96]=int rand(100);
   $SpecialReport="GM01����:$FORM{'vsname'}�o�g..�ϥ��]������q..�N$FORM{'pname'}�_�� X:@PL_VALUES[95],Y:@PL_VALUES[96]";
}   
}	


if ($SpecialDone eq 4)
{
$PL_VALUES[15]=int($PL_VALUES[15]/(rand(500)+500));
$SpecialReport="$VS_VALUES[15]HP��$FORM{'vsname'}�ϥ��]���g�V$FORM{'pname'}..�Ϩ�HP��t����$PL_VALUES[15].";
}

if ($SpecialDone eq 6)
{
$StealMoneyValue=int(rand(10000)+10000);
$PL_VALUES[8]-=$StealMoneyValue;
$SpecialReport="$VS_VALUES[15]HP��$FORM{'vsname'}��$FORM{'pname'}�W�U��ⰽ��$StealMoneyValue��";
if ($PL_VALUES[8] < 0){$PL_VALUES[8] = 0;}
}

if ($SpecialDone eq 7)
{
$GetMoneyValue=int(rand(10000)+1000);
$PL_VALUES[8]+=$GetMoneyValue;
$SpecialReport="$VS_VALUES[15]HP��$FORM{'vsname'}���p�ߪg��W�X�]��..�b���r�ɳQ$FORM{'pname'}�X������$GetMoneyValue��";
}

if ($SpecialDone eq 8)
{
if ($FORM{'vsname'} eq '�W�X�]�����H')
{
$DoubleTime=abs(int(rand(3))+2);
$FDoubTime=$DoubleTime-1;
my $DoubleAtt=abs($Pl_AtPoint*$FDoubTime);
$SpecialReport="$VS_VALUES[15]HP��$FORM{'vsname'}�l��$FORM{'pname'}��$FDoubTime�������O����HP,�W�[ $DoubleAtt �IHP.";
$VS_VALUES[15]+=$DoubleAtt;
}	
else
{
$GetHP=abs(int(rand($PL_VALUES[15])+1000));
$PL_VALUES[15]-=$GetHP;
$SpecialReport="$VS_VALUES[15]HP��$FORM{'vsname'}�l��$FORM{'pname'}HP,�W�[$GetHP HP.�Ϩ�HP����$PL_VALUES[15]";
}	
$VS_VALUES[15]+=$GetHP;
}

if ($SpecialDone eq 9)
{
if ($FORM{'vsname'} eq '�W�X�]�����H')
{
$SetMaxHPUPRate=int(rand(9))+1;
$MinusHPUP=int(rand(3))+5;
if ($SetMaxHPUPRate == 2){$MinusHPUP=int(rand(10))+5;}

$PL_VALUES[15]-=$MinusHPUP*1000;
$PL_VALUES[16]-=$MinusHPUP;
$SpecialReport="$FORM{'vsname'}�ΥͩR�����Y(�Q��)�}�a$FORM{'pname'}�ثeHP�P$MinusHPUP HP�W����$PL_VALUES[16] HP.";

}	
}


if ($SpecialReport ne "")
{
$ResultTag.=$SpecialReport;
WriteSNGMsg("GM01����:$SpecialReport ");
}

}	
	

#================== SPECIAL MONSTER ==================
if ($FORM{'vsname'} eq $SpecialMonster)
{
$RandTime=int(rand(6))+1;
if ($RandTime == 3)
{
$DoubleTime=int(rand(3))+2;
$FDoubTime=$DoubleTime+1;
my $DoubleAtt=$Pl_AtPoint*$FDoubTime;
if($DoubleAtt < 0){$DoubleAtt=$DoubleAtt*(-1);}
$SpecialReport="$VS_VALUES[15]HP��$FORM{'vsname'}�l��$FORM{'pname'}��$FDoubTime�������O����HP,�W�[ $DoubleAtt �IHP.";
$VS_VALUES[15]+=$DoubleAtt;
$ResultTag.=$SpecialReport;
WriteSNGMsg("GM01����:$SpecialReport ");
}


}	
#===================================




if ($PL_Country eq '�ۥѾԤh')
{
if ($PL_VALUES[8] > 1000000)
{
$LoseMoney=$PL_VALUES[29]*5;
$PL_VALUES[8]-=$LoseMoney;
$ResultTag.="�����F$LoseMoney G ..�֧��a�[�J�a!";
}
}	
	
        if ($VS_Limit eq 1)
        {
        $Vs_AttPoint=0;
        $Vs_Times=0;
        $ResultTag.= "<font color=$VC_VALUES[0]>�Ĥ赥�Ť����L�k�ϥΥثe�Z��! </font>";
        $BufferBlod=$PL_VALUES[15];
        
        }        	


$OrgAtpoint=$Pl_AtPoint;
if (($PL_VALUES[95] != $VS_VALUES[95]) || ($PL_VALUES[96] != $VS_VALUES[96]))
{
if ($Pl_W[7] ==153)
{
$ResultTag.="�l���~�������ʨ�ĤH��m�����ˮ`....";
}	
else
{
$ResultTag.="�ѩ󻷶Z�������S�˷Ǧn..�ҥH����ˮ`���..";
$LoseAttRate=abs($PL_VALUES[95] - $VS_VALUES[95])+abs($PL_VALUES[96] - $VS_VALUES[96])+1;

$Vs_AtPoint=int($Vs_AtPoint/$LoseAttRate);
$Pl_AtPoint=int($Pl_AtPoint/$LoseAttRate);

}
}


@GetOPPLAns=split(/!/,$PL_VALUES[9]);
@GetWepInfo=split(/\,/,$WEAPON_LIST{"@GetOPPLAns[0]"});

if ($Pl_W[7] == 155)
{
#==
$ResultTag.=" ����@GetWepInfo[3]�H. ";
$Attidx=0;
$IllID="";
while (($Key,$Value) = each %P)
{
if (length($Key > 50)){$IllID=$Key;}
@OTVS_VALUES = split(/\s/,$Value);
if (($Key ne $FORM{'pname'}) && (@OTVS_VALUES[5] eq $VS_VALUES[5]) && (@OTVS_VALUES[25] != 1))
{
$LoseAttRate=abs($PL_VALUES[95] - $OTVS_VALUES[95])+abs($PL_VALUES[96] - $OTVS_VALUES[96])+1;
$OTPl_AtPoint=int($OrgAtpoint/$LoseAttRate);

@OTVS_VALUES[15]-=$OTPl_AtPoint;
$P{"$Key"}="@OTVS_VALUES";
$ResultTag.="$Key ����ˮ` $OTPl_AtPoint HP. ";
$Attidx++;
}
if ($Attidx >= @GetWepInfo[3]){last;}

}
#===
}


if (($FORM{'b_mode'} eq '����') && ($Pl_W[7] == 15))
{
&ERROR('���i�ϥΦ��z����') ;
}


if (($VS_VALUES[77] == 1) && ($Pl_W[7] == 15))
{
$tasvaluemsg="GM01����:$FORM{'pname'} ��$FORM{'vsname'}�ϥΦ��z�L�� HP:@VS_VALUES[15]";
WriteSNGMsg("$tasvaluemsg");
}
else
{
if ($Pl_W[7] == 15)
{
$ResultAfterFight.=" $FORM{'pname'}�ϥΦ��z�˸m";
$PL_VALUES[25]=1;
$PL_VALUES[15]=0;
if (($PL_VALUES[95] == $VS_VALUES[95]) && ($PL_VALUES[96] == $VS_VALUES[96]) )
{
@GetPLHandArm=split(/!/,$PL_VALUES[9]);
@GetPLHandArmInfo=split(/\,/,$WEAPON_LIST{"@GetPLHandArm[0]"});
$DiePoint=(@GetPLHandArmInfo[1]*@GetPLHandArmInfo[3])+$PL_VALUES[16];
$ResultAfterFight.=" ��ĤH���J�z����!�l�� $DiePoint HP";
$VS_VALUES[15]-=$DiePoint;
if ($VS_VALUES[15] <=0 ){$VS_VALUES[25]=1;$ResultAfterFight.=" ��ĤH�j�}.";}
$Pl_AtPoint=$DiePoint;
$Vs_AtPoint=$DiePoint;
}	
else
{
$ResultAfterFight.=" �ĤH�Z���ӻ������v�T!";
}	

}	








if ($PL_VALUES[82] eq ""){$PL_VALUES[82]=0;}
if ($VS_VALUES[82] eq ""){$VS_VALUES[82]=0;}

if ($PL_VALUES[82] == 1)
{
 if (($Pl_W[7] > 0) && ($Pl_W[7] < 150)){Warning("���Z���u�����Ԥh���(�R���Ҧ�)");}	
}

if ($PL_VALUES[82] == 0)
{
if ($Pl_W[7] >=150){Warning("���]�k�u���]�k�v���(�R���Ҧ�)");}	
}

if ($VS_VALUES[82] == 1)
{
if (($Vs_W[7] > 0) && ($Vs_W[7] < 150)){$Vs_AtPoint=0;$ResultTag.=' ���ϥξ��Ԥh�Z���L��..';}	
}

if ($VS_VALUES[82] == 0)
{
if ($Vs_W[7] >=150){$Vs_AtPoint=0;$ResultTag.=' ���ϥ��]�k�v�Z���L��..';}	
}



$AttackStatusText='�����F';
$AttackStatusText2='�}�a';
if ($Pl_W[7] ==152)
{
$AttackStatusText='�v���F';
$AttackStatusText2='�v��';
}

if ($Vs_W[7] ==152)
{
$Vs_AtPoint=0;
}

	$Pl_AtPoint=0 if $Pl_AtPoint < 0;
	$Vs_AtPoint=0 if $Vs_AtPoint < 0;


	$dmgStyl="style=\"font-size:10px;color:#9acd32;\"";
	$chaStyl="style=\"font-size:10px;color:#dc143c;\"";
	$PlsumDmg="<br><b $dmgStyl>$Pl_W[3]</b> <b $chaStyl>������</b>  <b $chaStyl>$AttackStatusText</b> <b $dmgStyl>$Pl_Times</b> <b $chaStyl>��</b>
		<b $dmgStyl>$Pl_AtPoint</b><b $chaStyl> ��$AttackStatusText2</b>" if $Pl_Times > 0;
	$PlsumDmg='<font color=#6a5acd>Miss</font>' if $Pl_Times == 0;
	$VssumDmg="<br><b $dmgStyl>$Vs_W[3]</b> <b $chaStyl>������</b> <b $chaStyl>�����F</b> <b $dmgStyl>$Vs_Times</b> <b $chaStyl>��</b>
		<b $dmgStyl>$Vs_AtPoint</b><b $chaStyl> ���}�a</b>" if $Vs_Times > 0;
	$VssumDmg='<font color=#6a5acd>Miss</font>' if $Vs_Times == 0;
	$Pl_BfrHP=$PL_VALUES[15];


	$Vs_AtPoint=$PL_VALUES[15] if $PL_VALUES[15] < $Vs_AtPoint;

        $PL_VALUES[15]=$PL_VALUES[15]-$Vs_AtPoint;

	$Pl_width_per=$PL_VALUES[16]/150;
	$Pl_width_hp=int($PL_VALUES[15]/$Pl_width_per);
	$Pl_width_zen=int(($PL_VALUES[16]-$Pl_BfrHP)/$Pl_width_per);
	$Pl_width_dmg=int($Vs_AtPoint/$Pl_width_per);
	$PL_HPTAG="<img src=\"$IMG_FOLDER1/hp.gif\" hspace=0 height=7 width=$Pl_width_hp>" if $Pl_width_hp;
	$PL_HPTAG.="<img src=\"$IMG_FOLDER1/dmg.gif\" hspace=0 height=7 width=$Pl_width_dmg>" if $Pl_width_dmg;
	$PL_HPTAG.="<img src=\"$IMG_FOLDER1/zen.gif\" hspace=0 height=7 width=$Pl_width_zen>" if $Pl_width_zen;
	$Vs_BfrHP=$VS_VALUES[15];
	$Pl_AtPoint=$VS_VALUES[15] if $VS_VALUES[15] < $Pl_AtPoint;


if ($Pl_W[7] ==152)
{
$VS_VALUES[15]=$VS_VALUES[15]+$Pl_AtPoint;
}	
else	
{
$VS_VALUES[15]=$VS_VALUES[15]-$Pl_AtPoint;
}


	$Vs_width_per=$VS_VALUES[16]/150;
	$Vs_width_hp=int($VS_VALUES[15]/$Vs_width_per);
	$Vs_width_zen=int(($VS_VALUES[16]-$Vs_BfrHP)/$Vs_width_per);
	$Vs_width_dmg=int($Pl_AtPoint/$Vs_width_per);
	$VS_HPTAG="<img src=\"$IMG_FOLDER1/hp.gif\" hspace=0 height=7 width=$Vs_width_hp>" if $Vs_width_hp;
	$VS_HPTAG.="<img src=\"$IMG_FOLDER1/dmg.gif\" hspace=0 height=7 width=$Vs_width_dmg>" if $Vs_width_dmg;
	$VS_HPTAG.="<img src=\"$IMG_FOLDER1/zen.gif\" hspace=0 height=7 width=$Vs_width_zen>" if $Vs_width_zen;









        if ($VS_Limit eq 1)
        {
        $PL_VALUES[15]=$BufferBlod;
        }        	

WORL:{
	$VS_VALUES[15] == 0 && $PL_VALUES[15] > 0 && do{
		$ResultBattle=0;
		$PL_In[0]=int (rand(5)+8);$VS_In[0]=int (rand(2)+2);
		$PL_In[1]=3;$VS_In[1]=-2;
		
if ($MoneyLevel eq 1)
{
		$PL_In[2]=int(rand(200)+400)+(200*$GET_MONEY);
		$VS_In[2]=int(rand(200)+400)+((250-$VS_VALUES[29])*int($GET_MONEY/3));
}
else
{
		$PL_In[2]=int(rand(200)+400)+((250-$PL_VALUES[29])*$GET_MONEY);
		$VS_In[2]=int(rand(200)+400)+((250-$VS_VALUES[29])*int($GET_MONEY/3));
}			
		
		$PL_VALUES[24]++;$VS_VALUES[25]=1;
		($PL_VALUES[0]=0,$PL_VALUES[5]="$FORM{'boumeiC'}",$B_Com='����',$PL_VALUES[6]=0)if $FORM{'b_mode'} eq '�`�R';
		($PL_VALUES[6]="$VS_VALUES[6]",$PL_VALUES[28]="$VS_VALUES[28]",$VS_VALUES[6]=0,$Vs_KakutokuRank=-120,$VS_VALUES[5]=$VS_VALUES[28]='',$B_Com='����')
		if $FORM{'b_mode'} eq '����';
	last WORL;};
	$PL_VALUES[15] == 0 && $VS_VALUES[15] > 0 && do {
		$ResultBattle=1;
		$PL_In[0]=int (rand(2)+2);$VS_In[0]=int (rand(5)+8);
		$PL_In[1]=-2;$VS_In[1]=3;
if ($MoneyLevel eq 1)
{
		$PL_In[2]=int(rand(200)+400)+((250-$PL_VALUES[29])*int($GET_MONEY/3));
		$VS_In[2]=int(rand(200)+400)+(200*$GET_MONEY);
}
else
{
		$PL_In[2]=int(rand(200)+400)+((250-$PL_VALUES[29])*int($GET_MONEY/3));
		$VS_In[2]=int(rand(200)+400)+((250-$VS_VALUES[29])*$GET_MONEY);

}			

		$VS_VALUES[24]++;$PL_VALUES[25]=1;
		($PL_In[1]=int($PL_VALUES[0]/-3)*2,$B_Com='����') if $FORM{'b_mode'} eq '�`�R';
		($PL_In[1]=($PL_VALUES[0])*-1,$B_Com='����') if $FORM{'b_mode'} eq '����';
	last WORL;};
	$VS_VALUES[15] > 0 && $PL_VALUES[15] > 0 && do{
		$ResultBattle=2;
		$PL_In[0]=int (rand(3)+4);$VS_In[0]=int (rand(3)+4);
		$PL_In[1]=1;$VS_In[1]=1;
		$PL_In[2]=int(rand(200)+400);$VS_In[2]=int(rand(200)+400);
		($PL_In[1]=int($PL_VALUES[0]/-3)*2,$B_Com='����') if $FORM{'b_mode'} eq '�`�R';
		($PL_In[1]=($PL_VALUES[0])*-1,$B_Com='����') if $FORM{'b_mode'} eq '����';
	last WORL;};
}
	$PL_In[2]=400 if $PL_In[2]<10;$VS_In[2]=400 if $VS_In[2]<1;

	if ($Pl_W[7] == 13 )
	{
        $PL_In[2]=$PL_In[2]*2;
        $VS_In[2]=$VS_In[2]*2;
        }

	if (($Pl_W[7] == 18) && ($PL_VALUES[6] == 1))
	{
        $PL_In[2]=$PL_In[2]*2;
        $VS_In[2]=$VS_In[2]*2;
        
        }

 #       if (($C_VALUES[7] > time) && ($M_AITE eq $VS_Country))
#        {
         
#        }
#	else
#	{
	if ($Pl_W[7] ==17) 
	{
	$VS_In[1]=0;
	$VS_In[2]=0;
	$VS_In[4]=0;
	
	$PL_In[1]=0;
	$PL_In[2]=0;
        $PL_In[4]=int($PL_In[4]/10);
	}
	if ($Vs_W[7] ==17) 
	{
	$PL_In[1]=0;
	$PL_In[2]=0;
	$PL_In[4]=0;

	$VS_In[1]=0;
	$VS_In[2]=0;
	$VS_In[4]=int($VS_In[4]/10);
	}
#	}


	$PL_VALUES[0]+=$PL_In[1];
	$VS_VALUES[0]+=$VS_In[1];
	$PL_VALUES[8]+=$PL_In[2];
	
	if ($GiveVsMoneyInFight eq 1){$VS_VALUES[8]+=$VS_In[2];}
	
	$PL_VALUES[0]=0   if $PL_VALUES[0] < 0;
	$PL_VALUES[0]=215 if $PL_VALUES[0] >= 215;
	$PL_VALUES[0]=220 if $PL_VALUES[6] == 1;
	$VS_VALUES[0]=0   if $VS_VALUES[0] < 0;
	$VS_VALUES[0]=215 if $VS_VALUES[0] >= 215;
	$VS_VALUES[0]=220 if $VS_VALUES[6] == 1;
	$PL_VALUES[17]-=$Pl_W[4] if $Pl_Times;$PL_VALUES[17]=0 if $PL_VALUES[17] < 0;
	$Pl_vs="$VS_VALUES[5]��"if $VS_VALUES[5];$Pl_vs="�ۥѾԤh��"if !$VS_VALUES[5];
	$Vs_vs="$PL_VALUES[5]��"if $PL_VALUES[5];$Vs_vs="�ۥѾԤh��"if !$PL_VALUES[5];
local($PL_RETI1,$PL_RE1,$PL_RETI2,$PL_RE2,$PL_RETI3,$PL_RE3,$PL_RETI4,$PL_RE4,$PL_RETI5,$PL_RE5) = split(/!/,$PL_VALUES[1]);
local($VS_RETI1,$VS_RE1,$VS_RETI2,$VS_RE2,$VS_RETI3,$VS_RE3,$VS_RETI4,$VS_RE4,$VS_RETI5,$VS_RE5) = split(/!/,$VS_VALUES[1]);

$PL_VALUES[1]="$DATE!$FORM{'pname'}$IsUseDistoryWeapon�D�ʧ���$IsHitJoin$Pl_vs$FORM{'vsname'}." ;$PL_VALUES[26]=time;
$VS_VALUES[1]="$DATE!$IsHitJoin$FORM{'vsname'}�Q$Vs_vs$FORM{'pname'}$IsUseDistoryWeapon����." ;

$ResultTag.= $Tokusyu;

if ($ResultBattle==0)
{
if ($FORM{'vsname'} eq '�K�K') {$SpeciallNPCWords="..�A���N�ڥ���..�o�˭n���ڴ_���~��A���H�תZ���F..";}
$ResultTag.="$VS_VALUES[3]�j�}�C$SpeciallNPCWords <br>";
$PL_VALUES[1].="$VS_VALUES[3]�j�}�C";
$VS_VALUES[1].="$VS_VALUES[3]�j�}�C";
}




($ResultTag.="$PL_VALUES[3]�j�}�C<br>",$PL_VALUES[1].="$PL_VALUES[3]�j�}�C",$VS_VALUES[1].="$PL_VALUES[3]�j�}�C")
if $ResultBattle==1;



$PL_VALUES[1].="!".$PL_RETI1."!".$PL_RE1."!".$PL_RETI2."!".$PL_RE2."!".$PL_RETI3."!".$PL_RE3."!".$PL_RETI4."!".$PL_RE4;
$VS_VALUES[1].="!".$VS_RETI1."!".$VS_RE1."!".$VS_RETI2."!".$VS_RE2."!".$VS_RETI3."!".$VS_RE3."!".$VS_RETI4."!".$VS_RE4;
if ($ResultBattle==0){
$prize=$PL_VALUES[29]*20;$seikaku=int(rand(7));
if($wrecord eq ''){$wrecord=$wcount;$recnum=$cname;}
$VALS="$FORM{'pname'}<>$PL_VALUES[0]<>$PL_VALUES[1]<>$PL_VALUES[2]<>$PL_VALUES[3]<>$PL_VALUES[4]<>$PL_VALUES[5]<>$PL_VALUES[6]<>$PL_VALUES[7]<>$PL_VALUES[8]<>$PL_VALUES[9]<>$PL_VALUES[10]<>$PL_VALUES[11]<>$seikaku<>$PL_VALUES[13]<>$PL_VALUES[14]<>$PL_VALUES[15]<>$PL_VALUES[16]<>$PL_VALUES[17]<>$PL_VALUES[18]<>$PL_VALUES[19]<>$PL_VALUES[20]<>$PL_VALUES[21]<>$PL_VALUES[22]<>$PL_VALUES[23]<>$PL_VALUES[24]<>$PL_VALUES[25]<>$PL_VALUES[26]<>$PL_VALUES[27]<>$PL_VALUES[28]<>$PL_VALUES[29]<>$PL_VALUES[30]<>1<>$wrecord<>$recnum<>$prize<>\n";
}



#============ �԰��e��  ============
#<tr><td align=center width=50% bgcolor="$CL_VALUES[0]" style="color:#000000;font-size:25pt;">

	&HEADER;

#&DownFrameMax;
		
$ps_x=20;
$ps_y=150;
$vs_x=600;
$vs_y=150;
$vs_die=0;
$ps_die=0;
#VS�j�}
if ($ResultBattle==0)
{
$vs_die=1;
}

#PS�j�}
if ($ResultBattle==1)
{
$ps_die=1;
}	



if ($PL_VALUES[100] == "")
{
$PL_VALUES[100] = "175";
}	

if ($VS_VALUES[100] == "")
{
$VS_VALUES[100] = "175";
}	

if ($PL_VALUES[86] eq "") {$PL_VALUES[86] = 0;}

print << "	-----END-----";
<script LANGUAGE="JavaScript">
<!--
self.document.body.bgcolor="ffffff";
self.document.body.background="$IMG_FOLDER0/darksky.gif";
//-->
</script>         



<div id=psbodydata style="position: absolute; visibility: visible; z-index: 900; top:5; left:70;"><br></div> 
<div id=vsbodydata style="position: absolute; visibility: visible; z-index: 900; top:5; left:540;"><br></div>
<div id=vsbody style="position: absolute; visibility: visible; z-index: 900; top: $vs_y; left: $vs_x;"><img src="$IMG_FOLDER2/$VS_VALUES[27].gif" name="vsimg"></div>
<div id=psbody style="position: absolute; visibility: visible; z-index: 900; top: $ps_y; left: $ps_x;"><img src="$IMG_FOLDER2/$PL_VALUES[27].gif" name="plimg" style="filter:fliph();"></div> 
<div id=dieword style="position: absolute; visibility: visible; z-index: 900; top: -1000; left: -1000;font-size=70px;"><center><font color="red"><b>K.O</b></font></center></div> 
<div id=diebody style="position: absolute; visibility: visible; z-index: 900; top: -1000; left: -1000;"> <img src="$IMG_FOLDER0/diebody.gif"></div> 
<div id=attacklight style="position: absolute; visibility: visible; z-index: 900; top: -1000; left: -1000;"> <img src="$IMG_FOLDER0/attacklight.gif"></div> 
<div id=light style="position: absolute; visibility: visible; z-index: 900; top: -1000; left: -1000;"> <img src="$IMG_FOLDER0/flash.gif" name="flash"></div> 
<div id=ps_god_sword style="position: absolute; visibility: visible; z-index: 900; top: -1000; left:-1000;"> <img src="$IMG_FOLDER0/god_sword.gif" name="god_sword" style="filter:fliph();"></div> 
<div id=vs_god_sword style="position: absolute; visibility: visible; z-index: 900; top: -1000; left:-1000;"> <img src="$IMG_FOLDER0/god_sword.gif"></div> 
<div id=ps_weapon_a style="position: absolute; visibility: visible; z-index: 900; top: -1000; left:-1000;"> <img src="$IMG_FOLDER0/weapon_a.gif" name="weapon_a" style="filter:fliph();"></div> 
<div id=vs_weapon_a style="position: absolute; visibility: visible; z-index: 900; top: -1000; left:-1000;"> <img src="$IMG_FOLDER0/weapon_a.gif"></div> 
<div id=dieflash style="position: absolute; visibility: visible; z-index: 900; top: -1000; left: -1000;"> <img src="$IMG_FOLDER0/boom1.gif" name="boom1"></div> 

<bgsound id=wigwag >
<bgsound id=boomsound >
<bgsound id=background_mus>


<script LANGUAGE="JavaScript">
<!--

var ko_sound="$SoundDir/ko.wav";
var boom1_sound="$SoundDir/boom1.wav";
var boom2_sound="$SoundDir/boom2.wav";
var boom3_sound="$SoundDir/boom3.wav";
var boom4_sound="$SoundDir/boom4.wav";
var fightbg1_sound="$SoundDir/fightmusic1.wav";

var ps_x=$ps_x;
var ps_y=$ps_y;
var vs_x=$vs_x;
var vs_y=$vs_y;
var ps_x_org=ps_x;
var vs_x_org=vs_x;
var timespeed=100;
var fcount=0;
var attacktimes=5;
var actiondown=0;
var flash_x,flash_y;
var flash_width=81;
var flash_height=83;
var bgflash_counter=6;
var dieflash_x,dieflash_y;
var shark_counter=10;
var diefontsize=50;
var Fresh_counter=10;
var IsHit=0;
var ps_speed_x=30;
var vs_speed_x=30;
var vs_backtime=30;
var ps_backtime=30;
var light_type="dieflash";
var sound_switch=$PL_VALUES[86];
var vsbig=1;plbig=1;

var ps_weapon_type_img = "ps_weapon_a";
var ps_weapon_width=document.images['weapon_a'].width;
var ps_weapon_height=document.images['weapon_a'].height;

var vs_weapon_type_img = "vs_weapon_a";
var vs_weapon_width=document.images['weapon_a'].width;
var vs_weapon_height=document.images['weapon_a'].height;

var dieflash_width=document.images['boom1'].width;
var dieflash_height=document.images['boom1'].height;

document.images['vsimg'].width=document.images['vsimg'].width*vsbig;
document.images['vsimg'].height=document.images['vsimg'].height*vsbig;
document.images['plimg'].width=document.images['plimg'].width*plbig;
document.images['plimg'].height=document.images['plimg'].height*plbig;

function prv_fun_sound(theobj)
{
if (sound_switch == 0 ) return;
var mysound= eval("document.all."+theobj);
mysound.src=ko_sound;
}



function gobal_fun_get_random(num_area)
{
var rnd=Math.random()*10000*Math.random();
return (Math.floor(rnd%num_area));
}   


function dieword_size()
{
if (diefontsize > 120)
{
return;
}	
diefontsize=diefontsize+21;
document.all["dieword"].style.fontSize=diefontsize;
document.all["dieword"].style.visibility="visible";

if ((diefontsize % 2) == 0)
{
visible_object("dieword");
}
else
{
hidden_object("dieword");
}	

setTimeout('dieword_size()',45);  
}	

function bgcolor_change()
{
 document.bgColor=gobal_fun_get_random(999999);
 if (bgflash_counter > 0)
   {
    bgflash_counter--;
    document.bgColor="ffffff";
    setTimeout('bgcolor_change()',5);  
   }
}	

function gobal_fun_moveto(objectName,x,y)
{
eval('document.all["'+objectName+'"].style'+'.top='+y);
eval('document.all["'+objectName+'"].style'+'.left='+x);
}

function hidden_object(objectName)
{
eval('document.all["'+objectName+'"].style'+'.visibility="hidden";');
}

function visible_object(objectName)
{
eval('document.all["'+objectName+'"].style'+'.visibility="visible";');
}

function fliph_object(objectName)
{
eval('document.all["'+objectName+'"].style'+'.filter="fliph()";');
}

function shark(longtime,strong)
{
shark_counter--;
var shark_x=gobal_fun_get_random(strong);
var shark_y=gobal_fun_get_random(strong+5);
window.moveTo(shark_x,shark_y); 
if (shark_counter > 1)
{
setTimeout('bgcolor_change()',longtime);  
}
}


function PlaySound(SoundID,SoundFileName)
{
if (sound_switch ==1)
 	{
if (SoundID == "ko" )
	{
 	if (sound_switch ==1)
 	{
 	document.all.wigwag.src=SoundFileName;
 	document.all.wigwag.play=1;
 	sound_switch =0;
 	}
	}
if (SoundID == "boom" )
	{
 	document.all.boomsound.src=SoundFileName;
 	document.all.boomsound.play=1;
 	}

if (SoundID == "backbg" )
	{
 	document.all.background_mus.src=SoundFileName;
 	document.all.background_mus.play=1;
 	}

}
}

function fighter()
{



if ("$Pl_W[0]" == "�Ҥ������`�ӼC")
{
 ps_weapon_type_img="ps_god_sword";
 ps_weapon_height=document.images['god_sword'].height;
 ps_weapon_width=document.images['god_sword'].width;
}
if ("$Vs_W[0]" == "�Ҥ������`�ӼC")
{
 vs_weapon_type_img="vs_god_sword";
 vs_weapon_height=document.images['god_sword'].height;
 vs_weapon_width=document.images['god_sword'].width;
}


if  (actiondown==0)
{
if ("$Pl_MsnStyle" == "���q����")
{
 ps_speed_x=30;
 vs_speed_x=30;
 attacktimes=6;
 light_type="dieflash";
}

if ("$Pl_MsnStyle" == "����")
{
 ps_speed_x=70;
 vs_speed_x=10;
 attacktimes=2;
 light_type="attacklight";
}

if ("$Pl_MsnStyle" == "���m")
{
 ps_speed_x=10;
 vs_speed_x=40;
 attacktimes=3;
 light_type="attacklight";
 fliph_object(light_type);
}


if ("$Pl_MsnStyle" == "���u����")
{
 ps_speed_x=20;
 vs_speed_x=40;
 attacktimes=6;
 light_type="attacklight";
 fliph_object(light_type);
}



if ("$Pl_MsnStyle" == "����")
 {
 ps_speed_x=150;
 vs_speed_x=10;
 attacktimes=2;
 light_type="attacklight";
 }

if ("$Pl_MsnStyle" == "�{��")
{
 ps_speed_x=300;
 vs_speed_x=40;
 attacktimes=4;
 light_type="attacklight";
 fliph_object(light_type);
}


if ("$Pl_MsnStyle" == "����")
 {
 ps_weapon_height=document.images['god_sword'].height;
 ps_weapon_width=document.images['god_sword'].width;
 ps_weapon_type_img = "ps_god_sword";
 ps_speed_x=30;
 vs_speed_x=30;
 attacktimes=6;
 light_type="attacklight";
 }



ps_x=ps_x+ps_speed_x;
vs_x=vs_x-vs_speed_x;


if (ps_x > vs_x)
{
 ps_x=ps_x-(ps_speed_x+ps_backtime);
 vs_x=vs_x+(vs_speed_x+vs_backtime);
 IsHit=1;
}


//=SHOW WEAPON ATTACK

 vs_flash_x=((vs_x+vs_x)/2)-(flash_width/2)+50;
 vs_flash_y=((vs_y+vs_y)/2);


//==PS WEAPON 

 if (ps_weapon_type_img == "ps_weapon_a")
 {
  ps_weapon_x=ps_x+flash_width-20;
  ps_weapon_y=ps_y+vs_weapon_height+20;
 } 	

 if (ps_weapon_type_img == "ps_god_sword")
 {
  ps_weapon_x=ps_x+ps_weapon_width-20;
  ps_weapon_y=ps_y;
 } 	

//====VS WEAPON

 if (vs_weapon_type_img == "vs_weapon_a")
 {
  vs_weapon_x=vs_x-vs_weapon_width+20;
  vs_weapon_y=vs_y+vs_weapon_height+20;
 } 	
 if (vs_weapon_type_img == "vs_god_sword")
 {
  vs_weapon_x=vs_x-vs_weapon_width+20;
  vs_weapon_y=vs_y;
 } 	

//=SHOW WEAPON ATTACK=END=====

gobal_fun_moveto('psbody',ps_x,ps_y);
gobal_fun_moveto('vsbody',vs_x,vs_y);
gobal_fun_moveto(ps_weapon_type_img,ps_weapon_x,ps_weapon_y);
gobal_fun_moveto(vs_weapon_type_img,vs_weapon_x,vs_weapon_y);

}


if ((IsHit == 1) && (fcount < attacktimes) && (actiondown==0))
{
 fcount++;
 timespeed=500;

 flash_x=((ps_x+vs_x)/2)-(flash_width/2)+50;
 flash_y=((ps_y+vs_y)/2);
 
 if (($ps_die == 1 ) || ($vs_die == 1 ))
 {
 
  dieflash_x =flash_x;
  dieflash_y =flash_y;

if ("$Pl_MsnStyle" == "���q����")
{
  dieflash_x =flash_x;
  dieflash_y =flash_y;
  PlaySound("boom",boom1_sound); 	
}
if ("$Pl_MsnStyle" == "����")
 {
  dieflash_x =flash_x-100;
  dieflash_y =flash_y-20;
  PlaySound("boom",boom2_sound); 	

 }

if ("$Pl_MsnStyle" == "���m")
 {
  dieflash_x =flash_x-30;
  dieflash_y =flash_y-20;
  PlaySound("boom",boom2_sound); 	

  }

if ("$Pl_MsnStyle" == "���u����")
 {
  dieflash_x =flash_x-30;
  dieflash_y =flash_y-20;
  PlaySound("boom",boom2_sound); 	

  }

if ("$Pl_MsnStyle" == "����")
 {
  dieflash_x =flash_x-100;
  dieflash_y =flash_y-20;
  PlaySound("boom",boom2_sound); 	

  }

if ("$Pl_MsnStyle" == "�{��")
 {
  dieflash_x =flash_x-30;
  dieflash_y =flash_y-20;
  hidden_object('psbody');
  PlaySound("boom",boom3_sound); 	

  }

if ("$Pl_MsnStyle" == "����")
 {
   dieflash_x =flash_x-100;
   dieflash_y =flash_y-20;
   PlaySound("boom",boom4_sound); 	

 }
  
  if (actiondown==0 ) 
  {
   	gobal_fun_moveto(light_type,dieflash_x,dieflash_y);
   
	if ((attacktimes-fcount)<2  )
	{
  	dieword_size();
  	gobal_fun_moveto('dieword',flash_x-(diefontsize/2)-40,flash_y-20);
	}  
   
  }
  
 }

}	

if (fcount >= attacktimes)
{
 ps_x=ps_x_org;
 vs_x=vs_x_org;
 hidden_object(ps_weapon_type_img);
 hidden_object(vs_weapon_type_img);
 actiondown=1 ;
}	


if (actiondown== 1)
{

 if ($ps_die == 1 )
 {

if (sound_switch ==1)
 	{
	PlaySound("ko",ko_sound);
}
  	ps_x=ps_x_org;
  	vs_x=vs_x_org;

  
  	hidden_object("psbody");
  	gobal_fun_moveto('diebody',ps_x,ps_y);
 }	


 if ($vs_die == 1)
 {
 	if (sound_switch ==1)
 	{
         PlaySound("ko",ko_sound); 	
         }
 
 	ps_x=ps_x_org;
 	vs_x=vs_x_org;
 	hidden_object("vsbody");
 	gobal_fun_moveto('diebody',vs_x,vs_y);
 }	

gobal_fun_moveto('vsbody',vs_x,vs_y);
gobal_fun_moveto('psbody',ps_x,ps_y);

document.bgColor="000000";

hidden_object(light_type);
hidden_object(ps_weapon_type_img);
hidden_object(vs_weapon_type_img);
hidden_object("dieword");
//AutoFreshFrame();
}
setTimeout('fighter()',timespeed);
}

if (sound_switch ==1){PlaySound("backbg",fightbg1_sound);}
fighter();

//-->
</script>         


	-----END-----
		

		

#======== SHOW HP IN FIGHT==============

print << "	-----END-----";
<table border="1" width="100%" cellspacing="0" cellpadding="0">
<tr>
<td width="48%" valign="top">�@
<table border="0" cellspacing="0" cellpadding="0">
<td>HP $PL_HPTAG</td><td width=50 align=right style="font-size:14px;">
<span id=cplhp>$Pl_BfrHP</span></td><td style="font-size:14px;">/<b>$PL_VALUES[16]</b></td>
<img src="$IMG_FOLDER3/$PL_VALUES[100].gif" align="left">$Pl_MsnStyle ($PL_Country $PL_VALUES[3])<br>  
$FORM{'pname'} $Pl_Kaikyu��$PL_VALUES[31]<br><br><br>EN<SPAN style=BORDER-RIGHT: medium none; BORDER-TOP: medium none; FONT-SIZE: 16px; BORDER-LEFT: #23a012 1px solid; BORDER-BOTTOM: #23a012 1px solid; BACKGROUND-COLOR: #000000>
<b id=j_en>$PL_VALUES[17]</b>/<B>$PL_VALUES[18]</B></SPAN></TD>

</table>    
   
</td>

<td width="4%" valign="top" >�@
<form action=$MAIN_SCRIPT name='FM1' method='POST' target=Sub>
<center>
<input type=hidden name=cmd>
<input type=hidden name=pname value=$FORM{'pname'}>
<input type=hidden name=pass value=$FORM{'pass'}>

<input type=submit name='b_mode' value='�԰�' $STYLE_B1 onClick="document.FM1.cmd.value='BATTLE_1'">

</center>
</form>

<form action=$MAIN_SCRIPT method=POST target=Main>
<center>
<input type=hidden name=cmd value=MAIN_FRAME>
<input type=hidden name=pname value=$FORM{'pname'}>
<input type=hidden name=pass value=$FORM{'pass'}>
<input value="��s" $STYLE_B1 type=submit>
</center>
</form>

</td>

<td width="48%" valign="top">�@
<table border="0" cellspacing="0" cellpadding="0">
<td> HP $VS_HPTAG</td><td width=50 align=right style="font-size:14px;">
<span id=cvshp>$Vs_BfrHP</span></td><td style="font-size:14px;">/<b>$VS_VALUES[16]</b></td>    
<img src="$IMG_FOLDER3/$VS_VALUES[100].gif" align="left">$Vs_MsnStyle ($VS_Country $VS_VALUES[3])<br>$FORM{'vsname'}$Vs_Kaikyu��$VS_VALUES[31]<br>
<br><br>EN<SPAN style=BORDER-RIGHT: medium none; BORDER-TOP: medium none; FONT-SIZE: 16px; BORDER-LEFT: #23a012 1px solid; BORDER-BOTTOM: #23a012 1px solid; BACKGROUND-COLOR: #000000>
<b id=j_en>$VS_VALUES[17]</b>/<B>$VS_VALUES[18]</B></SPAN></TD>
</table>    
</td>
</tr>
</table>


<br><br><br><br><br><br><br><br><br><br><br><br><br>


	-----END-----

	
print << "	-----END-----";
<script language="JavaScript">
timeID=10;
cdplhp=Math.round(($Pl_BfrHP-$PL_VALUES[15])*0.1);
cdvshp=Math.round(($Vs_BfrHP-$VS_VALUES[15])*0.1);
flaga=flagb=flagc=0;
setTimeout(\"HEcount()\",2500);
function HEcount()
	{
	cplhp.innerText-=cdplhp;
	cvshp.innerText-=cdvshp;
	if (eval(cplhp.innerText) <= $PL_VALUES[15]){cplhp.innerText='$PL_VALUES[15]';flaga=1;}
	if (eval(cvshp.innerText) <= $VS_VALUES[15]){cvshp.innerText='$VS_VALUES[15]';flagb=1;}
	clearTimeout(timeID);
	if (!flaga || !flagb){timeID = setTimeout(\"HEcount()\",1);}
	}
</script>
	-----END-----
	

$ResultAfterFight="";
$Ch_rank=&RANK($PL_VALUES[0],$PL_VALUES[5],$PL_VALUES[6]);
if($Ch_rank ne $Pl_Kaikyu && $Ch_rank)
  {
   $ResultAfterFight.="$FORM{'pname'}�դU$Ch_rank�ܧ�";
   if ($PL_In[1] > 0) {$ResultAfterFight.="�ɮ�";}
   if ($PL_In[1] < 0) {$ResultAfterFight.="����";}
  }

$Ch_rank=&RANK($VS_VALUES[0],$VS_VALUES[5],$VS_VALUES[6]);
if($Ch_rank ne $Vs_Kaikyu && $Ch_rank)
	{
	$ResultAfterFight.="$FORM{'vsname'}�դU$Ch_rank�ܧ�";
	if ($VS_In[1] > 0) {$ResultAfterFight.="�ɮ�";}
   	if ($VS_In[1] < 0) {$ResultAfterFight.="����";}
	}

$PL_In[4]=$PL_In[0]*($VS_VALUES[0]+1);
$PL_Ln[8] *= 2 if $Pl_W[7] == 8;
$PL_In[4] *= 2 if $Pl_W[7] == 8;
$PL_In[0] *= 2 if $Pl_W[7] == 8;
	
$PL_In[4] *= 2 if $Pl_W[7] == 25;


$Pl_GetExp=int($PL_In[4]*0.8);
$St_GetExp=int($PL_In[4]*0.2);
$GetStSign=0;
if(length(@PL_VALUES[81]>100)){@PL_VALUES[76]=101;}

if (@PL_VALUES[79] ne "")
{
@ST_VALUES = split(/\s/,$P{"@PL_VALUES[79]"});
if((LOGIN_CHECK(@PL_VALUES[79])) &&(@ST_VALUES[78] eq $FORM{'pname'}))
{
if(@PL_VALUES[80] eq @ST_VALUES[80])
{
@PL_VALUES[81].="!�ϥάۦPIP�a�{��$Ipaddress";
$ResultAfterFight.="...�H�W�a�{��...";
}
else
{
@ST_VALUES[30]+=$St_GetExp;
$GetStSign=1;
}	
}	
}

if ($GetStSign == 1){$PlGetExp=$Pl_GetExp+$St_GetExp;}else{$PlGetExp=$Pl_GetExp;}

$PL_VALUES[30]+=$PlGetExp;


if ($Pl_W[7] == 27){$PL_In[0]=0;}
if ($Vs_W[7] == 27){$VS_In[0]=0;}

if ($GetStSign == 1)
{
$ResultAfterFight.="$FORM{'pname'} �դU�o��F $PlGetExp���g�� @PL_VALUES[79] �o�� $St_GetExp �g�� $PL_In[2] ������ $PL_In[0] ���Z���g�� �ĤH�o��$VS_In[0] ���Z���g��<br>";
}
else
{
$ResultAfterFight.="$FORM{'pname'} �դU�o��F $PlGetExp���g�� $PL_In[2] ������ $PL_In[0] ���Z���g�� �ĤH�o��$VS_In[0] ���Z���g��<br>";
}	


if (($PL_VALUES[29]+1)*200 <= $PL_VALUES[30]){
$ResultAfterFight.="<font color=#f7e957>$FORM{'pname'} �դU ���ŤW��</font><br>";
$PL_VALUES[30]=0;
$PL_VALUES[29]++;




sub BONUS{$ResultAfterFight.=" $_[0]��O�����F";}

$C=$PL_VALUES[23];$C=100 if $C > 100;

if ($Pl_W[7] == 21)
{
$$AT*=1.5;
}	
if ($Pl_W[7] == 22)
{
$$DE*=1.5;
}	
if ($Pl_W[7] == 23)
{
$$SP*=4
}	
if ($Pl_W[7] == 24)
{
$$WM*=1.5;
}	


GetAllMaxAttr();
#print "$StatusMax $AttStatusMax $ProStatusMax $SpdStatusMax $HitStatusMax";


if ($PL_VALUES[4] == 1){$BoAt=20;}
elsif ($PL_VALUES[4] == 2){$BoDe=20;}
elsif ($PL_VALUES[4] == 3){$BoSp=20;}
elsif ($PL_VALUES[4] == 4){$BoAg=20;}
elsif ($PL_VALUES[4] == 5){$BoHp=20;}
elsif ($PL_VALUES[4] == 6){$BoEn=20;}
elsif ($PL_VALUES[4] == 0){$BoAt=$BoSp=$BoDe=$BoAg=$BoHp=$BoEn=12;}

if (rand(22) < $BoAt && $PL_VALUES[19] < $AttStatusMax){print &BONUS('�����O');$PL_VALUES[19]++;}
if (rand(22) < $BoDe && $PL_VALUES[20] < $ProStatusMax){print &BONUS('���m�O');$PL_VALUES[20]++;}
if (rand(22) < $BoSp && $PL_VALUES[21] < $SpdStatusMax){print &BONUS('�F�ӫ�');$PL_VALUES[21]++;}
if (rand(22) < $BoAg && $PL_VALUES[22] < $HitStatusMax){print &BONUS('�R���O');$PL_VALUES[22]++;}
if (rand(22) < $BoHp && $PL_VALUES[16] < $MAX_HP){print &BONUS('HP');$PL_VALUES[16]++;}
if (rand(22) < $BoEn && $PL_VALUES[18] < $MAX_EN){print &BONUS('EN');$PL_VALUES[18]++;}
}




	

	if ($ResultBattle==1)  
	{
		sub DOWN{$ResultAfterFight.="����l�a $_[0]��O�U��";}
		$Event=int(rand(200));

		if ($Event == 12 && $PL_VALUES[19] >= 1){print &DOWN('�����O');$PL_VALUES[19]--;$BodyharmInfo="$FORM{'pname'}����l�a �����O��O�U��";}
		if ($Event == 13 && $PL_VALUES[20] >= 1){print &DOWN('���m�O');$PL_VALUES[20]--;$BodyharmInfo="$FORM{'pname'}����l�a ���m�O��O�U��";}
		if ($Event == 14 && $PL_VALUES[21] >= 1){print &DOWN('�ӱ���');$PL_VALUES[21]--;$BodyharmInfo="$FORM{'pname'}����l�a �ӱ��ׯ�O�U��";}
		if ($Event == 15 && $PL_VALUES[22] >= 1){print &DOWN('�R���O');$PL_VALUES[22]--;$BodyharmInfo="$FORM{'pname'}����l�a �R���O��O�U��";}
		if ($Event == 20 && $PL_VALUES[16] >= 5000){print &DOWN('HP');$PL_VALUES[16]=int($PL_VALUES[16]*0.995);}
		if ($Event == 40 && $PL_VALUES[18] >= 100){print &DOWN('EN');$PL_VALUES[18]=int($PL_VALUES[18]*0.995);}

		if ($Pl_W[7] eq 27)
		{
		sub RepDOWN
		{
		 $ResultAfterFight.="����׮� $_[0]��O�^�_";
		 @GetAnsPL=split(/!/,$PL_VALUES[9]);
		 @GetAnsPL[1]--;
		 $PL_VALUES[9]="@GetAnsPL[0]!@GetAnsPL[1]!@GetAnsPL[2]";
		 $ResultTag.=".�A����W�˳Ʒl���@�I!";
		}

		if ($Event == 12 ){&RepDOWN('�����O');$PL_VALUES[19]++;$BodyharmInfo="$FORM{'pname'}����׮� �����O��O�^�_";}
		if ($Event == 13 ){&RepDOWN('���m�O');$PL_VALUES[20]++;$BodyharmInfo="$FORM{'pname'}����׮� ���m�O��O�^�_";}
		if ($Event == 14 ){&RepDOWN('�ӱ���');$PL_VALUES[21]++;$BodyharmInfo="$FORM{'pname'}����׮� �ӱ��ׯ�O�^�_";}
		if ($Event == 15 ){&RepDOWN('�R���O');$PL_VALUES[22]++;$BodyharmInfo="$FORM{'pname'}����׮� �R���O��O�^�_";}
		}
                
	}

	if (rand(100) <= $GET_WEAPON  && !$ResultBattle && (!$PL_VALUES[10] || !$PL_VALUES[11])){
		my@al=keys %WEAPON_LIST;$alw=@al;
		$alw=int rand($alw);$gw=@al[$alw];$gw='a' if !$gw;
			@q=split(/\,/,$WEAPON_LIST{"$gw"});
		if ($q[5] == 0){
		 if (!$PL_VALUES[10]){$PL_VALUES[10]=$gw;}
		elsif(!$PL_VALUES[11]){$PL_VALUES[11]=$gw;}
		elsif(!$PL_VALUES[98]){$PL_VALUES[98]=$gw;}
		elsif(!$PL_VALUES[99]){$PL_VALUES[99]=$gw;}
		$ResultAfterFight.="�Z����o";
		}
	}


	if ($PL_VALUES[12] == 6 && $FORM{'mode'} !=1 && rand(255) > 200){$PL_VALUES[12]="$VS_VALUES[12]";}
	elsif($PL_VALUES[12] != 6 && $FORM{'mode'} ==1 && rand(255) > 253){$PL_VALUES[12]='6';}
	elsif($PL_VALUES[12] != 6 && $FORM{'mode'} ==1){$qiang=rand(255);$PL_VALUES[12]='6' if $qiang=250;$PL_VALUES[12]='7' if $qiang=255;$PL_VALUES[12]='8'; }
	elsif($PL_VALUES[12] != 6 && $FORM{'mode'} ==1){$qiang=rand(255);$PL_VALUES[12]='6' if $qiang=8;$PL_VALUES[12]='7' if $qiang=4;$PL_VALUES[12]='8' if $qiang=2;}
	$Pl_Drain = 0;$Vs_Drain = 0;
if ($Pl_W[7] == 14 && rand(100) > 80){
$ResultAfterFight.="�@�}���~��$VS_VALUES[3]���ͩR�O�Q�l���F�C";
if($PL_VALUES[16] > $VS_VALUES[15]){
$Pl_Drain = int(rand($VS_VALUES[15]*0.3));
}else{
$Pl_Drain = int(rand($PS_VALUES[16]*0.3));
}
$VS_VALUES[15]-=$Pl_Drain;
$PL_VALUES[15]+=$Pl_Drain;
}
if ($Vs_W[7] == 14 && rand(100) > 80){
$ResultAfterFight.="�@�}���~��$PL_VALUES[3]���ͩR�O�Q�l���F�C";
if($VS_VALUES[16] > $PL_VALUES[15]){
$Vs_Drain = int(rand($PL_VALUES[15]*0.3));
}else{
$Vs_Drain = int(rand($VS_VALUES[16]*0.3));
}
$PL_VALUES[15]-=$Vs_Drain;
$VS_VALUES[15]+=$Vs_Drain;
}




	if ($Pl_W[7] == 1)
	{
	if (($Vs_W[7] == 10) || ($Vs_W[7] == 17) || ($Vs_W[7] == 27) || ($Vs_W[7] == 156))
	{
	@GetAnsVS=split(/!/,$VS_VALUES[9]);
	my $LostPoint=int rand($WEAPON_LVUP/7)+10;
	@GetAnsVS[1]-=$LostPoint;
	$VS_VALUES[9]="@GetAnsVS[0]!@GetAnsVS[1]!@GetAnsVS[2]";
	$ResultTag.=".�ĤH��W�˳Ʀ]��׹���z�Z�ӷl��$LostPoint�I!";
	if ((@GetAnsVS[1] < 0) && (int rand(30)>25))
	   {
	    @GetOVSAns=split(/!/,$VS_VALUES[9]);
	    @GetOVSWepInfo=split(/\,/,$WEAPON_LIST{"@GetOVSAns[0]"});

	    $ResultTag.=".�ĤH��W�˳Ʀ]��׹���z�Z���z���F!";
	    WriteSNGMsg("GM01����:$FORM{'vsname'}��W�˳� @GetOVSWepInfo[0] �]���$FORM{'pname'}�z�Z���z���F.. ");
	    $VS_VALUES[9]="";
	   }
	}
	else
	{
		if (rand(255) > 240){$ResultAfterFight.="�ľ������t�ί}�a";$VS_VALUES[19]--;$BodyharmInfo=$BodyharmInfo."$FORM{'vsname'}�����t�ί}�a";}
		if (rand(255) > 240){$ResultAfterFight.="�ľ����m�t�ί}�a";$VS_VALUES[20]--;$BodyharmInfo=$BodyharmInfo."$FORM{'vsname'}���m�t�ί}�a";}
		if (rand(255) > 240){$ResultAfterFight.="�ľ��^�רt�ί}�a";$VS_VALUES[21]--;$BodyharmInfo=$BodyharmInfo."$FORM{'vsname'}�^�רt�ί}�a";}
		if (rand(255) > 240){$ResultAfterFight.="�ľ��R���t�ί}�a";$VS_VALUES[22]--;$BodyharmInfo=$BodyharmInfo."$FORM{'vsname'}�R���t�ί}�a";}
	}
	}







#if ($Pl_W[7] == 15 && $ResultBattle!=0){
#$ResultAfterFight.=" $PL_VALUES[3]�����z�˸m�Ұ�";$PL_VALUES[25]=1;}
#if ($Vs_W[7] == 15 && $ResultBattle!=0){
#$ResultAfterFight.=" $VS_VALUES[3]�����z�˸m�Ұ�";$PL_VALUES[25]=1;}
#if ($Pl_W[7] == 15 && $ResultBattle!=0){$VS_VALUES[15]-=$PL_VALUES[15];}
#if ($Vs_W[7] == 15 && $ResultBattle!=0){$VS_VALUES[15]-=$PL_VALUES[15];}
#if ($Pl_W[7] == 15 && $ResultBattle!=0){$PL_VALUES[15]=1;}
#if ($Vs_W[7] == 15 && $ResultBattle!=0){$PL_VALUES[15]=1;}
#if ($Pl_W[7] == 15 && 0 > $VS_VALUES[15]){$ResultAfterFight.=" $VS_VALUES[3]�Q���J�z����!!";$VS_VALUES[25]=1;}
#if ($Vs_W[7] == 15 && 0 > $VS_VALUES[15]){$ResultAfterFight.=" $VS_VALUES[3]�Q���J�z����!!";$VS_VALUES[25]=1;}
#if ($Pl_W[7] == 15 && 0 > $VS_VALUES[15]){$VS_VALUES[15]=1;}
#if ($Vs_W[7] == 15 && 0 > $VS_VALUES[15]){$VS_VALUES[15]=1;}
}


	if ($Pl_W[7] == 2 && rand(255) > 240){$ResultAfterFight.=" $VS_VALUES[3]�԰�����";$VS_VALUES[25]=1;}
	if ($Vs_W[7] == 2 && rand(255) > 240){$ResultAfterFight.=" $PL_VALUES[3]�԰�����";$VS_VALUES[25]=1;}

	$WLDUMMYpl=$PL_WLV;$PL_WLV+=$PL_In[0] if $PL_WLV < $MAX_WEAPONLV*100;
	$WLDUMMYvs=$VS_WLV;$VS_WLV+=$VS_In[0] if $VS_WLV < $MAX_WEAPONLV*100;
	$PL_WLV=$MAX_WEAPONLV*100 if $PL_WLV > $MAX_WEAPONLV*100;
	$VS_WLV=$MAX_WEAPONLV*100 if $VS_WLV > $MAX_WEAPONLV*100;

	if(int($PL_WLV/$WEAPON_LVUP) > int($WLDUMMYpl/$WEAPON_LVUP) && $PL_WLV < $MAX_WEAPONLV*100){
		$ResultAfterFight.=" $FORM{'pname'}��$Pl_W[0]���Ŵ��ɤF";
		$PL_VALUES[14]=$PL_VALUES[14]-$WEAPON_LVUP;
	}
	if(int($VS_WLV/$WEAPON_LVUP) > int($WLDUMMYvs/$WEAPON_LVUP) && $VS_WLV < $MAX_WEAPONLV*100){
		$ResultAfterFight.=" $FORM{'vsname'}��$Vs_W[0]���Ŵ��ɤF";
		$VS_VALUES[14]=$VS_VALUES[14]-$WEAPON_LVUP;
	}
		$PL_VALUES[9]="$PL_WN!$PL_WLV!$PEX_sA[1]";###�Z����y�s�W
		$VS_VALUES[9]="$VS_WN!$VS_WLV!$VEX_sA[1]";###�Z����y�s�W�s
		if($PL_VALUES[41] && rand(50)>38){ 
if ($PL_BGT>1){$TAI_p=$PL_BGT-=1;$PL_VALUES[41]="$PL_BG!$TAI_p"; 
}else{$ResultAfterFight.="���U�˳ƳQ�}�a�F�I";$PL_VALUES[41]="";} 
} 
if($VS_VALUES[41] && rand(50)>38){ 
if ($VS_BGT>1){$TAI_v=$VS_BGT-=1;$VS_VALUES[41]="$VS_BG!$TAI_v"; 
}else{$ResultAfterFight.="���U�˳ƳQ�}�a�F�I";$VS_VALUES[41]="";} 
} 


	$TheEnd=1 if $FORM{'yousai'} && !$ResultBattle;
	
	$ProtectMaskDays=((time)-$VC_VALUES[19])/(24*60*60);
	@CountryData1=split(/!/,$VC_VALUES[12]);
	if ($ProtectMaskDays >=7 ){$VC_VALUES[16] = 0; }
	#WriteSNGMsg("GM01����: @CountryData1[3] ���@�n�۰ʨ��@�ѼƤw��!");
	if (($Pl_AtPoint > $VS_VALUES[15]) && ($VC_VALUES[16]>=1))
	{
	 $VS_VALUES[15]+=$Pl_AtPoint;$VC_VALUES[16]--;$ResultAfterFight.="�n�먾�@�n�ٯ���$VC_VALUES[16]������! ";
	 $TheEnd=0;
	 $PlWin=1;
	 #$ResultBattle=3;
	 }
	
	
        $VC_VALUES[11]="$VS_VALUES[15]!$Y_HP[1]!$DATE" if $FORM{'yousai'};	
	if(!$ResultBattle && $PL_VALUES[5]){$CL_VALUES[1]+=$VS_VALUES[0]+20;$CL_VALUES[1]+=5000 if $TheEnd==1;}
	elsif($ResultBattle && $PL_VALUES[5]){$CL_VALUES[1]+=int(($VS_VALUES[0]+20)/3);}
	$CL_VALUES[1]+=$VS_VALUES[0]+20;
	if ($TheEnd eq 1 ){$CL_VALUES[1]+=$VC_VALUES[1];}
	$CL_VALUES[1]=$MaxCountryMoney if $CL_VALUES[1] > $MaxCountryMoney;
        

$PL_VALUES[32]++;




@GetPLAns=split(/!/,$PL_VALUES[11]);
@GetVSAns=split(/!/,$VS_VALUES[11]);

if (@GetVSAns[0] eq 'wya0004')
{
if (($Pl_AtPoint > $VS_VALUES[15]) && (@GetVSAns[1]>0))
{
@GetVSAns[1]--;
$VS_VALUES[11]="@GetVSAns[0]!@GetVSAns[1]!@GetVSAns[2]";
$Pl_AtPoint=0;
$VS_VALUES[25]=0;
$ResultBattle= 1;
$ResultTag.=".�ĤH���W�˳Ƶo�ͧ@��!..�ƸѧA�������O!���˳��٥i�� @GetVSAns[1] ��!";
if (@GetVSAns[1]<=0)
{
 $VS_VALUES[11]="6!@GetVSAns[1]!@GetVSAns[2]";
 $ResultTag.=".�ĤH���W�˳Ƥw�����o�K!";
}
}	
}

if (@GetPLAns[0] eq 'wya0004')
{

if ((($Vs_AtPoint > $PL_VALUES[15]) && (@GetPLAns[1]>0)) || (($PL_VALUES[25] == 1) || ($ResultBattle > 0)))
{
@GetPLAns[1]--;
$PL_VALUES[11]="@GetPLAns[0]!@GetPLAns[1]!@GetPLAns[2]";
$Vs_AtPoint=0;
$PL_VALUES[25]=0;
$ResultBattle= 0;

$ResultTag.=".�A���W�˳Ƶo�ͧ@��!..�Ƹѹ�誺�����O! ���˳��٥i�� @GetPLAns[1] ��!";
if (@GetPLAns[1]<=0)
{
 $PL_VALUES[11]="6!@GetPLAns[1]!@GetPLAns[2]";
 $ResultTag.=".�ĤH���W�˳Ƥw�����o�K!";
}

}	
}

#========================NPC �p�� =======================
if($FORM{'vsname'} eq '�ӪŮ��s')
{
if (($Pl_AtPoint > $VS_VALUES[15]) && ($VS_VALUES[15] > 1000))
{
 $Pl_AtPoint=int($VS_VALUES[15]/50);
 $ResultTag.="$FORM{'vsname'} �ϥΨ��@�n����j����������! ";
 WriteSNGMsg("GM01����:$VS_VALUES[15] HP��$FORM{'vsname'} �ϥΨ��@�n����j����$FORM{'pname'}������! ");
}

if ($ResultBattle eq 0)
{
 
 if ($Pl_W[7] == 15)
 {
 $Boom_p="�Φ��z ";
 $Bouns=0;
 } 	
 else
 {
 $Bouns=int(rand(100000)+30000);
 $PL_VALUES[8]+=$Bouns;
 $Boom_p="";
 }
 $SpecialReport="$FORM{'pname'} $Boom_p���� $FORM{'vsname'} ��o$Bouns��! ";
 $ResultTag.=$SpecialReport;
 WriteSNGMsg("GM01����:$SpecialReport ");
}

}	
#===============================================


 @spwn11ID=split(/!/,$VS_VALUES[11]);
 @spwn11=split(/\,/,$WEAPON_LIST{@spwn11ID[0]});

if ($ResultBattle eq 0)
{
 if ((@spwn11ID[0] eq "wya0004")&&(@spwn11ID[1] > 0))
 {
  $VS_VALUES[25]=0;
  $ResultBattle= 1;
  $ResultTag.="�ĤH���@�n���Ұʵd���˸m...�Ϩ��٦��@����O�԰�<br>";  
  WriteSNGMsg("GM01����:$FORM{'pname'}���@����$FORM{'vsname'}���@�n���Ұʵd���˸m�~��԰�.��@spwn11ID[1]�����@");
 } 	
}






if ($ResultBattle eq 0)
{
($WN_ID,$tt,$tt2) = split(/!/,$VS_VALUES[9]);
($PLWN_ID,$pltt,$pltt2) = split(/!/,$PL_VALUES[9]);

if ($WN_ID eq "wxa0001")
{
$VS_VALUES[15]=$VS_VALUES[16];
$VS_VALUES[25]=0;
$ResultBattle= 1;
$ResultTag.="�ĤH�ϥζ¬}����(�K�X�Z)�Ӻ�����...��O����<br>";
}


if ($VS_VALUES[77] == 1)
{


if ($PLWN_ID ne "whb0001")
{
$TakeHp=abs ($PL_VALUES[15]);
$VS_VALUES[15]=$TakeHp;
$PL_VALUES[15]-=$TakeHp;
$VS_VALUES[25]=0;
$ResultBattle= 1;
$PL_VALUES[25]=1;
$ResultTag.="�ĤH�ϥ� �ۤv�������˳�..�l���A���ͩR�O $TakeHp...�_��..��O�^�_<br>";
}
else
{
 
 @spwnID=split(/!/,$VS_VALUES[99]);
 @spwn=split(/\,/,$WEAPON_LIST{@spwnID[0]});

if ($WN_ID eq "wya0001")
{
$PL_VALUES[10] = $VS_VALUES[99];
}
else
{
$PL_VALUES[11] = $VS_VALUES[99];
}

$VS_VALUES[9]="die!0!";
$ResultTag.="�ĤH�e�A @spwn[0] ..<br>";

$AttackTime=localtime(time);
 
$tasvaluemsg="GM01����: �b�@�f�E������ $FORM{'pname'}���ѤF$FORM{'vsname'} �è��o���䪺�Z�� @spwn[0]";
WriteSNGMsg("$tasvaluemsg"); 
 
 
}


}
}


if (($VS_VALUES[15] < 1) || ($PlWin eq 1)){$PL_VALUES[33]++;}

	if ($FORM{'b_mode'} eq '����' || $FORM{'b_mode'} eq "�`�R"){print "$FORM{'b_mode'}$B_Com";}

	&LOCK;

if ($PLWeaponDemage eq 1)
{
@GetAns=split(/!/,$PL_VALUES[9]);
@GetAns[1]-=$WEAPON_LVUP;
@PL_VALUES[9]="@GetAns[0]!@GetAns[1]!@GetAns[2]";
}
@PL_VALUES[80]="$Ipaddress";

$KillVSCounter=0;
if ($VS_VALUES[19] < 0){$KillVSCounter++;}
if ($VS_VALUES[20] < 0){$KillVSCounter++;}
if ($VS_VALUES[21] < 0){$KillVSCounter++;}
if ($VS_VALUES[22] < 0){$KillVSCounter++;}

$FinalFightTime=(time)-@VS_VALUES[26];
$FinalFightDay=int($FinalFightTime/(24*60*60));

if ($PlWin eq 1){$VS_VALUES[25] = 1;$VS_VALUES[15] = 0;}




#====================================================
@GetAns=split(/!/,$PL_VALUES[9]);
@GetAnsVS=split(/!/,$VS_VALUES[9]);

if ((@GetAns[0] eq "") || (@GetAns[1] eq ""))
{
$PL_VALUES[9]='7!1';
}

if ((@GetAnsVS[0] eq "") || (@GetAnsVS[1] eq ""))
{
$VS_VALUES[9]='7!1';
}


if ($VS_VALUES[77] == 1) 
{
if ($VSOrgiUPHP != $VS_VALUES[15])
{
 my $HitHP=$VSOrgiUPHP-$VS_VALUES[15];
 my $MaxHitLose = int ($VS_VALUES[16]/30);
 $tasvaluemsg="GM01����:$FORM{'pname'}�ϥX�j�O�@����$FORM{'vsname'} HP ��$HitHP, $FORM{'vsname'} HP ��HP:@VS_VALUES[15]";
 if ($HitHP > $MaxHitLose)
 {
  $VS_VALUES[15]+=$HitHP-$MaxHitLose;
  $tasvaluemsg="GM01����:$FORM{'pname'}�@���� $FORM{'vsname'} HP��$HitHP,��$FORM{'vsname'}���Ĥ��^�_HP��@VS_VALUES[15]";
  }
 
 WriteSNGMsg("$tasvaluemsg");
}

@GetVSAns=split(/!/,$VS_VALUES[11]);
if (($VSOrgiProtect != @GetVSAns[1]) && (@GetVSAns[0] eq 'wya0004'))
   {
   $tasvaluemsg="GM01����:$FORM{'pname'} �ϥX�j�O�@����$FORM{'vsname'}���@�n��@GetVSAns[1]";
   WriteSNGMsg("$tasvaluemsg");
   if (@GetVSAns[1] == 2)
      {
	$VS_VALUES[15]=$VS_VALUES[16];$VS_VALUES[25]=0;
       $tasvaluemsg="GM01����:$FORM{'vsname'}�D������! HP �ɨ�$VS_VALUES[15]";
       WriteSNGMsg("$tasvaluemsg");

	}      	
   }	

$RandHit=int rand(8);
if ($RandHit == 1)
{
   $LossRandHit=int rand(10000);
   @PL_VALUES[15]-=$LossRandHit;
   $tasvaluemsg="GM01����:$FORM{'vsname'}��ŧ�ˮ`$FORM{'pname'} $LossRandHit HP�Ϩ�HP��@PL_VALUES[15]";
   WriteSNGMsg("$tasvaluemsg");
}	

if ($RandHit == 2)
{
   $LossRandHit=int rand(10000)+10000;
   @PL_VALUES[15]-=$LossRandHit;
   $tasvaluemsg="GM01����:$FORM{'vsname'}�ϥΥl��N�I�s���F���ˮ`$FORM{'pname'} $LossRandHit HP�Ϩ�HP��@PL_VALUES[15]";
   WriteSNGMsg("$tasvaluemsg");
}	

if ($RandHit == 3)
{
   $LossRandHit=int rand(10000)+10000;
   if ((@VS_VALUES[15]-$LossRandHit) > 1 )
   {
   @VS_VALUES[15]-=$LossRandHit;
   $tasvaluemsg="GM01����:$FORM{'vsname'}�ϥΥl��N�I�s���F���Q�ˮ`$FORM{'pname'} �o�����˨�ۤv$LossRandHit HP��HP��@VS_VALUES[15]";
   WriteSNGMsg("$tasvaluemsg");
   }
}	

if ($RandHit == 4)
{
   $LossRandHit=int rand(100000)+int (@VS_VALUES[16]/30);
   @VS_VALUES[15]+=$LossRandHit;
   $tasvaluemsg="GM01����:$FORM{'vsname'}�ϥί��t���~..�ۧ����� �W�[$LossRandHit HP �Ϩ�W�[��@VS_VALUES[15]";
   WriteSNGMsg("$tasvaluemsg");
}	



}


if (rindex($FORM{'pname'},'-�X-') == -1 )
    {
     my @GetPLAns=split(/!/,$PL_VALUES[9]);
     if (@GetPLAns[0] eq 'wya0013')
        {
         $PL_VALUES[5]=$WaitDiePlace;
         $tasvaluemsg="GM01����:$FORM{'pname'}�ϥΫD�k�Z���Q���J $WaitDiePlace";
         WriteSNGMsg("$tasvaluemsg");
        }
    }

if ($PL_VALUES[95] eq ""){$PL_VALUES[95]=1;}
if ($PL_VALUES[96] eq ""){$PL_VALUES[96]=1;}
if ($VS_VALUES[95] eq ""){$VS_VALUES[95]=1;}
if ($VS_VALUES[96] eq ""){$VS_VALUES[96]=1;}

if ($VS_VALUES[95] > 140){$VS_VALUES[95]=140;}
if ($VS_VALUES[96] > 70){$VS_VALUES[96]=70;}


dbmopen (%PL,"$DBM_P",0666);

if ($NeedBackupDBM == 1)
{
if (! -e "$EventRecordDir/ebsbak$mday")
{
dbmopen (%FILEBACKUP,"$EventRecordDir/ebsbak$mday",0666);
%FILEBACKUP=%PL;
dbmclose %FILEBACKUP;
}
}

if ($GetStSign == 1){$PL{"@PL_VALUES[79]"}="@ST_VALUES";}
		$PL{"$FORM{'pname'}"}="@PL_VALUES";
		$PL{"$FORM{'vsname'}"}="@VS_VALUES" if !$FORM{'yousai'};

	if ((rindex($FORM{'pname'},'-�X-') ne -1 ) && $ResultBattle==1)
	{
	
	dbmopen (%DH,"$DBM_H",0666);$DH{"$DATE"}="<font color=\"blue\">$FORM{'pname'}�P$FORM{'vsname'}�@�ԥ���..�X��Q�}�a..�����F.</font>";dbmclose %DH;

	$SplitKey='-�X-';
	($MasterID,$CoMasterID)=split(/$SplitKey/,$FORM{'pname'});
	@MasterID_Values = split(/\s/,$PL{"$MasterID"});
	@CoMasterID_Values = split(/\s/,$PL{"$CoMasterID"});
	@MasterID_Values[5]='';
	@CoMasterID_Values[5]='';
	$PL{"$MasterID"}="@MasterID_Values";
	$PL{"$CoMasterID"}="@CoMasterID_Values";
	WriteSNGMsg("GM01����:$FORM{'pname'}����F $MasterID �M $CoMasterID �^��ۥѰ�!");
	delete $PL{"$FORM{'pname'}"};
	}

	
	if ($KillVSCounter >=2)
	{
	if ($DisableCountry{"$VS_VALUES[5]"} ne 1)
	{
	dbmopen (%DH,"$DBM_H",0666);$DH{"$DATE"}="<font color=\"blue\">$FORM{'pname'}�⦳$KillVSCounter����O���t�Ȫ� $FORM{'vsname'} �]�o�F..�ܮw�]�����F.</font>";dbmclose %DH;
	delete $PL{"$FORM{'vsname'}"};
	unlink "$StorageDir/".$FORM{'vsname'}.".dat";
	$ResultTag.=" ���H�w����!!^.^|| ";
	}
	}


	if (length($FORM{'vsname'}) > 50)
	{
	dbmopen (%DH,"$DBM_H",0666);$DH{"$DATE"}="<font color=\"blue\">$FORM{'pname'}�⦳�W�l�Ӫ��� $FORM{'vsname'} �]�o�F..�ܮw�]�����F.</font>";dbmclose %DH;
	delete $PL{"$FORM{'vsname'}"};
	unlink "$StorageDir/".$FORM{'vsname'}.".dat";
	$ResultTag.=" ���H�w����!!^.^|| ";
	}

	if ($VS_VALUES[77] == 3)
	{
        @CL_VALUES[1]+=$VS_VALUES[8];	


        dbmopen (%DH,"$DBM_H",0666);$DH{"$DATE"}="<font color=\"blue\">$FORM{'pname'}��$FORM{'vsname'} �]�o�F..$PL_Country�o���O$VS_VALUES[8].</font>";dbmclose %DH;
	$VS_VALUES[8]=0;
	delete $PL{"$FORM{'vsname'}"};
	$ResultTag.=" ���H�w����!!^.^|| ";
	}

	if ($IllID ne ""){delete $PL{"$IllID"};}

	

        if (((@VS_VALUES[32] <= $FinalFightDay) || (@VS_VALUES[32] eq "") ) && (@VS_VALUES[77] eq 0))
        {
	if ($FinalFightDay > 0)
	{
	if ($DisableCountry{"$VS_VALUES[5]"} ne 1)
	{
	if (@VS_VALUES[32] eq "") {@VS_VALUES[32] = 0;}
	dbmopen (%DH,"$DBM_H",0666);$DH{"$DATE"}="<font color=\"blue\">$FORM{'pname'}��$FinalFightDay�Ѥ��S�@�ԥB�ѵ��U���ثe�u����@VS_VALUES[32]���� $FORM{'vsname'} �]�o�F..�ܮw�]�����F.</font>";dbmclose %DH;
	delete $PL{"$FORM{'vsname'}"};
	unlink "$StorageDir/".$FORM{'vsname'}.".dat";
	$ResultTag.=" ���H�w����!!^.^|| ";
	}
	}
	}        	
        if ($CountryAutoAttackID ne ""){$PL{"$CountryAutoAttackID"}="@ALLVS_VALUES";}	
	dbmclose %PL;
	if (($FORM{'b_mode'} eq '����' && $B_Com && $PL_VALUES[6] == 1) || $TheEnd){
		 WriteSNGMsg("GM01�S�O����:$FORM{'pname'}�N..$VS_Country���z..��aì�o@VC_VALUES[1]��O ") if $TheEnd;
		dbmopen (%DH,"$DBM_H",0666);
			$DH{"$DATE"}="$PL_VALUES[5] �����z�o $FORM{'pname'} �x���F���������v$FORM{'vsname'}�U��$FORM{'pname'}���R" if $B_Com;
			$DH{"$DATE"}="$FORM{'vsname'}���ín�보��$VS_Country���` ��$FORM{'pname'} ���̫�@��" if $TheEnd;
		
		dbmclose %DH;
	}

	if ($PL_Country ne '�ۥѾԤh' && !$FORM{'b_mode'}){
		dbmopen (%CL,"$DBM_C",0666);
			$CL{"$PL_Country"}="@CL_VALUES" if $CL{"$PL_Country"} && $PL_Country ne '�ۥѾԤh';
			$CL{"$VS_Country"}="@VC_VALUES" if $FORM{'yousai'} && !$TheEnd;
			delete $CL {"$VS_Country"} if $CL{"$VS_Country"} && $TheEnd;
		dbmclose %CL;
	}
	&UNLOCK;


if(LOGIN_CHECK($FORM{'vsname'}))
{
$BodyharmInfo=$BodyharmInfo."�����ɤ�$FORM{'vsname'}";
}	

$CheckAbility=0;
if ($VS_VALUES[19] < 0 )
{
 $ResultTag.=" $FORM{'vsname'} �����O����! ";
 $CheckAbility++;
}	
if ($VS_VALUES[20] < 0 )
{
 $ResultTag.=" $FORM{'vsname'} ���@�O����! ";
 $CheckAbility++;
}	
if ($VS_VALUES[21] < 0 )
{
 $ResultTag.=" $FORM{'vsname'} �ثe�L�k����! ";
 $CheckAbility++;
}	


if ($CheckAbility >=3)
{
$CurrentCheckAbilityTime=localtime(time);
$ResultTag.=" $FORM{'vsname'} �ثe�w�g�L����@�ԯ�O! ($CurrentCheckAbilityTime)";
}	

if ($FightRecordSwitch eq 1)
{
&record_fight($FORM{'pname'},$FORM{'vsname'},"$ResultTag.�ثe��$PL_VALUES[8]G $BodyharmInfo");
}


if ($FightOnlyRecordSwitch eq 1)
{
 $CurrentTimeSecond=(time);
if ($local_test eq 0) {flock(FIGHTFILE,LOCK_EX)};
 open(FIGHTFILE,">>$FightOnlyRecordFile") || die $!;
 print FIGHTFILE "$CurrentTimeSecond $FORM{'pname'} �� $FORM{'vsname'} $Ipaddress $PL_VALUES[15] <br>\n";
 close(FIGHTFILE);
if ($local_test eq 0) {flock(FIGHTFILE,LOCK_UN)};

}	

 
print << "	-----END-----";
<div id=final_result_show style="position: absolute;visibility: visible; font-size=16px; z-index: 900; top:-1000; left:-1000;">
<table border="1" width="100%">
<tr>
<td width="100%">�@
$PL_Country��$FORM{'pname'}�r�p$PL_VALUES[3]����,��$Pl_WeaponNameA�ϥX$Pl_MsnStyle����$VS_VALUES[3] �α��෽:$Pl_W[4],$PlsumDmg<br>
$VS_Country��$FORM{'vsname'}�r�p$VS_VALUES[3]������O����,��$Vs_WeaponNameA�ϥX$Vs_MsnStyle���� �α��෽:$Vs_W[4],$VssumDmg<br>
$ResultTag $ResultAfterFight
</td>
</tr>
</table>



</div> 

<script language="JavaScript">

function Detect_ActionDown()
{

if (actiondown== 1)
{
 gobal_fun_moveto('final_result_show',30,220); 
}
setTimeout('Detect_ActionDown()',2000);
}

Detect_ActionDown();

</script>
	-----END-----
}

sub SYUSEI{
		$AT="$_[2]_AttPoint";$DE="$_[2]_DefPoint";$SP="$_[2]_SpPoint";
	if($_[0] eq 'm'){
		$MsnStyle="$_[2]_MsnStyle";
		if   ($_[1] == 1){$$MsnStyle="���q����";}
		elsif($_[1] == 2){$$AT*=1.3;$$DE*=0.7;$$MsnStyle="����";}
		elsif($_[1] == 3){$$AT*=0.8;$$DE*=2;$$MsnStyle="���m";}
		elsif($_[1] == 4){$$AT*=0.7;$$SP*=2;$$MsnStyle="���u����";}
		elsif($_[1] == 5){$$DE*=0.8;$$MsnStyle="����";
			$Pl_W[2]+=20 if $_[2] eq 'Pl';$Vs_W[2]+=20 if $_[2] eq 'Vs';
		}elsif($_[1] == 6){$$AT*=2;$$DE/=5;$$MsnStyle="�{��";}
		elsif($_[1] == 7){$$AT*=0.9;$$SP*=3;$$MsnStyle="����";
			$Pl_W[2]+=10 if $_[2] eq 'Pl';$Vs_W[2]+=10 if $_[2] eq 'Vs';
		}elsif($_[1] == 8){$$MsnStyle="���u��X";
			($Pl_W[2]-=35,$Pl_W[3]*=2,$Pl_W[4]*=2) if $_[2] eq 'Pl';
			($Vs_W[2]-=35,$Vs_W[3]*=2,$Vs_W[4]*=2) if $_[2] eq 'Vs';
		}elsif($_[1] == 9){$$AT*=2;$$DE*=2;$$MsnStyle="�îg";}
		elsif($_[1] == 10){$$AT*=1.2;$$SP*=4;$$MsnStyle="�߲�";
			$Pl_W[2]+=20 if $_[2] eq 'Pl';$Vs_W[2]+=20 if $_[2] eq 'Vs';
		}elsif($_[1] == 11){$$MsnStyle="���g�T�s";
			($Pl_W[2]-=65,$Pl_W[3]*=3,$Pl_W[4]*=3) if $_[2] eq 'Pl';
			($Vs_W[2]-=65,$Vs_W[3]*=3,$Vs_W[4]*=3) if $_[2] eq 'Vs';}
		elsif($_[1] == 12){$$AT*=2.5;$$SP*=1.5;$$MsnStyle="�@�I����";
			$Pl_W[2]+=10 if $_[2] eq 'Pl';$Vs_W[2]+=10 if $_[2] eq 'Vs';
		}
		elsif($_[1] == 13){$$AT*=3;$$SP*=6;$$MsnStyle="�t�̤���";
			($Pl_W[2]+=50,$Pl_W[4]*=4) if $_[2] eq 'Pl';
			($Pl_W[2]+=50,$Pl_W[4]*=4) if $_[2] eq 'Vs';
		}
		elsif($_[1] == 14){$$AT*=2;$$SP*=30;$$DE*=4;$$MsnStyle="��������";
			($Pl_W[2]+=90,$Pl_W[4]*=2) if $_[2] eq 'Pl';
			($Pl_W[2]+=90,$Pl_W[4]*=2) if $_[2] eq 'Vs';
		}

	}
	if($_[0] eq 's'){
		if   ($_[1] eq "1"){$$AT*=1.2;$$DE-=2;}
		elsif($_[1] eq "2"){$$AT*=1.2;$$WM-=5;}
		elsif($_[1] eq "3"){$$AT*=0.9;$$SP+=3;}
		elsif($_[1] eq "4"){$$WM+=5;}
		elsif($_[1] eq "5"){$$AT*=1.3;$$WM+=10;$$DE-=4;}
		elsif($_[1] eq "6"){$$AT*=1.5;$$DE*=1.5;$$SP*=4;$$WM*=1.5;}
		elsif($_[1] eq "7"){$$AT*=2;$$DE*=2;$$SP*=0.8;$$WM*=0.8;}
		elsif($_[1] eq "8"){$$AT*=2;$$DE*=0.8;$$SP*=2;$$WM*=1.5;}



	}
}



sub WriteSNGMsg
    {
    my ($Message)=@_;
    $MeetTas=1;
    $AttackTime="$month��$mday�� $hours:$minutes:$second";
    if (!-e "$LOG_FOLDER/tas.htm") {@tasvalue[0]="\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";
    write_file("$LOG_FOLDER/tas.htm",@tasvalue);}
    @tasvalue=read_file("$LOG_FOLDER/tas.htm");
    $tasi=@tasvalue-1;
    foreach(1..$tasi)
    {
    	@tasvalue[$tasi]=@tasvalue[$tasi-1];
    	$tasi--;
    }	
    @tasvalue[0]="$Message ($AttackTime)<br>\n";
    write_file("$LOG_FOLDER/tas.htm",@tasvalue);
    }
1;