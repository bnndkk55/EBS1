#!/usr/bin/perl
require 'config.cgi';
require "debug_sub.pl";
require 'ebs_sub1.cgi';
require "$LOG_FOLDER/$HASH_DATA";

print "Content-type: text/html;\n\n";
print '<body bgcolor="#000000" ><font size="2" color=white>�����H�j�� �Z���C�� <A href="http://www.7era.com/free/debug/">DEBUG</A> �s�@..�ۧ@�v,���v�Ҧ�</font><br>';
&pre_get_value;

if ($parm1 eq 'fgrtyhgt')
{
@pair = split(/;/, $ENV{'HTTP_COOKIE'});
foreach (@pair) {my($key, $value) = split(/=/, $_);$DUMMY{$key} = $value;}
@pairs = split(/,/, $DUMMY{EB});
foreach (@pairs) 
{
my($key, $value) = split(/:/, $_);
$COOKIE{$key} = $value;
}


$CurrentTime=localtime(time);
$SeeListRecFile="evenrecord/whoseeweaponlist.txt";
if (-e $SeeListRecFile){@SeeBuffer=read_file("$SeeListRecFile");}
@SeeBuffer[0].="$COOKIE{'pname'}($Ipaddress) ����: $COOKIE{'passname'} $CurrentTime\n";
&write_file("$SeeListRecFile",@SeeBuffer);

}	









%ColorList=(0=>'#AAAAAA',1=>'#888888',2=>'#CCCCCC');



foreach $Key (sort (keys %WEAPON_LIST))
{
$Indx++;
#while (($Key,$Value) = each %WEAPON_LIST)
        #{
        $Value=$WEAPON_LIST{$Key};
        @GetValue=split(/\,/,$Value);
        #print "<font size=2>�W��:@GetValue[0] �����O:@GetValue[1] �R���v:@GetValue[2] �����^��:@GetValue[3] ���OEN:@GetValue[4] ��X��@GetValue[5]</font><br>";
if($parm1 eq "special"){$SpecialWay="<br>�S��:".$WeaponUseWay{@GetValue[7]};}

$ColorCho=$Indx%3;
$isshowall=0;
$GetdisableKey=substr($Key,0,1);
if (($GetdisableKey ne 'w') && ($GetdisableKey ne 'z')) {$isshowall=1;}
if (rindex($Key,'magic') != -1) {$isshowall=0;}
if (rindex($Key,'wya') != -1) {$isshowall=0;}
if (length($Key) == 1){$SetColor=$ColorList{$ColorCho};}
if ($parm1 eq "fgrtyhgt") {$isshowall=1;}
if ($isshowall == 1)
{
#@GetValue[1]
$WeaponAttPower=STATUS_CONVERT(@GetValue[1]*@GetValue[3]/500,'s');
#@GetValue[2]
$WeaponHitPower=&STATUS_CONVERT(@GetValue[2]/4,'s');

if ($parm1 eq "fgrtyhgt") {$WeaponAttPower=@GetValue[1];$WeaponHitPower=@GetValue[2];}

print << "---HTMLTAG----";
<font size=2></font><table border="1" width="752" cellspacing="1" cellpadding="0" bgcolor="$SetColor" bordercolorlight="#D89812" bordercolordark="#FEF7E0"><tr><td width="258" bgcolor="$SetColor"><font size=2>�W��:@GetValue[0]$SpecialWay</font></td><td width="85"><font size=2>�����O:<br>
      $WeaponAttPower</font></td><td width="83"><font size=2>�R���O:<br>
      $WeaponHitPower&nbsp;</font></td><td width="72"><font size=2>�����^��:<br>
      @GetValue[3]</font></td><td width="73"><font size=2> ����EN:<br>
      @GetValue[4]</font></td><td width="65"><font size=2> ��X��:<br>
      @GetValue[5]</font></td><td width="73"><font size="2">�W�[���:<br>
      @GetValue[8]</font></td></tr></table>
---HTMLTAG----
} 


}
#<font size=2></font><table border="1" width="733" cellspacing="1" cellpadding="0"><tr><td width="258"><font size=2>�W��:@GetValue[0]$SpecialWay</font></td><td width="85"><font size=2>��:@GetValue[1]</font></td><td width="83"><font size=2>�R:@GetValue[2]&nbsp;</font></td><td width="72"><font size=2> �^��:@GetValue[3]</font></td><td width="84"><font size=2> EN:@GetValue[4]</font></td><td width="111"><font size=2> ��X��@GetValue[5]</font></td></tr></table>
#�γ~:@GetValue[7]
#�W�[���:@GetValue[8]

sub pre_get_value
{
# ���Φr��Χ�r��ѽX�^��Ӫ��r��
if ($ENV{'REQUEST_METHOD'} eq 'POST')
{
    read(STDIN, $temp, $ENV{'CONTENT_LENGTH'});
}
else
{
    $temp=$ENV{'QUERY_STRING'};
}

@key_value=split(/&/,$temp);

foreach $item(@key_value) 
{
    ($key,$value)=split (/=/,$item,2);
    $value=~tr/+/ /;
    $value=~ s/%(..)/pack("c",hex($1))/ge;
    $FORM{$key}=$value;
}

$buff = "$ENV{'QUERY_STRING'}";
$buff =~ s/\+/ /g;

($parm1,$parm2,$parm3)=split(/ /,$buff);
}
