#!/usr/bin/perl

require "ebs_sub1.cgi";
require "debug_sub.pl";
require "$LOG_FOLDER/$HASH_DATA";
$PasswordNameErrorMdy="�K�X�����D!";
%GMPassword=("DEBUG"=>"ertgfd","GM01"=>"rtgbvf","Chris"=>"ertyuyty","GM05"=>"frtdf",);
print "Content-type: text/html;\n\n";
print "<html>";
&pre_get_value;

#$ItemInq=$FORM{'SelectItem'};
#$Password=$FORM{'GmPassword'};
#$GmName=$FORM{'GmName'};
#$OptionalName=$FORM{'OptionalName'};


ShowPasswordForm();
CheckGMPassword($GmName,$Password);
print "�K�X�q�L!<br>";
print "�� $ItemInq!<br>";
print "�B�z�ܮw:";
if ($parm1 eq "readdata")
{
&DBM_INPORT(P);

while (($Key,$Value) = each %P)
{
@PL_VALUES = split(/\s/,$Value);
($Weapon0ID,$None)=split(/!/,@PL_VALUES[9]);
($Weapon1ID,$None)=split(/!/,@PL_VALUES[10]);
($Weapon2ID,$None)=split(/!/,@PL_VALUES[11]);
($Weapon3ID,$None)=split(/!/,@PL_VALUES[98]);
($Weapon4ID,$None)=split(/!/,@PL_VALUES[99]);
$AllWeapon{$Weapon0ID}++;
$AllWeapon{$Weapon1ID}++;
$AllWeapon{$Weapon2ID}++;
$AllWeapon{$Weapon3ID}++;
$AllWeapon{$Weapon4ID}++;

if ($ItemInq ne "")
{
if ($ItemInq eq GetItemInfo($Weapon0ID,'name')){print "<font color='red'>$Key ��W�Z����즳 $ItemInq</font> <br>";}	
if ($ItemInq eq GetItemInfo($Weapon1ID,'name')){print "<font color='red'>$Key �Z�����1�� $ItemInq</font> <br>";}	
if ($ItemInq eq GetItemInfo($Weapon2ID,'name')){print "<font color='red'>$Key �Z�����2�� $ItemInq</font> <br>";}	
if ($ItemInq eq GetItemInfo($Weapon3ID,'name')){print "<font color='red'>$Key �Z�����3�� $ItemInq</font> <br>";}	
if ($ItemInq eq GetItemInfo($Weapon4ID,'name')){print "<font color='red'>$Key �Z�����4�� $ItemInq</font> <br>";}	
}

$RealStorageFile="$StorageDir/$Key.dat";
#print "$RealStorageFile ";

if (-e $RealStorageFile)
{
print "$Key ";
@Nothing=read_file($RealStorageFile);
foreach my $ItemInfo(@Nothing)
{
($WeaponID,$None)=split(/!/,$ItemInfo);
if ($ItemInq ne "")
{
if ($ItemInq eq GetItemInfo($WeaponID,'name')){print "<font color='red'>$Key �ܮw�� $ItemInq</font> <br>";}	
}

$AllWeapon{$WeaponID}++;
}	
}

}






print "<br>";
while (($Key,$Value) = each %AllWeapon)
{
$WeaponName=GetItemInfo($Key,'name');
if ($WeaponName eq ""){$WeaponName = "$Key(�����Z��ID)";}
print "$WeaponName = $Value ��<br>";
}



print qq~
<form method="POST" action="itemcounter.pl?readdata" name="PasswordForm">
<input type="submit" value="OK">
<input type="hidden" value="$Password" name="GmPassword">
<input type="hidden" value="$GmName" name="GmName">";
<input type="hidden" value="$ItemInq" name="SelectItem">
<input type="text" value="$FORM{'OptionalName'}" name="OptionalName">
</form>~;
}


sub ShowPasswordForm
{
$ItemInq=$FORM{'SelectItem'};
$Password=$FORM{'GmPassword'};
$GmName=$FORM{'GmName'};
$OptionalName=$FORM{'OptionalName'};

if (($GmName eq "") or ($Password eq ""))
{

print << "---HTNLTAG----"; 
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=big5">
</head>
<body bgcolor="#FFF4E6">
<form method="POST" action="itemcounter.pl?readdata" name="PasswordForm">
ID<input type="text" value="$GmName" name="GmName">
Password<input type="password" value="$Password" name="GmPassword">
�Z���֦��̬d��(�Z���W)<input type="text" value="$ItemInq" name="SelectItem"><br>

<select name="SelectType">
<option value="Storage">�ܮw���</option>
<option value="Player">�H�����</option>
</select>
<input type="submit" value="OK">
</form>
</body>
</html>
---HTNLTAG----
exit;
}	
}

sub pre_get_value
{
# ���Φr��Χ�r��ѽX�^��Ӫ��r��
if ($ENV{'REQUEST_METHOD'} eq 'POST')
{
    read(STDIN, $temp, $ENV{'CONTENT_LENGTH'});
}
else
{
    $temp=$ENV{'QUERY_STRING'};
}

@key_value=split(/&/,$temp);

foreach $item(@key_value) 
{
    ($key,$value)=split (/=/,$item,2);
    $value=~tr/+/ /;
    $value=~ s/%(..)/pack("c",hex($1))/ge;
    $FORM{$key}=$value;
}

$buff = "$ENV{'QUERY_STRING'}";
$buff =~ s/\+/ /g;

($parm1,$parm2,$parm3)=split(/ /,$buff);
}

sub WriteDBData
{
my($FileName,$UserName,@DataValue)=@_;
&LOCK;
dbmopen (%P,"$FileName",0666);
$P{"$UserName"}="@DataValue";
dbmclose %P;
&UNLOCK;
print "Wrote ($UserName,$FileName)";
}	

sub ReadDBData
{
my @DataValue;
my($UserName,$FileName)=@_;
&LOCK;
dbmopen (%V,"$FileName",0666);
@DataValue= split(/\s/,$V{"$UserName"});
dbmclose %V;
&UNLOCK;
return @DataValue;
}	

sub CheckGMPassword
{
my($GmName,$Password)=@_;
if (($GmName ne "") && ($Password ne ""))
{
my $PasswordInfo=$GMPassword{$GmName};
if ($PasswordInfo ne $Password)
{
print $PasswordNameErrorMdy;
exit;
}	
}
else
{
print $PasswordNameErrorMdy;
exit;
}		

}	

sub GetItemInfo
{
my ($ItemKey,$Mode)=@_;
@spwn=split(/\,/,$WEAPON_LIST{"$ItemKey"});
if ($Mode eq 'name') {return @spwn[0];}
if ($Mode eq 'price') {return @spwn[5];}
}