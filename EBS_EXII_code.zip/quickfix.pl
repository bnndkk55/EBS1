#!/usr/bin/perl
#���L���a�I���ӱN��Ʈ���
require "ebs_sub1.cgi";
require "debug_sub.pl";
$PasswordNameErrorMdy="�K�X�����D!";
%GMPassword=("DEBUG"=>"ertgfd","GM01"=>"rtgbvf","Chris"=>"ertyuyty");
print "Content-type: text/html;\n\n";
print "<html>";
&pre_get_value;

ShowPasswordForm();
CheckGMPassword($GmName,$Password);
print "�K�X�q�L!<br>";

if ($parm1 eq "readdata")
{
if ($FORM{'SelectType'} eq "Player"){@PL_VALUES=ReadDBData($UserName,$DBM_P);}
if ($FORM{'SelectType'} eq "Country"){@PL_VALUES=ReadDBData($UserName,$DBM_C);}
if ($FORM{'SelectType'} eq "SelfFile"){@PL_VALUES=ReadDBData($UserName,"$LOG_FOLDER/$FORM{'OptionalName'}");};

$Index=0;
print (time);
print "<form method=\"POST\" action=\"quickfix.pl?writedata\" name=\"PasswordForm\">";
foreach $ListAll(@PL_VALUES)
{
print "($Index) <input type=\"text\" value=\"$ListAll\" name=\"$Index\"><br>";
$Index++;
}	
print "<input type=\"submit\" value=\"OK\">";
print "<input type=\"hidden\" value=\"$Password\" name=\"GmPassword\">";
print "<input type=\"hidden\" value=\"$GmName\" name=\"GmName\">";
print "<input type=\"hidden\" value=\"$UserName\" name=\"SelectID\">";
print "<input type=\"text\" value=\"$FORM{'SelectType'}\" name=\"SelectType\"> Player Country SelfFile";
print "<input type=\"text\" value=\"$FORM{'OptionalName'}\" name=\"OptionalName\">";


print "</form>";
print "</html>";
}

if ($parm1 eq "writedata")
{

if ($FORM{'SelectType'} eq "Player"){@PL_VALUES=ReadDBData($UserName,$DBM_P);}
if ($FORM{'SelectType'} eq "Country"){@PL_VALUES=ReadDBData($UserName,$DBM_C);}
if ($FORM{'SelectType'} eq "SelfFile") {@PL_VALUES=ReadDBData($UserName,"$LOG_FOLDER/$FORM{'OptionalName'}");};

$WriteIndex=0;

foreach (@PL_VALUES)
{
@UserValues[$WriteIndex]=$FORM{"$WriteIndex"};
$WriteIndex++;
}


if ($FORM{'SelectType'} eq "Player"){WriteDBData($DBM_P,$UserName,@UserValues);}
if ($FORM{'SelectType'} eq "Country"){WriteDBData($DBM_C,$UserName,@UserValues);}
if ($FORM{'SelectType'} eq "SelfFile") {WriteDBData("$LOG_FOLDER/$FORM{'OptionalName'}",$UserName,@UserValues);}

print "$FORM{'SelectType'} $UserName DATA WROTE!";
}

sub ShowPasswordForm
{
$UserName=$FORM{'SelectID'};
$Password=$FORM{'GmPassword'};
$GmName=$FORM{'GmName'};
$OptionalName=$FORM{'OptionalName'};

if (($GmName eq "") or ($Password eq ""))
{

print << "---HTNLTAG----"; 
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=big5">
</head>
<body bgcolor="#FFF4E6">
<form method="POST" action="quickfix.pl?readdata" name="PasswordForm">
ID<input type="text" value="$GmName" name="GmName">
Password<input type="password" value="$Password" name="GmPassword">
UserName<input type="text" value="$UserName" name="SelectID"><br>
FileName(�۩w�ɦW)<input type="text" value="$FORM{'OptionalName'}" name="OptionalName">

<select name="SelectType">
<option value="Player">���a���</option>
<option value="Country">��a���</option>
<option value="SelfFile">�۩w�ɦW</option>
</select>
<input type="submit" value="OK">
</form>
</body>
</html>
---HTNLTAG----
exit;
}	
}

sub pre_get_value
{
# ���Φr��Χ�r��ѽX�^��Ӫ��r��
if ($ENV{'REQUEST_METHOD'} eq 'POST')
{
    read(STDIN, $temp, $ENV{'CONTENT_LENGTH'});
}
else
{
    $temp=$ENV{'QUERY_STRING'};
}

@key_value=split(/&/,$temp);

foreach $item(@key_value) 
{
    ($key,$value)=split (/=/,$item,2);
    $value=~tr/+/ /;
    $value=~ s/%(..)/pack("c",hex($1))/ge;
    $FORM{$key}=$value;
}

$buff = "$ENV{'QUERY_STRING'}";
$buff =~ s/\+/ /g;

($parm1,$parm2,$parm3)=split(/ /,$buff);
}

sub WriteDBData
{
my($FileName,$UserName,@DataValue)=@_;
&LOCK;
dbmopen (%P,"$FileName",0666);
$P{"$UserName"}="@DataValue";
dbmclose %P;
&UNLOCK;
print "Wrote ($UserName,$FileName)";
}	

sub ReadDBData
{
my @DataValue;
my($UserName,$FileName)=@_;
&LOCK;
dbmopen (%V,"$FileName",0666);
@DataValue= split(/\s/,$V{"$UserName"});
dbmclose %V;
&UNLOCK;
return @DataValue;
}	

sub CheckGMPassword
{
my($GmName,$Password)=@_;
if (($GmName ne "") && ($Password ne ""))
{
my $PasswordInfo=$GMPassword{$GmName};
if ($PasswordInfo ne $Password)
{
print $PasswordNameErrorMdy;
exit;
}	
}
else
{
print $PasswordNameErrorMdy;
exit;
}		

}	
