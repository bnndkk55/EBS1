	    if ($CharacterName eq "�˳ưӤH")
	    {
	    	($CurrentItem1ID,$None)= split(/!/,@PL_VALUES[9]);
	
	     if ($CurrentItem1ID eq "3333333333")
	     {
		@PL_VALUES[9]="wsa!0!a";	     
	       $OutputMessage.=SetFontAttr("2","#f105ab",1,"�˳ưӤH ��F���q���i���� $GetUserName");
	       WritePldata($GetUserName,@PL_VALUES);   
	     }	

	     if ($CurrentItem1ID eq "33333333333333")
	     {
		@PL_VALUES[9]="htlock!0!a";	     
	       $OutputMessage.=SetFontAttr("2","#f105ab",1,"�˳ưӤH ��F�ܮw�굹 $GetUserName");
	    	WritePldata($GetUserName,@PL_VALUES);   
	     }	
	    }	
1;