#!/usr/bin/perl




require 'config.cgi';
require "ebs_sub1.cgi";
require "$LOG_FOLDER/$HASH_DATA";

&pre_get_value;

$proxyip = $ENV{HTTP_X_FORWARDED_FOR};
if ($proxyip){$proxyip="�u��IP:".$proxyip;}



print "Content-type: text/html;charset=big5\n\n";
print '�@�Բ{����p���� <a href="http://www.7era.com/free/debug/" target="_blank">DEBUG</a> �s�@..�ۧ@�v,���v�Ҧ� 2009-10-21<br>';

 @tasvalue=read_file("$LOG_FOLDER/tas.htm");
print @tasvalue;

exit;

sub write_file
{
 local($writefile_dat,@value)=@_;
 open(WRITEFILE,">$writefile_dat") || die $!;
 if ($local_test eq 0) {flock(WRITEFILE,LOCK_EX)};
 print WRITEFILE @value;
 if ($local_test eq 0) {flock(WRITEFILE,LOCK_UN)};
 close(WRITEFILE);
}	

sub read_file
{
 local($filename)=@_;
 open(READFILE,"<$filename") || die $!;
 if ($local_test eq 0) {flock(WRITEFILE,LOCK_EX)};
 @filedata = <READFILE>;
 if ($local_test eq 0) {flock(WRITEFILE,LOCK_UN)};
 close(READFILE);
return @filedata,;
}	



sub pre_get_value
{
# ���Φr��Χ�r��ѽX�^��Ӫ��r��
if ($ENV{'REQUEST_METHOD'} eq 'POST')
{
    read(STDIN, $temp, $ENV{'CONTENT_LENGTH'});
}
else
{
    $temp=$ENV{'QUERY_STRING'};
}

@key_value=split(/&/,$temp);

foreach $item(@key_value) 
{
    ($key,$value)=split (/=/,$item,2);
    $value=~tr/+/ /;
    $value=~ s/%(..)/pack("c",hex($1))/ge;
    $FORM{$key}=$value;
    if (rindex(' ',$value) ne -1){print "���t�����`�r��";exit;}
    if (rindex('!',$value) ne -1){print "���t�����`�r��";exit;}
    if (rindex('@',$value) ne -1){print "���t�����`�r��";exit;}
    if (rindex('.',$value) ne -1){print "���t�����`�r��";exit;}
}

$buff = "$ENV{'QUERY_STRING'}";
$buff =~ s/\+/ /g;

($parm1,$parm2,$parm3)=split(/ /,$buff);
}
