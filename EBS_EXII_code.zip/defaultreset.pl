@Buffer[0]=$FORM{'B0'};#GAME中帳號 
@Buffer[1]=$FORM{'B1'};#
@Buffer[2]=$FORM{'B2'};#暱稱
@Buffer[3]=crypt "$FORM{'B3'}","MK";#帳號密碼
@Buffer[4]=crypt "$FORM{'B4'}","MK";#密碼確認
@Buffer[5]=$FORM{'B5'};#Email聯絡信箱

@Buffer[30]="";#裝備空間開頭

@Buffer[150]="";#裝備空間結尾

@Buffer[190]="10";#最大空間指標,最大不超過150

@Buffer[201]="";
@Buffer[202]="";
@Buffer[203]="";
1;
