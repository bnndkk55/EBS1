if (rindex($FORM{'pname'},'-�X-') ne -1 )
{
 &ERROR('�X���~�u��ΨӾ԰�!');
}

sub CUSTOM_HEADER {
	$BgColor="bgcolor=\"#000000\"";
	&HEADER;
	print << "	-----END-----";
	<form action=$MAIN_SCRIPT method=POST name=Ms target="$_[0]" onSubmit='window.location.replace("$MAIN_SCRIPT?LOGO");'>
		<input type=hidden name=cmd value=CUSTOM>
		<input type=hidden name=CustomCheck value=$Date>
		<input type=hidden name=pname value=$FORM{'pname'}>
		<input type=hidden name=pass value=$FORM{'pass'}>
	<center><table bordercolor=\"#333333\" border=1 cellspacing=0 style="font-size:10pt;">
		<tr><td bgcolor=\"#808080\"><b>$FORM{'custom'}</b></td></tr>
	-----END-----
}
sub EQUIP {
	&CUSTOM_HEADER('Main');
	require "$LOG_FOLDER/$HASH_DATA";
	require "$LOG_FOLDER/_ex.data";
	&LOCK;&DBM_CONVERT('P',"$FORM{pname}");&UNLOCK;
	local($WN_A,$WLV_A,$WEX_A) = split(/!/,$PL_VALUES[9]);
	local($WN_B,$WLV_B,$WEX_B) = split(/!/,$PL_VALUES[10]);
	local($WN_C,$WLV_C,$WEX_C) = split(/!/,$PL_VALUES[11]);
	local($WN_D,$WLV_D,$WEX_D) = split(/!/,$PL_VALUES[98]);
	local($WN_E,$WLV_E,$WEX_E) = split(/!/,$PL_VALUES[99]);
	@WN_sA=split(/\,/,$WEAPON_LIST{"http://www.asp300.com/soft/bbs/javaclub.zip"});
	@WN_sB=split(/\,/,$WEAPON_LIST{"$WN_B"});
	@WN_sC=split(/\,/,$WEAPON_LIST{"$WN_C"});
	@WN_sD=split(/\,/,$WEAPON_LIST{"$WN_D"});
	@WN_sE=split(/\,/,$WEAPON_LIST{"$WN_E"});
	@WEX_sA=split(/\,/,$WEAPONEX_LIST{"$WEX_A"});
	@WEX_sB=split(/\,/,$WEAPONEX_LIST{"$WEX_B"});
	@WEX_sC=split(/\,/,$WEAPONEX_LIST{"$WEX_C"});
	@WEX_sD=split(/\,/,$WEAPONEX_LIST{"$WEX_D"});
	@WEX_sE=split(/\,/,$WEAPONEX_LIST{"$WEX_E"});
	$WLV_A=int $WLV_A/$WEAPON_LVUP;
	$WLV_B=int $WLV_B/$WEAPON_LVUP;
	$WLV_C=int $WLV_C/$WEAPON_LVUP;
	$WLV_D=int $WLV_D/$WEAPON_LVUP;
	$WLV_E=int $WLV_E/$WEAPON_LVUP;
	$Pl_WeaponNameA="$WN_sA[0](Lv$WLV_A)$WEX_sA[0]";
	$Pl_WeaponNameB="$WN_sB[0](Lv$WLV_B)$WEX_sB[0]";
	$Pl_WeaponNameC="$WN_sC[0](Lv$WLV_C)$WEX_sC[0]";
	$Pl_WeaponNameD="$WN_sD[0](Lv$WLV_D)$WEX_sD[0]";
	$Pl_WeaponNameE="$WN_sE[0](Lv$WLV_E)$WEX_sE[0]";
	if ($WN_sB[0]||$WN_sC[0]||$WN_sD[0]||$WN_sE[0]){
		$PartofW="<select name=soubi $STYLE_L>";
		if ($WN_sB[0] ne ""){$PartofW.="<option value=B>$Pl_WeaponNameB";}
		if ($WN_sC[0] ne ""){$PartofW.="<option value=C>$Pl_WeaponNameC";}
		if ($WN_sD[0] ne ""){$PartofW.="<option value=D>$Pl_WeaponNameD";}
		if ($WN_sE[0] ne ""){$PartofW.="<option value=E>$Pl_WeaponNameE";}
		$PartofW.="</select><input type=submit name=Cmode value=�˳� class=button2 onClick=\"return checkEquip()\">";
		&JScfm(checkEquip,"�˳��ܧ�A�T�{�ܡH");
		print "<tr><td $BgColor><b>�˳��ܧ�</b><br>\n";
		print "&nbsp;$Pl_WeaponNameA�˳Ƥ�<div align=right>$PartofW</div></td></tr>\n";
	}
	if ($WLV_A >= $WEAPON_RANKUP){
		&JScfm(checkRnkup,"�Z����y�A�T�{�ܡH");
		while (my ($key,$val) = each %WEAPON_LIST){
			if (substr($key,0,length($WN_A)) eq $WN_A && length($key) == length($WN_A)+1){
				my @UpW = split(/\,/,$val);
				$WeCH++;
				print "<tr><td $BgColor><b>�ɯŪZ��</b><br>\n" if $WeCH ==1;
				print "<table style=\"font-size:10pt;\"><tr><td $BgColor>&nbsp;\n";
				print "$Pl_WeaponNameA\n" if $WeCH ==1;
				print "<font color=\"000000\">$Pl_WeaponNameA</font>\n" if $WeCH !=1;
				print "</td><td $BgColor><font color=#1e90ff><b>=></b></font>\n";
				print "<input type=radio name=wname value=$key\n";
				print " checked" if $WeCH ==1;
				print ">$UpW[0]</td><td $BgColor>\n";
				print "<input name=\"Cmode\" type=submit value=CUSTOM�� class=button2 " if $WeCH ==1;
				print "onClick=\"return checkRnkup()\">\n" if $WeCH ==1;
				print "</td></tr></table>\n";
			}
		}
	}
		if ($WN_sB[0] ||$WN_sC[0]||$WN_sD[0]||$WN_sE[0]){
		$PartofSW.="<option value=1>$Pl_WeaponNameB" if $WN_sB[0];
		$PartofSW.="<option value=2>$Pl_WeaponNameC" if $WN_sC[0];
		$PartofSW.="<option value=3>$Pl_WeaponNameD" if $WN_sD[0];
		$PartofSW.="<option value=4>$Pl_WeaponNameE" if $WN_sE[0];
		print "<SCRIPT language=\"JavaScript\">\nfunction checkMoney (){\n";
		print "num=document.Ms.sellw.value;\nif (num==1){var wn='$Pl_WeaponNameB';var mn='".int($WN_sB[5]/3)."';}\n";
		print "else if (num ==2){var wn='$Pl_WeaponNameC';var mn='".int($WN_sC[5]/3)."';}\n";
		print "if (confirm(wn + '�N\$' + mn + '�X��') == true){\n";
		print "window.location.replace(\"./dummy.html\");return true;}else{return false}\n";
		print "}\n</script>\n<tr><td $BgColor><b>�Z���X��</b><div align=right><select name=sellw $STYLE_L>";
		print "$PartofSW</select><input type=submit name=Cmode value=�X�� ";
		print "class=button2 onClick=\"return checkMoney()\"></div></td></tr>";
	}
	if (!$WN_sB[0] ||!$WN_sC[0]||!$WN_sD[0]||!$WN_sE[0]){
		print "<tr><td $BgColor><b>�Z���ʤJ</b><table style=\"font-size:10pt;\">\n";
		&JScfm(checkBuy,"�n�ʤJ�s�Z���A�T�w�ܡH");
		local($Flag=0);
		$buy="<select name=buyw $STYLE_L>";
		while (my($key,$value) = each %WEAPON_LIST){
			if (length($key) == 1){
				my @ByW = split(/\,/,$value);
				if (!$PL_VALUES[5]){$ByW[5]=int ($ByW[5]*0.8);}
				if($ByW[5] <= $PL_VALUES[8] && $ByW[6] != 1 && $ByW[6] != 4 && $ByW[6] != 5){
					print "<tr><td>&nbsp;&nbsp;$ByW[0]</td><td>\$$ByW[5]</td></tr>";
					$buy.="<option value=$key>$ByW[0]\n";$Flag++;}
			}
		}
		if ($Flag>0){$buy.="</select><input name=\"Cmode\" type=submit value=�ʤJ
					class=button2 onClick=\"return checkBuy()\">\n";}else{$buy="�w�g�F���y�W��";$Flag++;}
		print "</table><div align=right>$buy</div></td></tr>\n";
	}
	if (!$PL_VALUES[10] && !$PL_VALUES[11] && $Flag==0 && $WeCH ==0){
		print "<tr><td $BgColor>�������y�M�j��</td></tr></table>\n";}
	if ($WN_sA[8] eq $WN_sB[8] && $WN_sA[8] && $WN_sA[8]!=1 && $PL_VALUES[5] && $WLV_A >= $WEAPON_RANKUP && $WLV_B >= $WEAPON_RANKUP) {@PW_RH=split(/\,/,$WEAPON_LIST{"$WN_sA[8]"});&JScfm(checkRH,"�n��y$PW_RH[0]�A�T�w�ܡH");
	print "<tr><td $BgColor><table style=\"font-size:10pt;\"><b>�����H��y�M�j��<font color=#f7e957>$PW_RH[0]</font></b>&nbsp;<input name=\"Cmode\" type=submit value=�Z����y class=button2 onClick=\"return checkRH()\"></table></td></tr>";}
	print "</form></table>\n";&FOOTER;
}
sub WEX {
	&CUSTOM_HEADER('Main');
	require "$LOG_FOLDER/$HASH_DATA";
	require "$LOG_FOLDER/_ex.data";
	&LOCK;&DBM_CONVERT('P',"$FORM{pname}");&UNLOCK;
	local($WN_A,$WLV_A,$WEX_A) = split(/!/,$PL_VALUES[9]);
	local($WN_B,$WLV_B,$WEX_B) = split(/!/,$PL_VALUES[10]);
	local($WN_C,$WLV_C,$WEX_C) = split(/!/,$PL_VALUES[11]);
	local($WN_D,$WLV_D,$WEX_D) = split(/!/,$PL_VALUES[98]);
	local($WN_E,$WLV_E,$WEX_E) = split(/!/,$PL_VALUES[99]);
	@WN_sA=split(/\,/,$WEAPON_LIST{"$WN_A"});
	@WN_sB=split(/\,/,$WEAPON_LIST{"$WN_B"});
	@WN_sC=split(/\,/,$WEAPON_LIST{"$WN_C"});
	@WN_sD=split(/\,/,$WEAPON_LIST{"$WN_D"});
	@WN_sE=split(/\,/,$WEAPON_LIST{"$WN_E"});
	@WEX_sA=split(/\,/,$WEAPONEX_LIST{"$WEX_A"});
	@WEX_sB=split(/\,/,$WEAPONEX_LIST{"$WEX_B"});
	@WEX_sC=split(/\,/,$WEAPONEX_LIST{"$WEX_C"});
	@WEX_sD=split(/\,/,$WEAPONEX_LIST{"$WEX_D"});
	@WEX_sE=split(/\,/,$WEAPONEX_LIST{"$WEX_E"});
	$WLV_A=int $WLV_A/$WEAPON_LVUP;
	$WLV_B=int $WLV_B/$WEAPON_LVUP;
	$WLV_C=int $WLV_C/$WEAPON_LVUP;
	$WLV_D=int $WLV_D/$WEAPON_LVUP;
	$WLV_E=int $WLV_E/$WEAPON_LVUP;
	$Pl_WeaponNameA="$WN_sA[0](Lv$WLV_A)$WEX_sA[0]";
	$Pl_WeaponNameB="$WN_sB[0](Lv$WLV_B)$WEX_sB[0]";
	$Pl_WeaponNameC="$WN_sC[0](Lv$WLV_C)$WEX_sC[0]";
	$Pl_WeaponNameD="$WN_sD[0](Lv$WLV_D)$WEX_sD[0]";
	$Pl_WeaponNameE="$WN_sE[0](Lv$WLV_E)$WEX_sE[0]";
		print "<tr><td $BgColor><b>�Z���j�����P�ƥ����F��500�H�W</b><table style=\"font-size:9pt;\">\n";
		&JScfm(checkBuy,"�T�w�n�i��Z���j�ƶ�");
		local($Flag=0);
		$buy2="<select name=buyww $STYLE_L>";
		while (my($key,$value) = each %WEAPONEX_LIST){
#			if (length($key) == 1){
				my @ByW = split(/\,/,$value);
				if($PL_VALUES[24]>=500){
					print "<tr><td>&nbsp;&nbsp;$ByW[0]</td><td>\$100000 ���C���P��</td></tr>";
					$buy2.="<option value=$key>$ByW[0]\n";$Flag++;}
#			}
		}
		if ($Flag>0){$buy2.="</select><input name=\"Cmode\" type=submit value=�Z���j��
					class=button2 onClick=\"return checkBuy()\">\n";}else{$buy2="�ҫ������m�שθ������,��y�L��ĳ���n�A�j��";$Flag++;}
		print "</table><div align=right>$buy2</div></td></tr>\n";
	if ($Flag==0 && $WeCH ==0){
		print "<tr><td $BgColor>�j�ƶi�椤</td></tr>\n";}

require "$LOG_FOLDER/_hash2.data";
foreach my $Ckey (sort keys %COMPOSITE_LIST){
@COMPOW=split(/\,/,$COMPOSITE_LIST{"$Ckey"});
if($COMPOW[3] eq 0){
if($WN_A eq "$COMPOW[1]" || $WN_B eq "$COMPOW[1]" && $WLV_A >= $WEAPON_RANKUP){
if($WN_A eq "$COMPOW[2]" || $WN_B eq "$COMPOW[2]" && $WLV_B >= $WEAPON_RANKUP){
print "<tr><td $BgColor><b>�X���Z��</b><table style=\"font-size:9pt;\">\n";
&JScfm(checkCompo,"�X���Z���A�T�w�ܡH");
if (!$PL_VALUES[5]){$COMPOW[4]=int ($COMPOW[4]*0.8);}
if($COMPOW[4] <= $PL_VALUES[8]){
print "<tr><td>&nbsp;$COMPOW[0]</td><td>\$$COMPOW[4]</td></tr>";
$compo="<select name=compow $STYLE_L>";
$compo.="<option value=$Ckey>$COMPOW[0]\n";
$compo.="</select><input name=\"Cmode\" type=submit value=�X�� $STYLE_B1 onClick=\"return checkCompo()\">\n";}else{$compo="��������C";}
print "</table><div align=right>$compo</div></td></tr>\n";}}}
else{
if($WN_A eq "$COMPOW[1]" || $WN_B eq "$COMPOW[1]" || $WN_C eq "$COMPOW[1]" && $WLV_A >= $WEAPON_RANKUP){
if($WN_A eq "$COMPOW[2]" || $WN_B eq "$COMPOW[2]" || $WN_C eq "$COMPOW[2]" && $WLV_B >= $WEAPON_RANKUP){
if($WN_A eq "$COMPOW[3]" || $WN_B eq "$COMPOW[3]" || $WN_C eq "$COMPOW[3]" && $WLV_C >= $WEAPON_RANKUP){
print "<tr><td $BgColor><b>�X���Z��</b><table style=\"font-size:9pt;\">\n";
&JScfm(checkCompo,"�X���Z���A�T�w�ܡH");
if (!$PL_VALUES[5]){$COMPOW[4]=int ($COMPOW[4]*0.8);}
if($COMPOW[4] <= $PL_VALUES[8]){
print "<tr><td>&nbsp;$COMPOW[0]</td><td>\$$COMPOW[4]</td></tr>";
$compo="<select name=compow $STYLE_L>";
$compo.="<option value=$Ckey>$COMPOW[0]\n";
$compo.="</select><input name=\"Cmode\" type=submit value=�X�� $STYLE_B1 onClick=\"return checkCompo()\">\n";}else{$compo="��������C";}
print "</table><div align=right>$compo</div></td></tr>\n";}}}}
}
	print "</form></table>\n";&FOOTER;
}

sub CUSTOMING2 {
	&LOCK;&DBM_CONVERT('P',"$FORM{pname}");&UNLOCK;
	&CUSTOM_HEADER('Main');
	&JScfm(checkHp,"�@�[�O�j�ơA�T�w�ܡH");
	&JScfm(checkEn,"�U�ƽc�W�j�A�T�w�ܡH");
	&JScfm(checklvback,"��ͭn$LVBACK�A�T�w�ܡH");
	$HM=$PL_VALUES[16]+5000;$EM=$PL_VALUES[18]*10+5000;#�p�q��
	$HM2=($PL_VALUES[16]+5000)*5;$EM2=($PL_VALUES[18]*10+5000)*5;#���q��
	$HM3=($PL_VALUES[16]+5000)*7;$EM3=($PL_VALUES[18]*10+5000)*7;#�j�q��
print "<tr><td $BgColor colspan=4>";
print "<table border=0 cellpadding=0 cellspacing=0 style=\"border-collapse: collapse\" bordercolor=#111111 width=100%><tr>";
print "<td width=100% colspan=3 align=center>�����H��y�P�j�Ƥu�t</td></tr><tr>";
print "<td width=33%>HP�ɯ�</td>";
print "<td width=33%>�]\$$HM�^</td>";
print "<td width=34%><input type=submit name=\"Cmode\" value=\"HP�p�q�ɯ�\" class=button2 onClick='";
print "return checkHp()'>" if $PL_VALUES[8] >= $HM && $PL_VALUES[16] < $MAX_HP;
print "alert (\"�ҫ��������\");return false;'>" if $PL_VALUES[8] < $HM;
print "alert (\"�w�g�F���y�W��\");return false;'>" if $PL_VALUES[8] >= $HM && $PL_VALUES[16] >= $MAX_HP;
print "</td></tr><tr>";
print "<td width=33%>HP�ɯ�</td>";
print "<td width=33%>�]\$$HM2�^</td>";
print "<td width=34%><input type=submit name=\"Cmode\" value=\"HP���q�ɯ�\" class=button2 onClick='";
print "return checkHp()'>" if $PL_VALUES[8] >= $HM2 && $PL_VALUES[16] < $MAX_HP;
print "alert (\"�ҫ��������\");return false;'>" if $PL_VALUES[8] < $HM2;
print "alert (\"�w�g�F���y�W��\");return false;'>" if $PL_VALUES[8] >= $HM2 && $PL_VALUES[16] >= $MAX_HP;
print "</td></tr><tr>";
print "<td width=33%>HP�ɯ�</td>";
print "<td width=33%>�]\$$HM3�^</td>";
print "<td width=34%><input type=submit name=\"Cmode\" value=\"HP�j�q�ɯ�\" class=button2 onClick='";
print "return checkHp()'>" if $PL_VALUES[8] >= $HM3 && $PL_VALUES[16] < $MAX_HP;
print "alert (\"�ҫ��������\");return false;'>" if $PL_VALUES[8] < $HM3;
print "alert (\"�w�g�F���y�W��\");return false;'>" if $PL_VALUES[8] >= $HM3 && $PL_VALUES[16] >= $MAX_HP;
print "</td></tr><tr>";
print "<td width=33%>EN�ɯ�</td>";
print "<td width=33%>�]\$$EM�^</td>";
print "<td width=34%><input type=submit name=\"Cmode\" value=\"EN�p�q�ɯ�\" class=button2 onClick='";
print "return checkEn()'>" if $PL_VALUES[8] >= $EM && $PL_VALUES[18] < $MAX_EN;
print "alert (\"�ҫ��������\");return false;'>" if $PL_VALUES[8] < $EM;
print "alert (\"�w�g�F���y�W��\");return false;'>" if $PL_VALUES[8] >= $EM && $PL_VALUES[18] >= $MAX_EN;
print "</td></tr><tr>";
print "<td width=33%>EN�ɯ�</td>";
print "<td width=33%>�]\$$EM2�^</td>";
print "<td width=34%><input type=submit name=\"Cmode\" value=\"EN���q�ɯ�\" class=button2 onClick='";
print "return checkEn()'>" if $PL_VALUES[8] >= $EM2 && $PL_VALUES[18] < $MAX_EN;
print "alert (\"�ҫ��������\");return false;'>" if $PL_VALUES[8] < $EM2;
print "alert (\"�w�g�F���y�W��\");return false;'>" if $PL_VALUES[8] >= $EM2 && $PL_VALUES[18] >= $MAX_EN;
print "</td></tr><tr>";
print "<td width=33%>EN�ɯ�</td>";
print "<td width=33%>�]\$$EM3�^</td>";
print "<td width=34%><input type=submit name=\"Cmode\" value=\"EN�j�q�ɯ�\" class=button2 onClick='";
print "return checkEn()'>" if $PL_VALUES[8] >= $EM3 && $PL_VALUES[18] < $MAX_EN;
print "alert (\"�ҫ��������\");return false;'>" if $PL_VALUES[8] < $EM3;
print "alert (\"�w�g�F���y�W��\");return false;'>" if $PL_VALUES[8] >= $EM3 && $PL_VALUES[18] >= $MAX_EN;
print "</td></tr><tr>";
print "<td width=100% colspan=3 align=center>";
print "<input type=submit name=\"Cmode\" value=\"���\" class=button2 onClick='";
print "return checklvback()'>" if $PL_VALUES[8] >= $LVBACK && $PL_VALUES[29] >= 300;
print "alert (\"�ҫ��������$LVBACK\");return false;'>" if $PL_VALUES[8] < $LVBACK;
print "alert (\"���ݭn���\");return false;'>" if $PL_VALUES[29] < 300;
print "</td></tr><tr>";
print "<td width=100% colspan=3 align=center>";

print "</td></tr></table>";
print "</td></tr>";

	if ($PL_VALUES[8] >= 20000 && $PL_VALUES[24] >=200){
	print "<script language=\"JavaScript\">\nfunction changeImg(){num=document.Ms.icon.value;document.msImg.src=\"$IMG_FOLDER2/\"+ num +\".gif\";}\n</script>";
	&JScfm(checkCustom,"����Custom�ơA�T�w�ܡH");
	print "<tr><td $BgColor colspan=4><b>Custom</b><br>&nbsp;&nbsp;$20000<br>\n";
	print "&nbsp;&nbsp;ICON�ܧ�<img src=\"$IMG_FOLDER2/$PL_VALUES[27].gif\" name=\"msImg\"><br>\n";
	print "&nbsp;&nbsp;&nbsp;&nbsp;<select name=icon $STYLE_L onChange=\"changeImg()\">\n";
	foreach (0..$ICON){
		print "<option value=\"$_\"";
		print " selected\n"if $_ eq $PL_VALUES[27];
		print ">ICON No.$_\n";
	}
if (  ($SPECIAL_ICON == 1 && $PL_VALUES[16] >= 10000)
	||($SPECIAL_ICON == 2 && $PL_VALUES[12] eq '6')
	||($SPECIAL_ICON == 3 && $PL_VALUES[6] == 1)){$_='';
	foreach (500..$S_ICON_NUMBER){
		print "<option value=\"$_\"";
		print " selected\n"if $_ eq $PL_VALUES[27];
		print ">ICON No.$_\n";
	}
	if ($SPECIAL_ICON2 == 1 && $PL_VALUES[16] >= 40000)
	{$_='';
	foreach (700..$ICON3){
		print "<option value=\"$_\"";
		print " selected\n"if $_ eq $PL_VALUES[27];
		print ">ICON No.$_\n";
	}}}
	print "</select><br>&nbsp;&nbsp;MS����<br>&nbsp;&nbsp;&nbsp;&nbsp;\n";
	print "<input type=text name=MsName size=30 maxlength=15 value=$PL_VALUES[3] $STYLE_L><br>\n";
	print "&nbsp;&nbsp;���������ܧ�<br>&nbsp;&nbsp;&nbsp;&nbsp;\n";
	print "<select name=MsType $STYLE_L>\n";
	print "<option value=1";print " selected"if $PL_VALUES[4] eq '1';print ">�����O����\n";
	print "<option value=2";print " selected"if $PL_VALUES[4] eq '2';print ">���m�O����\n";
	print "<option value=3";print " selected"if $PL_VALUES[4] eq '3';print ">�ӱ��׭���\n";
	print "<option value=4";print " selected"if $PL_VALUES[4] eq '4';print ">�R���O����\n";
	print "<option value=0";print " selected"if $PL_VALUES[4] eq '0';print ">������</select><br>\n";
	print "&nbsp;&nbsp;���ܧ�<br>&nbsp;&nbsp;&nbsp;&nbsp;\n";
	$br=0;
		foreach (@COLOR){$br++;
			print "<input type=\"radio\" name=\"MsColor\" value=$_";
	        print " checked" if $_ =~ /$PL_VALUES[13]/i;
	        print "><font color=$_>��</font>\n";
			if ($br==5){print"<br>&nbsp;&nbsp;&nbsp;&nbsp;\n";$br=0;}
		}
	print "<div align=right>\n";
	print "<input name=\"Cmode\" type=submit value=\"Custom\" class=button2 onClick=\"if (document.Ms.MsName.value!=''){if (document.Ms.MsName.value.match('[&! =.,<>]') != null){alert('�b���Ÿ�������ϥΡC');return false;}else{return checkCustom()}}else{alert('MS�����п�J');return false;}\">\n";
	print "</div></td></tr>\n";
	}
	print "</form></table>\n";
	&FOOTER;
}
sub HISTORY {
	&CUSTOM_HEADER('Main');
	$c=0;
	dbmopen (%NOTE,"$DBM_H",0666);
		foreach $Key (sort {$b <=> $a} keys %NOTE){$c++;
			if ($c <= $HISTORY_MAX){
				print "<tr><td $BgColor><b>".&DATE_DECORD($Key)."</b>&nbsp;&nbsp;$NOTE{$Key}</td></tr>\n";
			}else{delete $NOTE{$Key};}
		}
	dbmclose %NOTE;
	print "</table>\n";
	&FOOTER;
}
sub COMMENT {
	&CUSTOM_HEADER('Main');
	&JScfm(checkComment,"�����ܧ�A�T�{�ܡH");
	print << "	-----END-----";
		<tr><td $BgColor><b>�����ܧ�</b><br>
		&nbsp;&nbsp;<input type="text" name="com" size="70" maxlength="30" value="" $STYLE_L><br>
		&nbsp;&nbsp;<span style="font-size:13px;">���׿�J�H��A�������^���Ϊ̽T�w��~���s�ܧ�</span><br>
		&nbsp;&nbsp;<input name="Cmode" type="submit" value="�ܧ�" class=button2 onClick=\"return checkComment()\">
		&nbsp;&nbsp;<input type="reset" value="�M��" class=button2></td></tr></form></table>
	-----END-----

	&FOOTER;
}
sub SPECIAL{

	&LOCK;&DBM_CONVERT('P',"$FORM{pname}");&UNLOCK;
if($PL_VALUES[16] < $NoSpecialHP){&ERROR("�ثe HP�W�� $PL_VALUES[16] �]HP���� $NoSpecialHP �L�k�ϥ�!");}
	&CUSTOM_HEADER('Sub');

	print "<tr><td $BgColor><br>";
	$sp.= "<input name=\"custom\" type=\"submit\" value=\"�ذ�\" class=button2  onClick=\"document.Ms.cmd.value='MAKE_C';\">" if $PL_VALUES[8] > $MAKE_COUNTRY;
	$sp.= "<input name=\"custom\" type=\"submit\" value=\"����\" class=button2  onClick=\"document.Ms.cmd.value='MAKE_T';\">"if $PL_VALUES[6]!=1 && $PL_VALUES[5];
	$sp.= "<input name=\"custom\" type=\"submit\" value=\"�Բ�\" class=button2  onClick=\"document.Ms.cmd.value='MISSION';\">" if $PL_VALUES[6] == 1 && $PL_VALUES[5];
	$sp.= "<input name=\"custom\" type=\"submit\" value=\"�n��j��\" class=button2  onClick=\"document.Ms.cmd.value='BOSS';\">" if $PL_VALUES[6] != 0 && $PL_VALUES[5];
	$sp.= "<input name=\"custom\" type=\"submit\" value=\"�����Ѵ�\"  class=button2 onClick=\"document.Ms.cmd.value='DEL_U';\">" if $PL_VALUES[6] == 1 && $PL_VALUES[5];
	$sp.= "<input name=\"custom\" type=\"submit\" value=\"�~��\" class=button2  onClick=\"document.Ms.cmd.value='MAKE_K';\">" if $PL_VALUES[5] && $PL_VALUES[6] == 1;
	$sp.= "<input name=\"custom\" type=\"submit\" value=\"�Z���اe\" class=button2  onClick=\"document.Ms.cmd.value='MAKE_A';\">"
	if (  ($WWMONEY == 1)
||($PL_VALUES[23] > 10 && $WMONEY == 2)
||($PL_VALUES[23] > 10 && $PL_VALUES[24] > 500 && $WMONEY == 3));
	$sp.= "<input name=\"custom\" type=\"submit\" value=\"�Z���j��\" class=button2  onClick=\"document.Ms.cmd.value='EX';\">"
if (  ($WCHANGE == 1)
||($PL_VALUES[23] > 10 && $WCHANGE == 2)
||($PL_VALUES[23] > 10 && $PL_VALUES[24] > 500 && $WCHANGE == 3));
	$sp.= "<input name=\"custom\" type=\"submit\" value=\"�Ѷ�\" class=button2  onClick=\"document.Ms.cmd.value='DEL_UNIT';\">" if $PL_VALUES[6] == 1 && $PL_VALUES[5];
	$sp='�ثe�S���i�H���檺�S�����O' if !$sp;
	print "&nbsp;&nbsp;$sp&nbsp;&nbsp;<br><br></td></tr></form></table>";
	print "</form></table>\n";
	&FOOTER;
}
sub MISSION2{
	&LOCK;&DBM_CONVERT('P',"$FORM{pname}");&DBM_INPORT('C');&UNLOCK;
	@C_VALUES = split(/\s/,$C{"$PL_VALUES[5]"});
	&ERROR if $PL_VALUES[6]!=1 || !$PL_VALUES[5] || !$C{"$PL_VALUES[5]"};
	&ERROR('ERROR',"�{�b$C_VALUES[5]�@�ԥ��b�o�ʤ�") if $C_VALUES[7] > time;
	&CUSTOM_HEADER('Main');
	print "<tr><td $BgColor align=right><br>";
	while (my($key,$val) =each %C) {
		if ($PL_VALUES[5] ne "$key"){$op.= "<option value=\"$key\">$key\n";}
	}
	&ERROR('�𲤰��٨S�����w') if !$op;
	print "<input type=hidden name=dmmy>";
	print "��O<b>\$ $C_VALUES[1]</b><br>";
	print "�Բ��O<input type=text name=sikin size=10 maxlength=10 style=\"border:none;background:#000000;text-align:right;\"><br>";
	print "�@�ԦW<input type=text name=mname size=25 maxlength=15 class=button2><br>";
	print "�Բ���H�G<select name=main $STYLE_L onChange=\"YOSAN()\">$op</select><br>";

	print "�Ĥ@�x�� $C_VALUES[2] �Բ��G<select name=u1 $STYLE_L onChange=\"YOSAN()\">$op</select><br>" if $C_VALUES[2];
	print "�ĤG�x�� $C_VALUES[3] �Բ��G<select name=u2 $STYLE_L onChange=\"YOSAN()\">$op</select><br>" if $C_VALUES[3];
	print "�ĤT�x�� $C_VALUES[4] �Բ��G<select name=u3 $STYLE_L onChange=\"YOSAN()\">$op</select><br>" if $C_VALUES[4];
	print "�Բ��ɭ��G<select name=kikan $STYLE_L onChange=\"YOSAN()\"><option value=1>2�p��<option value=2>4�p��<option value=3>6�p��</select><br>";
	print "<input name=\"Cmode\" type=\"submit\" value=\"�o��\" class=button2 onClick=\"return ChMn()\">";
	print "<script language=\"JavaScript\">\nfunction YOSAN(){\nvar mm=8000;\n";
	print "if (document.Ms.main.selectedIndex != document.Ms.u1.selectedIndex){mm+=1000;}\n" if $C_VALUES[2];
	print "if (document.Ms.main.selectedIndex != document.Ms.u2.selectedIndex){mm+=1000;}\n" if $C_VALUES[3];
	print "if (document.Ms.main.selectedIndex != document.Ms.u3.selectedIndex){mm+=1000;}\n" if $C_VALUES[4];
	print "if (document.Ms.u1.selectedIndex == document.Ms.u2.selectedIndex){mm-=1000;}\n" if $C_VALUES[2] && $C_VALUES[3];
	print "if (document.Ms.u2.selectedIndex == document.Ms.u3.selectedIndex){mm-=1000;}\n" if $C_VALUES[3] && $C_VALUES[4];
	print "if (document.Ms.u1.selectedIndex == document.Ms.u3.selectedIndex){mm-=1000;}\n" if $C_VALUES[2] && $C_VALUES[4];
	print "if (document.Ms.u1.selectedIndex != document.Ms.u2.selectedIndex && document.Ms.u1.selectedIndex != document.Ms.u3.selectedIndex){mm+=3000;}\n" if $C_VALUES[2] && $C_VALUES[3] && $C_VALUES[4];



	print << "	-----END-----";
		total=(eval(document.Ms.kikan.selectedIndex) + 1)*mm;
		document.Ms.sikin.value='\$'+total;
		document.Ms.dmmy.value=total;
		if (total > $C_VALUES[1]){document.Ms.sikin.style.color='#ffadac';}
	}
	function ChMn(){
	if (document.Ms.dmmy.value > $C_VALUES[1]){alert('�������');return false;}
	if (document.Ms.mname.value == ''){alert('�S�����w�@�ԦW');return false;}
	if (confirm('�Բ��N�n�o�ʡC\\n�A�T�{�ܡH') == true){return true;}else{return false;}

	}
	YOSAN();
	</script></td></tr></form></table>
	-----END-----
	&FOOTER;
}


sub BOSS2{
	&LOCK;&DBM_CONVERT('P',"$FORM{pname}");&DBM_CONVERT('C',"$PL_VALUES[5]");&UNLOCK;
	&ERROR if $PL_VALUES[6]==0 || !$PL_VALUES[5] || !@CL_VALUES;
	&CUSTOM_HEADER('Main');
	print "<tr><td $BgColor><br>";
	print "<b>��O�G\$ $CL_VALUES[1]</b><br>";
	print "<br>�ꤺ����ʳ��G$CL_VALUES[14]�H����. ���@�n�i�Φ���:$CL_VALUES[16] <br>";
print " <select name=ckisei $STYLE_M>\n";
foreach (1..$C_MAX_MEMBER){
print "<option value=\"$_\"";
print " selected\n"if $_ eq $CL_VALUES[14];
print ">����̤j��$_�H�";
}
print "</select> ";
print "<input name=\"Cmode\" type=\"submit\" value=\"����\" class=button2 ";
print " onClick=\"return ChMn('�ꤺ�B��ʳ��C','5000')\"><br> ";
print "</td></tr><tr><td $BgColor>";
	@Y_HP=split(/!/,$CL_VALUES[11]);
	$Y_HP[0]=$Y_HP[0]+(time-$Y_HP[2])*$HP_REPAIR*2;$Y_HP[0]=$Y_HP[1] if $Y_HP[0] > $Y_HP[1];

	@Y_ST=split(/!/,$CL_VALUES[12]);
		print "<input type=hidden name=yousaiCheck value=$DATE";
	print "<b><span style=\"font-size:20px;\">HP</span>&nbsp;&nbsp;$Y_HP[0]/$Y_HP[1]</b>&nbsp;&nbsp;&nbsp;";
	print "<input name=\"Cmode\" type=\"submit\" value=\"�^�Ф�\" class=button2 ";
	print " onClick=\"return ChMn('HP���^�С]�֡^','1000')\">";
	print "<input name=\"Cmode\" type=\"submit\" value=\"�^�Фj\" class=button2 ";
	print " onClick=\"return ChMn('HP���^�С]�j�^','10000')\">";
	if ($PL_VALUES[6] == 1){
		print "<input name=\"Cmode\" type=\"submit\" value=\"HP�j��\" class=button2 ";
		print " onClick=\"return ChMn('HP���j��','50000')\"><br><b>�����O</b>&nbsp;&nbsp;";
		print "<b style=\"color:#ff0080;\">NT</b>+$Y_ST[0]&nbsp;&nbsp;";
		print "<input name=\"Cmode\" type=\"submit\" value=\"�����O�j��\" class=button2 ";
		print " onClick=\"return ChMn('�����O���j��','10000')\"><br><b>���m�O</b>&nbsp;&nbsp;";
		print "<b style=\"color:#ff0080;\">NT</b>+$Y_ST[1]&nbsp;&nbsp;";
		print "<input name=\"Cmode\" type=\"submit\" value=\"���m�O�j��\" class=button2 ";
		print " onClick=\"return ChMn('���m�O���j��','10000')\"><br><b>�R���O</b>&nbsp;&nbsp;";
		print "<b style=\"color:#ff0080;\">NT</b>+$Y_ST[2]&nbsp;&nbsp;";
		print "<input name=\"Cmode\" type=\"submit\" value=\"�R���O�j��\" class=button2 ";
		print " onClick=\"return ChMn('�R���O���j��','10000')\"><br>";
		print "<input name=\"Cmode\" type=\"submit\" value=\"�n��Z���ɯ�\" class=button2 ";
		print " onClick=\"return ChMn('�n��Z���ɯ�','20000000')\"><br>";
	}
	print << "	-----END-----";
	<script language="JavaScript">
		function ChMn(msg,mny){
			if (mny > $CL_VALUES[1]){alert('�������');return false;}
			if (confirm(msg+'�֭p\\n�O��\$'+mny+'�^\\n�T�{�ܡH') == true){
				return true;}else{return false;}
		}
	</script>

	</td></tr></form></table>
	-----END-----
	&FOOTER;
}
sub MAKE_C2{
	&LOCK;&DBM_INPORT('C');&UNLOCK;
	&CUSTOM_HEADER('Main');
	my@C=%C;my$C=@C/2;
	if ($C >= $COUNTRY_MAX){print "<tr><td $BgColor>$COUNTRY_MAX�w�g�W�L�F���s����a�ƶq</td></tr></table>\n";
	}else{
		print << "		-----END-----";
			<tr><td $BgColor><b>�ذ�O�� \$$MAKE_COUNTRY</b><br>&nbsp;&nbsp;��a�W�r
			<input type=text name=\"cname\" size=25 maxlength=20 $STYLE_L><br>&nbsp;&nbsp;��a�C��<br>
			&nbsp;&nbsp;&nbsp;&nbsp;
			<input type=\"radio\" name=\"cl\" value=\"#C0C0C0\" checked><font color=#C0C0C0>��</font>
		-----END-----
			$br=1;
			foreach $Ccol(@COLOR){$br++;
				print "<input type=\"radio\" name=\"cl\" value=$Ccol><font color=$Ccol>��</font>\n";
				if ($br==5){print"<br>&nbsp;&nbsp;&nbsp;&nbsp;\n";$br=0;}
			}
			&JScfm(checkCountry,"�إ߰�a�A�A�T�{�ܡH");
			if ($PL_VALUES[5] eq $PRISON_NATIONALITY) {&ERROR('�A�w�Q�ɹܤ��v...�K�K');}
			print "<input name=\"Cmode\" type=submit value=�ذ� class=button2  onClick=\"if (document.Ms.cname.value!=''){if (document.Ms.cname.value.match('[&! =.,<>]') != null){alert('���n�ϥΫD�k�r�C');return false;}else{return checkCountry()}}else{alert('���ư�a�W�١C');return false;}\">\n";
			print "<input type=reset value=�M�� class=button2 ></td></tr></form></table>\n";
		}
	&FOOTER;
}
sub MAKE_T2{
	&LOCK;&DBM_CONVERT('P',"$FORM{pname}");&DBM_CONVERT('C',"$PL_VALUES[5]");&UNLOCK;
	&CUSTOM_HEADER('Main');
	if ($PL_VALUES[6] != 1 && $PL_VALUES[5]){
		if (!$PL_VALUES[28] && ($CL_VALUES[2] || $CL_VALUES[3] || $CL_VALUES[4])){
			&JScfm(checkInteam,"�[�J�����A�T�{�ܡH");
			print "<tr><td $BgColor><b>�J��</b><br>&nbsp;&nbsp;����<br>\n";
			print "&nbsp;&nbsp;&nbsp;&nbsp;<select name=inunit $STYLE_L>\n";
			for ($i=2;$i <= 4; $i++){
				if ($CL_VALUES[$i]){print "<option value=\"$CL_VALUES[$i]\">$CL_VALUES[$i]\n";}
			}
			print "</select>\n";
			print "<input name=\"Cmode\" type=submit value=\"�J��\"";
			print " class=button2  onClick=\"return checkInteam()\"></td></tr>\n";
		}elsif ($PL_VALUES[28]){
			&JScfm(checkOutteam,"���}�����A�T�{�ܡH");
			print "<tr><td $BgColor><b>����</b><br>&nbsp;&nbsp;����&nbsp;$PL_VALUES[28]\n";
			print "<input name=\"Cmode\" type=submit value=\"����\"";
			print " class=button2  onClick=\"return checkOutteam()\"></td></tr>\n";
		}
		if (!$PL_VALUES[28] && $PL_VALUES[8] >= $MAKE_TEAM && $PL_VALUES[0] >= 150 &&
			(!$CL_VALUES[2] || !$CL_VALUES[3] || !$CL_VALUES[4]) && $PL_VALUES[5]){
		print << "		-----END-----";
			<SCRIPT language="JavaScript">
			function checkUnit(){
			if (document.Ms.uname.value == ''){alert("�����W�٨S����J");return false; }
			else if (confirm('�إ߳����A�T�{�ܡH') == true){
					window.location.replace("./$MAIN_SCRIPT?LOGO");return true;
			}else{return false}
			}
			</script>
			<tr><td $BgColor><b>��������</b><br>
			&nbsp;&nbsp;<b>���߶O�� \$$MAKE_TEAM</b><br>
			&nbsp;&nbsp;&nbsp;&nbsp;�������W�r
			<input type=text name="uname" size=25 maxlength=15 $STYLE_L>
			<input name="Cmode" type=submit value="�����s��" class=button2 onClick="return checkUnit()"></td></tr>
		-----END-----
		}
	print "</form></table>\n";
	}else{print "<tr><td $BgColor><b>�٤���ϥγ������ߪ����O</b></td></tr></table>";}
	&FOOTER;
}


sub MAKE_A2{
&LOCK;&DBM_CONVERT('P',"$FORM{pname}");&DBM_CONVERT('C',"$PL_VALUES[5]");&UNLOCK;
@pair = split(/\;/, $ENV{'HTTP_COOKIE'});
foreach (@pair) {my($key, $value) = split(/=/, $_);$DUMMY{$key} = $value;}
@pairs = split(/\,/, $DUMMY{'EB'});
foreach (@pairs) {my($key, $value) = split(/\:/, $_);$COOKIE{"$key"} = $value;}
&ERROR('�S�����}COOKIE�����\��') if !$COOKIE{'pname'};
&DBM_INPORT(P);
@PL_VALUES = split(/\s/,$P{"$COOKIE{'pname'}"});
&DBM_CONVERT('C',"$PL_VALUES[5]");
&CUSTOM_HEADER('Main');
&JScfm(checkkoui,"�˳Ƥ��Z���ذe����L�Ԥh");
print "<tr><td $BgColor colspan=4>��ܧA�n�ذe����H<br><b>����@��</b><br>\n";
print "<select name=hito $STYLE_L>\n";
foreach $Key (sort {$P{$b} <=> $P{$a}} keys %P){
@VALUES = split(/\s/,$P{$Key});
if ($FORM{'pname'} ne $Key)
{print "<option value=\"$Key\">$Key\n";}
}
print "</select>\n";
print "<input type=submit name=\"Cmode\" value=\"�Z���اe\" class=button2  onClick='";
print "return checkkoui()'>" ;
print "</td></tr>";
print "</form></table>\n";
}

sub DEL_U2{
	&LOCK;&DBM_CONVERT('P',"$FORM{pname}");&DBM_CONVERT('C',"$PL_VALUES[5]");&UNLOCK;
	&CUSTOM_HEADER('Main');
	if ($PL_VALUES[6] == 1 && $PL_VALUES[5] && @CL_VALUES){
		if (!$PL_VALUES[28] && ($CL_VALUES[2] || $CL_VALUES[3] || $CL_VALUES[4])){
			&JScfm(checkInteam,"�N�ӳ����Ѵ��A�T�{�ܡH");
			print "<tr><td $BgColor><b>�Ѵ�</b><br>&nbsp;&nbsp;����<br>\n";
			print "&nbsp;&nbsp;&nbsp;&nbsp;<select name=delunit $STYLE_L>\n";
			for ($i=2;$i <= 4; $i++){
				if ($CL_VALUES[$i]){print "<option value=\"$CL_VALUES[$i]\">$CL_VALUES[$i]\n";}
			}
			print "</select>\n";
			print "<input name=\"Cmode\" type=submit value=\"�Ѵ�\"";
			print " class=button2  onClick=\"return checkInteam()\"></td></tr>\n";
		}
	print "</form></table>\n";
	}else{print "<tr><td $BgColor><b>�٤���ϥθѴ����������O</b></td></tr></table>";}
	&FOOTER;
}
sub DEL_UNIT{
&LOCK;&DBM_CONVERT('P',"$FORM{pname}");&DBM_CONVERT('C',"$PL_VALUES[5]");&UNLOCK;

@pair = split(/\;/, $ENV{'HTTP_COOKIE'});
foreach (@pair) {my($key, $value) = split(/=/, $_);$DUMMY{$key} = $value;}
@pairs = split(/\,/, $DUMMY{'EB'});
foreach (@pairs) {my($key, $value) = split(/\:/, $_);$COOKIE{"$key"} = $value;}

&ERROR('COOKIE�w�g�L���C') if !$COOKIE{'pname'};
&DBM_INPORT(P);
@PL_VALUES = split(/\s/,$P{"$COOKIE{'pname'}"});
&DBM_CONVERT('C',"$PL_VALUES[5]");

&CUSTOM_HEADER('Main');
if ($PL_VALUES[6] == 1 && $PL_VALUES[5]){
&JScfm(checkInteam,"�Ѷ����O�U�F�C�T�w�R���o�W���U�ܡH");
print "<tr><td $BgColor align=center><br>����H���Ѷ�<br>\n";
print "����<select name=delunit $STYLE_L>\n";

foreach $Key (sort {$P{$b} <=> $P{$a}} keys %P){
@VALUES = split(/\s/,$P{$Key});
if ($PL_VALUES[5] && $PL_VALUES[5] eq $VALUES[5] && $VALUES[6] ne 1)
{print "<option value=\"$Key\">$Key\n";}
}

print "</select>\n";
print "<input name=\"Cmode\" type=submit value=\"�Ѷ�\"";
print " class=button2  onClick=\"return checkInteam()\"></td></tr>\n";

print "</form></table>\n";

}else{print "<tr><td $BgColor><b>�Ѷ��ϥΡC</b></td></tr></table>";}
&FOOTER;
}
sub COMMENT {
	&CUSTOM_HEADER('Main');
	&JScfm(checkComment,"�۰ꪺ�o���ܧ�H�H");
	&JScfm(checkBaCom,"�԰����x���ܧ�H�H");
	&JScfm(checkHiCom,"�����ަW�ܧ�H");
	&JScfm(checkCiCom,"�W�����ަW�ܧ�H");
	print << "	-----END-----";

	<tr><td $BgColor><b>�۰�o���ܧ�</b><br>
	&nbsp;&nbsp;<input type="text" name="com" size="70" maxlength="100" value="" $STYLE_L><br>
	&nbsp;&nbsp;<span style="font-size:13px;">�۰�o���J��B�������u�ܧ�v���so�C
	</span><br>
	&nbsp;&nbsp;<input name="Cmode" type="submit" value="�ܧ�" class=button2  onClick=\"return checkComment()\">
	&nbsp;&nbsp;<input type="reset" value="�M��" class=button2 ><BR>

	<b>�԰��x���ܧ�</b><br>
	&nbsp;&nbsp;<input type="text" name="bacom" size="70" maxlength="100" value="" $STYLE_L><BR>
	&nbsp;&nbsp;<span style="font-size:13px;">�԰��x���ܧ󤧫�B�������u�x�� �v���s�C
	</span><br>
	&nbsp;&nbsp;<input name="Cmode" type="submit" value="�x��" class=button2  onClick=\"return checkBaCom()\">
	&nbsp;<input type="reset" value="�M��" class=button2 ><br>

	<b>�����ަW</b><br>
	&nbsp;&nbsp;<input type="text" name="hicom" size="70" maxlength="100" value="" $STYLE_L><BR>
	&nbsp;&nbsp;<span style="font-size:13px;">�����ޤJ��B�������u�����v���s�C
	</span><br>
	&nbsp;&nbsp;<input name="Cmode" type="submit" value="����" class=button2  onClick=\"return checkHiCom()\">
	&nbsp;<input type="reset" value="�M��" class=button2 ><br>

	<b>�W�����ަW</b><br>
	&nbsp;&nbsp;<input type="text" name="cicom" size="70" maxlength="100" value="" $STYLE_L><BR>
	&nbsp;&nbsp;<span style="font-size:13px;">�W�����ަW�J�O����u�W���v���s�C</span><br>
	&nbsp;&nbsp;<input name="Cmode" type="submit" value="�W��" class=button2  onClick=\"return checkCiCom()\">
	&nbsp;<input type="reset" value="�M��" class=button2 ><br>
	</td></tr></form></table>

	-----END-----
	&FOOTER;
}
sub MAKE_K2{
&LOCK;&DBM_CONVERT('P',"$FORM{pname}");&DBM_CONVERT('C',"$PL_VALUES[5]");&UNLOCK;
@pair = split(/\;/, $ENV{'HTTP_COOKIE'});
foreach (@pair) {my($key, $value) = split(/=/, $_);$DUMMY{$key} = $value;}
@pairs = split(/\,/, $DUMMY{'EB'});
foreach (@pairs) {my($key, $value) = split(/\:/, $_);$COOKIE{"$key"} = $value;}
&ERROR('COOKIE  �oi�C') if !$COOKIE{'pname'};
&DBM_INPORT(P);
@PL_VALUES = split(/\s/,$P{"$COOKIE{'pname'}"});
&DBM_CONVERT('C',"$PL_VALUES[5]");
&CUSTOM_HEADER('Main');
&JScfm(checkkoui,"�n����������O�H�H�H");
print "<tr><td $BgColor colspan=4>�ǳƧ���������֩O�O�H<br><B>����@�� </B><BR>\n";
print "<select name=atotugi $STYLE_L>\n";
foreach $Key (sort {$P{$b} <=> $P{$a}} keys %P){
@VALUES = split(/\s/,$P{$Key});
if ($VALUES[5] eq $PL_VALUES[5] && $FORM{'pname'} ne $Key)
{print "<option value=\"$Key\">$Key\n";}
}
print "</select>\n";
print "<input type=submit name=\"Cmode\" value=\"�~��\" class=button2  onClick='";
print "return checkkoui()'>";
print "</td></tr>";
}
sub FACE_C{
	&LOCK;&DBM_CONVERT('P',"$FORM{pname}");&UNLOCK;
	&CUSTOM_HEADER('Main');
	print "<script language=\"JavaScript\">\nfunction changeImg(){num=document.Ms.icon.value;document.msImg.src=\"$IMG_FOLDER3/\"+ num +\".gif\";}\n</script>";
	&JScfm(checkface,"�n���y�СA�T�w�ܡH");
	print "<tr><td $BgColor colspan=4><b>��ܧA���w���y�Чa</b><br>&nbsp;&nbsp;$20000<br>\n";
	print "&nbsp;&nbsp;&nbsp;&nbsp;<img src=\"$IMG_FOLDER3/$PL_VALUES[100].gif\" name=\"msImg\">&nbsp;&nbsp;<a href=ebs.cgi?ICON2 target=face><font size=4>�y�йϮw</font></a><br>\n";
	print "&nbsp;&nbsp;<select name=icon $STYLE_L onChange=\"changeImg()\">\n";
	foreach (0..$ICON2){
		print "<option value=\"$_\"";
		print " selected\n"if $_ eq $PL_VALUES[100];
		print ">ICON No.$_\n";
	}
	if ($SPECIAL_ICON2 == 1 && $PL_VALUES[16] >= 40000)
    {$_='';
    foreach (200..$ICON4){
        print "<option value=\"$_\"";
        print " selected\n"if $_ eq $PL_VALUES[100];
        print ">ICON No.$_\n";
    }}
	print "<div align=right>\n";
	print "<input name=\"Cmode\" type=submit value=\"�y���ܧ�\" class=button2 onClick='";
	print "return checkface()'>" ;
	print "</div></td></tr>\n";

}
sub BOUGU2 { 
&CUSTOM_HEADER('Main'); 
require "$LOG_FOLDER/_bougu.data"; 
&LOCK;&DBM_CONVERT('P',"$FORM{pname}");&UNLOCK; 
local($BG_A) = split(/!/,$PL_VALUES[41]); 
@BG_sA=split(/\,/,$BOUGU_LIST{"$BG_A"}); 
$Pl_BOUGUNameA="$BG_sA[0]"; 
if ($BG_sA[0]){ 
$PartofSB.="<option value=1>$Pl_BOUGUNameA" if $BG_sA[0]; 
print "<SCRIPT language=\"JavaScript\">\nfunction checkMoney (){\n"; 
print "num=document.Ms.sellb.value;\nif (num==1){var bn='$Pl_BOUGUNameA';var mn='".int($BG_sA[5]/3)."';}\n"; 
print "if (confirm(bn + '\$' + mn + '��X') == true){\n"; 
print "window.location.replace(\"./dummy.html\");return true;}else{return false}\n"; 
print "}\n</script>\n<tr><td $BgColor><b>���U�˸m�X��</b><div align=right><select name=sellb $STYLE_L>"; 
print "$PartofSB</select><input type=submit name=Cmode value=���U�˸m�X�� "; 
print "$STYLE_B1 onClick=\"return checkMoney()\"></div></td></tr>"; 
} 
if (!$BG_sA[0]){ 
print "<tr><td $BgColor><b>���U�˸m�ʤJ</b><table style=\"font-size:9pt;\">\n"; 
&JScfm(checkBuy,"�̩w?"); 
local($Flag=0); 
$buy="<select name=buyb $STYLE_L>"; 
while (my($key,$value) = each %BOUGU_LIST){ 
if (length($key) == 1){ 
my @ByB = split(/\,/,$value); 
if($ByB[5] <= $PL_VALUES[8] && $ByB[8] != 1 && $ByW[8] != 4 && $ByW[8] != 5){ 
print "<tr><td>  $ByB[0]</td><td>\$$ByB[5]</td></tr>"; 
$buy.="<option value=$key>$ByB[0]\n";$Flag++;} 
} 
} 
if ($Flag>0){$buy.="</select><input name=\"Cmode\" type=submit value=���U�ʤJ 
$STYLE_B1 onClick=\"return checkBuy()\">\n";}else{$buy="�ҫ����B�����C";$Flag++;} 
print "</table><div align=right>$buy</div></td></tr>\n"; 
} 
if (!$PL_VALUES[41] && $Flag==0 && $WeCH ==0){ 
print "<tr><td $BgColor>�i��T�w�C</td></tr>\n";} 
print "</form></table>\n";&FOOTER; 
} 

1;