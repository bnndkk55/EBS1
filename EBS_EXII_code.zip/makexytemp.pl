#!/usr/bin/perl
#���L���a�I���ӱN��Ʈ���
require "ebs_sub1.cgi";
require "debug_sub.pl";
print "Content-type: text/html;\n\n";

$i=0;$j=0;
$writemapxy="";
open(WRITEFILE,">maptemp.txt") || die $!;

foreach(0..49)
{
foreach(0..49)
{
$writemapxy="$i,$j,��a,�L\n";
print WRITEFILE $writemapxy;

$j++;
}
$i++;
$j=0;
}	
close(WRITEFILE);

print "ok";
1;