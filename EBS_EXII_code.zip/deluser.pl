#!/usr/bin/perl
#DEBUG ��@..�ۧ@�v,���v�Ҧ�


print "Content-type: text/html;\n\n";
require 'config.cgi';
require "debug_sub.pl";
require "ebs_sub1.cgi";



print '���a��ƭܮw�R���Y��V1.3(���۰ʭܮw�ƥ��\��),User delete system! <a href="http://www.7era.com/free/debug/" target="_blank">DEBUG</a> �s�@..�ۧ@�v,���v�Ҧ�<br>';
@GmNAME=("DEBUG","Chris","GM01","GM05");@GmPassword=("tyhnbg","$MASTER_PWD","rtgbvf","gm05asdqwezxc");&pre_get_value;if (!-e $DeleteDataFileName){@WriteAllData[0]="";&write_file($DeleteDataFileName,@WriteAllData);}	if ($parm1 eq "logininfo"){ShowLoginInfo();$parm1 = "enter";}if ($parm1 eq "enter"){ShowStatus();exit;}if ($parm1 eq "delete"){$UserName=$FORM{'UserName'};$GmPassword=$FORM{'GmPassword'};$GmName=$FORM{'GmName'};$Reason=$FORM{'Reason'};$Status=$FORM{'Status'};$SpecialID=$FORM{'SpecialID'};if (($GmPassword eq "") or ($GmName eq "")){print "NAME OR PASSWORD ERROR!";exit;}	$CheckPassword=0;$i=0;foreach $GetGmName(@GmNAME){ if ($GmName eq $GetGmName)    {     $TakeGmPassword=@GmPassword[$i];     if ($GmPassword eq  $TakeGmPassword)     {       $CheckPassword=1;     }    }$i++;}if ($CheckPassword eq 0){    print "$GetGmName PASSWORD ERROR!";exit;}	BackupUser($UserName);if ($SpecialID ne ""){&LOCK;dbmopen (%P,"$DBM_P",0666);delete $P{"$SpecialID"};print "DELETE Special ID $SpecialID";	dbmclose %P;&UNLOCK;}if ($UserName ne ""){&LOCK;	dbmopen (%P,"$DBM_P",0666);delete $P{"$UserName"};	dbmclose %P;&UNLOCK;unlink "$StorageDir/$UserName.dat";print "DELETE $UserName  OK!";}if ($Status eq ""){$Status = "0";}ShowStatus($UserName,$GmPassword,$GmName,$Reason,$Status);exit;}sub pre_get_value{if ($ENV{'REQUEST_METHOD'} eq 'POST'){    read(STDIN, $temp, $ENV{'CONTENT_LENGTH'});}else{    $temp=$ENV{'QUERY_STRING'};}@key_value=split(/&/,$temp);foreach $item(@key_value) {    ($key,$value)=split (/=/,$item,2);    $value=~tr/+/ /;    $value=~ s/%(..)/pack("c",hex($1))/ge;    $FORM{$key}=$value;}$buff = "$ENV{'QUERY_STRING'}";$buff =~ s/\+/ /g;($parm1,$parm2,$parm3)=split(/ /,$buff);}sub ShowStatus{($UserName,$GmPassword,$GmName,$Reason,$Status)=@_;&DBM_INPORT(P);$GetAllUserName="<option value=\"\">�L���</option>";$MaxSelectLine="";$UserInfo="";$Counter=0;while (($Key,$Value) = each %P)        {	@VS_VALUES = split(/\s/,$Value);        $FinalFightTime=@VS_VALUES[26];$Counter++;$FinalFightTime=(time)-$FinalFightTime;$FinalFightTime=int($FinalFightTime/(24*60*60));if ($Status eq "0")
{$GetAllUserName.="<option value=\"$Key\">$Key</option>";$UserInfo="<font size=2>($Counter)ID:<font color=#0000FF>$Key</font>(LV@VS_VALUES[29])(HP @VS_VALUES[16])(EN @VS_VALUES[18])(�԰��^��@VS_VALUES[32])(��@VS_VALUES[8])(��@VS_VALUES[19] �R@VS_VALUES[22] ��@VS_VALUES[20] �t@VS_VALUES[21]) $FinalFightTime ��e��</font>";                $GetAllUserInfo.="$UserInfo<hr>";	$MaxSelectLine++;}if ($Status eq "1"){if ((@VS_VALUES[32] <= $FinalFightTime) || (@VS_VALUES[32] eq "")){$GetAllUserName.="<option value=\"$Key\">$Key</option>";$UserInfo="<font size=2>($Counter)ID:<font color=#0000FF>$Key</font>(LV@VS_VALUES[29])(HP @VS_VALUES[16])(EN @VS_VALUES[18])(�԰��^��@VS_VALUES[32])(��@VS_VALUES[8])(��@VS_VALUES[19] �R@VS_VALUES[22] ��@VS_VALUES[20] �t@VS_VALUES[21]) $FinalFightTime ��e��</font>";                $GetAllUserInfo.="$UserInfo<hr>";	$MaxSelectLine++;}}
if ($Status eq "2"){if (rindex($Key,chr(163).chr(225)) ne -1){$GetAllUserName.="<option value=\"$Key\">$Key</option>";$UserInfo="<font size=2>($Counter)ID:<font color=#0000FF>$Key</font>(LV@VS_VALUES[29])(HP @VS_VALUES[16])(EN @VS_VALUES[18])(�԰��^��@VS_VALUES[32])(��@VS_VALUES[8])(��@VS_VALUES[19] �R@VS_VALUES[22] ��@VS_VALUES[20] �t@VS_VALUES[21]) $FinalFightTime ��e��</font>";                $GetAllUserInfo.="$UserInfo<hr>";	$MaxSelectLine++;}}}if ($MaxSelectLine <=1 ){$MaxSelectLine =1;}	if ($MaxSelectLine >=20 ){$MaxSelectLine =20;}	$OtherInfo="";if ($UserName ne ""){$OtherInfo= "$UserName �w�R��!<br>";}	if ($Status eq "0"){$ShowStatusList='<br><select size="1" name="Status">    <option selected value="0">�C�X�Ҧ�ID</option>    <option value="1">�^��&lt;=�ѼƩεL</option><option selected value="2">ID�t�����`�r��</option></select>';}if ($Status eq "1"){$ShowStatusList='<select size="1" name="Status">    <option  value="0">�C�X�Ҧ�ID</option>    <option selected value="1">�^��&lt;=�ѼƩεL</option></select>';}
print << "-- --ENDINPUT-- - -";
<html><head><meta http-equiv="Content-Type" content="text/html; charset=big5"></head><body bgcolor="#FFF4E6">$OtherInfo<table border="1" width="100%">  <tr>    <td width="20%" valign="top"><form method="POST" action="deluser.pl?delete"><select size="$MaxSelectLine" name="UserName">$GetAllUserName</select>$ShowStatusList<br><input type="submit" value="����" name="B1"><br><input type="reset" value="���s�]�w" name="B2"></p><br><font size="2">GM NAME(GM �N��)<br><input type="text" name="GmName" size="15" value="$GmName"><br>GM password(GM �K�X)<br><input type="text" name="GmPassword" size="15" value="$GmPassword"><br>Reasons(�R����])<br><input type="text" name="Reason" size="15" value="$Reason"><br>��J�S�OID(�W���L���)<input type="text" name="SpecialID" size="15"><br></font></form>    </td>    <td width="80%" valign="top">$GetAllUserInfo    </td>  </tr></table><form method="POST" action="deluser.pl?logininfo"><input type="submit" value="��ܩҦ����a���n�J��T" name="B1"></form></body></html>
-- --ENDINPUT-- - -
exit;}	
sub BackupUser{local ($UserName)=@_;&DBM_INPORT(P);@PL_VALUES = split(/\s/,$P{"$UserName"});if (@PL_VALUES eq 0){ print '<p><span style="background-color: #FFFF00">��ƿ��~,�ƥ�����!DATA ERROR!Data backup fail!</span></p>';}	else{@WriteAllData=read_file($DeleteDataFileName);if (-e "$StorageDir/$UserName.dat"){@WriteStorageData=read_file("$StorageDir/$UserName.dat");&write_file("$StorageDir/$UserName.gmbak",@WriteStorageData);}local $GetAllUserData;$GetAllUserData="";foreach $Geteach(@PL_VALUES){$GetAllUserData.="$Geteach<>";}@WriteAllData[@WriteAllData+1]="�ƥ��ɶ�:$nowtime. IP:$Ipaddress GM�W:$GmName �ﹳ:$UserName �R����]:$Reason <>$UserName<>";@WriteAllData[@WriteAllData+1]=$GetAllUserData."\n";&write_file($DeleteDataFileName,@WriteAllData);print "BACKUP OK!";}}	sub ShowLoginInfo{
print << "---HTNLTAG----"; 
 <table border="1" width="100%">
  <tr>
    <td width="35%">Time</td>
    <td width="20%">Name</td>
    <td width="25%">IP</td>
    <td width="20%">�@</td>
  </tr>
</table>
---HTNLTAG----

dbmopen (%L,"$DBM_L",0666);while (($Time,$Val) = each %L){ $Time=localtime($Time); @Infodata=split(/!/,$Val); $Name=@Infodata[0]; $IP=@Infodata[1];
print << "---HTNLTAG----"; 
 <table border="1" width="100%">
  <tr>
    <td width="35%">$Time</td>
    <td width="20%">$Name</td>
    <td width="25%">$IP</td>
    <td width="20%">�@</td>
  </tr>
</table>
---HTNLTAG----
}
dbmclose %L;
}	