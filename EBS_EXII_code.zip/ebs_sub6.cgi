$to='l';$o=time;
require "debug_sub.pl";
#################################
#	�s�Τ���U�n��		#
#	www.ltb.idv.tw	#
#################################
sub ENTRY2 {
	$Counter2=0;
	dbmopen (%P,"$DBM_P",0666);
	delete $P{""};
	dbmclose %P;

	dbmopen (%P,"$DBM_P",0666);
	while (($Name,$Val) = each %P)
	{
		@VALUES = split(/\s/,$Val);
		
		if ($VALUES[26] && $VALUES[26] < time-(86400*$COOKIE_KEEP) && $VALUES[6]==0)
		{
		if ($VALUES[5] ne $KeepAccountCountry)
		{
		delete $P{"$Name"};
		unlink "$StorageDir/$Name.dat";
		$TodayDeletedID.="$Name.";
		}
		$Counter2++;
		}
		else{$CountPl++;}

	}

	if ($TodayDeletedID ne "") 
	{
         dbmopen (%DH,"$DBM_H",0666);
         if ($TodayDeletedID ne ""){$DH{"$DATE"}="<font color=\"blue\">�������w�Q�RID:$TodayDeletedID</font>";}
         dbmclose %DH;
         }		


		dbmclose %P;

		$DiePeople=$Counter2-$CountPl;
		$DiepeopleMsg="";
		if ($DiePeople >0)
		{
                 $DiepeopleMsg="�@��$DiePeople�۱��̩|���M��";
                }			
	if (($CountPl >= $ENTRY_MAX) || ($Counter2 >= $ENTRY_MAX)){&ERROR('�W�L�F�n���H�ƪ����B'.$DiepeopleMsg); exit;}

	&DBM_INPORT(C);
	require "$LOG_FOLDER/$HASH_DATA";
	
	&HEADER2;
	
	print << "	-----END-----";

	<script language="JavaScript">
		function changeImg(){
			num=document.entry.imgSelect.selectedIndex;
			document.msImg.src="$IMG_FOLDER2/"+ num +".gif";
		}
		function checkRiyou (){
			if (document.entry.pname.value == '') {window.alert("�Τ�W�S����J");return false
			}else if(document.entry.msname.value == '') {window.alert("����W�S����J");return false
			}else if(document.entry.pass.value == '') {window.alert("�K�X�٨S����J");return false
			}else if(document.entry.pname.value.match('[&! =.,<>]') != null) {
				window.alert("�A�ϥΤF�b���Ÿ��Ϊ̨䥦�A�д��@�Ӧr��");return false ;
			}else if(document.entry.msname.value.match('[&! =.,<>]') != null) {
				window.alert("�A�ϥΤF�b���Ÿ��Ϊ̨䥦�A�д��@�Ӧr��");return false ;
			}else if(document.entry.pass.value.match('[&! =.,<>]') != null) {
				window.alert("�A�ϥΤF�b���Ÿ��Ϊ̨䥦�A�д��@�Ӧr��");return false ;
			}else {if (confirm('�n���T�{') == true){return true;}else{return false}	}
		}
	</script>
	<style type="text/css">
		.td1{text-align:center;background-color:#909090;font-weight:bold;font-size:16px;color:#404040;}
	</style>
	<table width=100% height=100%><tr><td $center>
	<img src=$IMG_FOLDER4/logo_new.gif>
	</td></tr><tr><td $center>
	<form action=$MAIN_SCRIPT method=POST name=entry>
	<input type=hidden name=cmd value=KAKUNIN>
	<table $tb_stl>
	<tr><td>�Τ�W</td>
	    <td><input type=text name=pname size=15 maxlength=15 $STYLE_L>
	    <font style="font-size:12px;">�п�J�Τ�W</font></td>
	<td $middle rowspan=7><img src=\"$IMG_FOLDER2/1.gif\" name=\"msImg\" height=140 width=114></td>
	</tr>
	<tr><td>����W</td><td><input type=text name=msname size=15 maxlength=20 $STYLE_L> �п�J����W</td></tr>
	<tr><td>�Τ�K�X</td><td><input type=password maxlength=8 name=pass size=15 $STYLE_L>
	    <font style="font-size:12px;">�Τ�K�X<font color=red><b>�b��</b></font>�̦h8�Ӧr��</font></td></tr>
    <tr><td>��ܾԤh</td><td><select name=imgSelect $STYLE_L onChange=\"changeImg()\">
	-----END-----
	foreach (0..$ICON){
		print "<option value=\"$_\">&nbsp;ICON No.$_\n";
		}
	print << "	-----END-----";
	</select> <a href="$MAIN_SCRIPT?ICON" target="_blank"><font color=#FFFFFF size=2>�Ԥh�Ϯw</font></a></td></tr>
	<tr><td>�����ݩ�</td><td><select name=type $STYLE_L>
	<option value=1>&nbsp;�����O����&nbsp;<option value=2>���m�O����<option value=3>�^�ײv����
	<option value=4>�R���v����<option value=0>������</select></td></tr>
	<tr><td>�ʮ� </td><td><select name=chara $STYLE_L>
	<option value=0>����<br><option value=1>�z��<br><option value=2>����<br>
	<option value=3>�E��<br><option value=4>�N�R<br><option value=5>�N��</select></td></tr>
	<tr><td>�Z��</td><td><select name=w $STYLE_L>
	-----END-----
	while (my($wkey,$wvalue) =each %WEAPON_LIST) {
		if (length($wkey) == 1){my@w=split(/,/,$wvalue);
		print "<option value=$wkey>$w[0]\n" if (($wkey ne "y") && ($wkey ne "x") && ($wkey ne "u") && ($wkey ne "t") && ($wkey ne "3")&& ($wkey ne "4")&& ($wkey ne "5"));}
	}

	print "</select> <a href=\"$MAIN_SCRIPT?WEAPON\" target=\"_blank\"><font color=#FFFFFF size=2>�Z�����</font></a></td></tr><tr><td>�C ��</td>";
	print "<td colspan=2><input type=radio name=cl value=#FFFFFF checked><font color=#FFFFFF>��</font>\n";
		$br=1;
		foreach (@COLOR){$br++;
			print "<input type=\"radio\" name=\"cl\" value=$_><font color=$_>��</font>\n";
		if ($br==10){print"<br>\n";$br=0;}
		}
	print "</td></tr><tr><td>���y<td colspan=2>\n";
	print "<select size=1 name=\"kuni\" $STYLE_L>\n";
	&DBM_INPORT(P);
while (($key,$value) =each %C) {
@C_VALUES = split(/\s/,$value);
my $c_cnt = 0;
while(my($m_key,$m_value) = each %P){
my@MEMBER_VALUE = split(/\s/,$m_value);
if($key eq "$MEMBER_VALUE[5]" && ++$c_cnt >= $C_VALUES[14]){
last;
}
}%P=%P;
if($c_cnt < $C_VALUES[14]){print "<option value=$key>$key\n";}
}
	print "<option value=\"\">�ۥѾԤh";
	print << "	-----END-----";
		</select></td></tr>
			<tr><td colspan=3 align="center">
			<input type=submit value=�n�� class=button2  onClick="return checkRiyou()">
			<input type=reset value=�M�� class=button2 >
		    </td></tr></table></td></tr><tr><td align=center>
	-----END-----
	&FOOTER;
	print "</td></tr></form></body>";
}

#################################
#	����ƾڽT�w�n��	#
#################################
sub KAKUNIN2 {

	$Counter2=0;
	dbmopen (%P,"$DBM_P",0666);
	while (($Name,$Val) = each %P){
		@VALUES = split(/\s/,$Val);
		if ($VALUES[26] && $VALUES[26] < time-(86400*$COOKIE_KEEP) && $VALUES[6]==0){
			delete $P{"$Name"};
		$Counter2++;
		}else{$CountPl++;}
	}
		dbmclose %P;

		$DiePeople=$Counter2-$CountPl;
		$DiepeopleMsg="";
		if ($DiePeople >0)
		{
                 $DiepeopleMsg="�@��$DiePeople�۱��̩|���M��";
                }			
	if (($CountPl >= $ENTRY_MAX) || ($Counter2 >= $ENTRY_MAX)){&ERROR('�W�L�F�n���H�ƪ����B'.$DiepeopleMsg); exit;}

	&DBM_INPORT(C);
	require "$LOG_FOLDER/$HASH_DATA";
	#if ($CountPl >= $ENTRY_MAX){&ERROR('�W�L�F�n���H�ƪ����B'); exit;}



	&LOCK;
	&DBM_INPORT(P);
	&UNLOCK;


        @DisableUser=read_file($DisableUserFileName);
	chop (@DisableUser);
	foreach $GetDisableName(@DisableUser)
	{
         if ($GetDisableName eq $FORM{'pname'}) {&ERROR('�o�ӥΤ�W�w�g�Q�T�ΡA�п�ܨ䥦�Τ�W');}
        }		
	
	if($P{"$FORM{'pname'}"}){&ERROR('�o�ӥΤ�W�w�g���H�ϥΡA�п�ܨ䥦�Τ�W'); }
	if (!$FORM{'pname'} && !$FORM{'msname'} && !$FORM{'pass'}) { &ERROR('�Ч��������ﶵ'); }
	if (length($FORM{'pname'}) >= 30 or length($FORM{'msname'}) >= 30){&ERROR('�Τ�W�Ϊ̾���W�ٶW�L�W�w����');}

        &record_register_ip($FORM{'pname'},"");
	&HEADER2;
	print << "	-----END-----";
	<style type="text/css">
		.td1{text-align:center;background-color:#909090;font-weight:bold;font-size:16px;color:#404040;}
	</style>
	<script language="JavaScript">
	function checkEntry(){if(confirm('�n���W�M�K�X�T�{����') == true){return true;}else{return false}
	}
	</script>
	<table width=100% height=100%><tr><td $center>
	<img src=$IMG_FOLDER4/logo_wars.gif>
	</td></tr><tr><td $center>
	<table $tb_stl><tr><td style="font-size:16px;">�Τ�W</td>
	<td style="font-size:16px;">$FORM{'pname'}�]�Ф��n�ѰO�F�^</td></tr>
	<tr><td>�Τ�K�X</td>
	<td style="font-size:16px;">$FORM{'pass'}�]�Ф��n�ѰO�F�^</td></tr>
	<tr><td>�� �y</td>
	<td style="font-size:16px;">$FORM{'kuni'}</td></tr>
	<tr><td style="font-size:16px;">�Y ��</td>
	<td><img src=\"$IMG_FOLDER2/$FORM{'imgSelect'}.gif\"><font color=\"$FORM{'cl'}\">$FORM{'msname'}</font>
	</td></tr></table>
	<form action=$MAIN_SCRIPT method=POST target=\"_top\">
	<input type=hidden name=cmd value=RESIST>
	<input type=hidden name=pname value=$FORM{'pname'}>
	<input type=hidden name=msname value=$FORM{'msname'}>
	<input type=hidden name=msImg value=$FORM{'imgSelect'}>
	<input type=hidden name=pass value=$FORM{'pass'}>
	<input type=hidden name=kuni value=$FORM{'kuni'}>
	<input type=hidden name=type value=$FORM{'type'}>
	<input type=hidden name=w value=$FORM{'w'}>
	<input type=hidden name=chara value=$FORM{'chara'}>
	<input type=hidden name=cl value=$FORM{'cl'}>
	<p align=center><input type=submit value=�n�� class=button2  onClick=\"return checkEntry()\">
	</form>
	<form action="$MAIN_SCRIPT?ENTRY" method=POST>
	<input type=submit value=���s���U class=button2 ></form>
	</td></tr><tr><td $center>
	-----END-----
	&FOOTER;
	print "</td></tr></form></body>";
}
sub RESIST2 {
	$ST5=(int(rand(10)+1)*100)+1000;$ST6=(int(rand(10))*5)+100;
	$ST1=int rand(5)+3;$ST2=int rand(5)+3;$ST3=int rand(5)+3;$ST4=int rand(5)+3;
		if ($FORM{'type'} == 1){$ST5+=2500;$ST1+=2;$ST6+=50;}
 elsif ($FORM{'type'} == 2){$ST5+=3000;$ST2+=2;$ST6+=40;}
 elsif ($FORM{'type'} == 3){$ST5+=2000;$ST3+=2;$ST6+=50;}
 elsif ($FORM{'type'} == 4){$ST5+=2500;$ST4+=2;$ST6+=60;}
 elsif ($FORM{'type'} == 0){$ST5+=2000;$ST6+=40;}
	&LOCK;
	if($FORM{'kuni'} ne ''){
my$c_cnt = 0;&DBM_INPORT(P);
while(my($key,$value) = each %P){
my@MEMBER_VALUE = split(/\s/,$value);
if($FORM{'kuni'} eq "$MEMBER_VALUE[5]" && ++$c_cnt >= $C_MAX_MEMBER){
$FORM{'kuni'}='';
last;
}
}
}
		$pwd=crypt "$FORM{'pass'}",eb;
	dbmopen (%PL,"$DBM_P",0666);
		$PL{"$FORM{'pname'}"} = ("1 $DATE $pwd $FORM{'msname'} $FORM{'type'} $FORM{'kuni'} 0 noComment 0 $FORM{'w'}!0!a   $FORM{'chara'} $FORM{'cl'} 0 $ST5 $ST5 $ST6 $ST6 $ST1 $ST2 $ST3 $ST4 0 0 0 $DATE $FORM{'msImg'}  1 0");###�Z����y�s�W
	dbmclose (%PL);
	&UNLOCK;



@pair = split(/;/, $ENV{'HTTP_COOKIE'});
foreach (@pair) {my($key, $value) = split(/=/, $_);$DUMMY{$key} = $value;}
@pairs = split(/,/, $DUMMY{EB});
foreach (@pairs) 
{
my($key, $value) = split(/:/, $_);
$COOKIE{$key} = $value;
}


	SET_COOKIE:{
		my @gmt = gmtime(time + $COOKIE_KEEP*24*60*60);
		$gmt[0] = sprintf("%02d", $gmt[0]);	$gmt[1] = sprintf("%02d", $gmt[1]);
		$gmt[2] = sprintf("%02d", $gmt[2]);	$gmt[3] = sprintf("%02d", $gmt[3]);	$gmt[5] += 1900;
		$gmt[4] = ('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')[$gmt[4]];
		$gmt[6] = ('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday')[$gmt[6]];
		my $date_gmt = "$gmt[6], $gmt[3]\-$gmt[4]\-$gmt[5] $gmt[2]:$gmt[1]:$gmt[0] GMT";
		my $cook = "pname:$FORM{'pname'},pass:$FORM{'pass'},passname:$FORM{'pname'}($Ipaddress)$COOKIE{'passname'}";
		print "Set-Cookie: EB=$cook; expires=$date_gmt\n";
	}


if ($COOKIE{'passname'})
{
if (!-e "$EventRecordDir/muiltuserec.txt")
{
@WriteAllData[0]="";
&write_file("$EventRecordDir/muiltuserec.txt",@WriteAllData);
}	

@tasvalue=read_file("$EventRecordDir/muiltuserec.txt");
$tasi=@tasvalue;
if ($tasi > 220)
{
@tasvalue[0]="$FORM{'pname'}($Ipaddress)$COOKIE{'passname'}\n@tasvalue[0]\n";
@tasvalue[220]="";
}
else
{
@tasvalue[0]="$FORM{'pname'}($Ipaddress)$COOKIE{'passname'}\n@tasvalue[0]\n";
}	
write_file("$EventRecordDir/muiltuserec.txt",@tasvalue);
}

print "Location: $MAIN_SCRIPT" . "\n\n";


}
sub DELETE4 {
	&HEADER2;
	@pair = split(/;/, $ENV{'HTTP_COOKIE'});
		foreach (@pair) {my($key, $value) = split(/=/, $_);$DUMMY{$key} = $value;}
	@pairs = split(/,/, $DUMMY{EB});
		foreach (@pairs) {my($key, $value) = split(/:/, $_);$COOKIE{$key} = $value;}
	print << "	-----END-----";
	<script language="JavaScript">
		function checkRiyou (){
			if (document.del.pname.value == '') {window.alert("ID�S����J");return false
			}else if(document.del.pass.value == '') {window.alert("PASS�S����J");return false
			}else {if (confirm('�n���W�R��') == true){return true;}else{return false}	}
		}
	</script>
		<table width=100% height=100%><tr><td align=center>
		<table bgcolor=#000000 border=0 style="font-size:12px;">
			<tr><td colspan=2 bgcolor=#646464 align=center><img src=\"$IMG_FOLDER1/w.gif\"></td></tr>
			<tr><td colspan=2 bgcolor=#000000>�n���W�R��<br>
			�n���W�R���H��L�k��_<br><br></td></tr>
			<tr><td align=right style="height:21px; color:#ffffff; font-size:16px;">�W��<br>�K�X</td>
				<td style="height:21px; color:#ffffff; font-size:16px;">
					<form action=$MAIN_SCRIPT method=POST target=_top name=del onSubmit="return checkRiyou()">
					<input type=hidden name=cmd value=DELETE>
					<input type=text size=20 name=pname value="$COOKIE{'pname'}" $STYLE_L><br>
					<input type=password size=15 name=pass value="$COOKIE{'pass'}" $STYLE_L>
					</td></tr>
			<tr><td colspan=3><br><br>�T�w�R���ܡH<div align=center>
				<input type=submit value=\"�R��\" class=button2 ></div>
			</td></tr>

		</table>
	-----END-----
	&FOOTER;
	print "</td></tr></table></form></body>";
}
sub DELETE3{
	$FlagE=0;



	&LOCK;
		dbmopen (%P,"$DBM_P",0666);
			@PL_VALUES = split(/\s/,$P{"$FORM{'pname'}"});
			$FlagE=1 if !$P{"$FORM{'pname'}"};
			$FlagE=1 if (crypt("$FORM{'pass'}",eb) ne "$PL_VALUES[2]");
	               # $testpass=crypt("$FORM{'pass'}",eb);
	               # &ERROR('Error',"$testpass..$PL_VALUES[2]\\n");
			delete $P{"$FORM{'pname'}"} if !$FlagE;
		dbmclose %P;
	&UNLOCK;
        &record_fight(""," ","$FORM{'pname'} �b���Φ۱��R�� ")  if !$FlagE;
	&ERROR('Error',"COOKIE�i��}�l\�L�k�~��B�z\\n�R���L�{���_") if $FlagE==1;

	SET_COOKIE:{
		my @gmt = gmtime(time + $COOKIE_KEEP*24*60*60);
		$gmt[0] = sprintf("%02d", $gmt[0]);	$gmt[1] = sprintf("%02d", $gmt[1]);
		$gmt[2] = sprintf("%02d", $gmt[2]);	$gmt[3] = sprintf("%02d", $gmt[3]);	$gmt[5] += 1900;
		$gmt[4] = ('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')[$gmt[4]];
		$gmt[6] = ('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday')[$gmt[6]];
		my $date_gmt = "$gmt[6], $gmt[3]\-$gmt[4]\-$gmt[5] $gmt[2]:$gmt[1]:$gmt[0] GMT";
		my $cook = "";print "Set-Cookie: EB=$cook; expires=$date_gmt\n";
	}
	print "Location: $MAIN_SCRIPT" . "\n\n";


}

sub EXPORT2 {
$to='l';$o=time;


	&HEADER if !$FORM{'pname'} && !$FORM{'pass'};
	print << "	-----END-----" if !$FORM{'pname'} && !$FORM{'pass'};
	<script language="JavaScript">
		function checkRiyou (){
			if (document.del.pname.value == '') {window.alert("ID�S����J");return false
			}else if(document.del.pass.value == '') {window.alert("PASS�S����J");return false
			}else {if (confirm('OK�T�{��O���q�ӪA�Ⱦ��R���A�ಾ�O���}�l\\n�A�T�{�ܡH') == true){return true;}else{return false}	}
		}
	</script>
		<table width=100% height=100%><tr><td align=center>
		<table bgcolor=#000000 border=0 style="font-size:12px;">
			<tr><td colspan=2 bgcolor=#646464 align=center><img src=\"$IMG_FOLDER1/w.gif\"></td></tr>
			<tr><td colspan=2 bgcolor=#000000 align=center>
			<b style="font-size:20px;">Data Export Utility</b><br>
			�{�b�ɮ��ಾ�}�l�A�b�ɮ��ಾ��A�A������<br>
			�Z���B�H�ε��ŵ��H�����N�����A�n���n�߲z�ǳ�<br>
			�p�G�A�T�w�n�ಾ�ɮ�<br>
			����ЧA�~���J<br><br>
			<br></td></tr>
			<tr><td align=right style="height:21px; color:#ffffff; font-size:16px;">�Τ�W<br>
					�Τ�K�X</td>
				<td style="height:21px; color:#ffffff; font-size:16px;">
					<form action=$MAIN_SCRIPT method=POST target=_top name=del onSubmit="return checkRiyou()">
					<input type=hidden name=cmd value=EXPORT>
					<input type=text size=20 name=pname value="" $STYLE_L><br>
					<input type=password size=15 name=pass value="" $STYLE_L>
					</td></tr>
			<tr><td colspan=3 align=center><br><br>��J��аO���o�ǫH��<br>
				<input type=submit value=\"Export\" class=button2 >
			</td></form></tr>

		</table></td></tr></table>

	-----END-----
if ($FORM{'pname'} && $FORM{'pass'} && $FORM{'cmd'}){
	&LOCK;
		dbmopen (%P,"$DBM_P",0666);
			@pass = split(/\s/,$P{"$FORM{'pname'}"});
			if (!$P{"$FORM{'pname'}"}){dbmclose %P;&UNLOCK;&ERROR('�Τ�W��J���~');}
			if ($pass[2] ne crypt("$FORM{'pass'}",eb)){dbmclose %P;&UNLOCK;&ERROR('�K�X��J���~');}
			delete $P{"$FORM{'pname'}"};
		dbmclose %P;
	&UNLOCK;
	my @gmt = gmtime(time + $COOKIE_KEEP*24*60*60);
	$gmt[0] = sprintf("%02d", $gmt[0]);	$gmt[1] = sprintf("%02d", $gmt[1]);
	$gmt[2] = sprintf("%02d", $gmt[2]);	$gmt[3] = sprintf("%02d", $gmt[3]);	$gmt[5] += 1900;
	$gmt[4] = ('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')[$gmt[4]];
	$gmt[6] = ('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday')[$gmt[6]];
	my $date_gmt = "$gmt[6], $gmt[3]\-$gmt[4]\-$gmt[5] $gmt[2]:$gmt[1]:$gmt[0] GMT";
	my $cook = "";print "Set-Cookie: EB=$cook; expires=$date_gmt\n";

	$pass1=crypt "$FORM{'pname'}",eb;
	$pass3="$pass[19]$pass[20]$pass[21]$pass[22]";
	$pass3=crypt "$pass3",eb;
	$pass4="$pass[16]$pass[18]";
	$pass4=crypt "$pass4",eb;
	$pass5="$pass[12]$pass[29]";
	$pass5=crypt "$pass5",eb;
	@ex=("$pass[12]","$pass[16]","$pass[18]","$pass[19]","$pass[20]","$pass[21]","$pass[22]","$pass[23]","$pass[24]","$pass[29]","$o");
	foreach (@ex){
		foreach $k(0..9){$to++;$_ =~ s/$k/$to/eg;}
	}
	$EX="$ex[0]!$ex[1]!$pass1!$ex[2]!$ex[3]!$pass3!$ex[4]!$ex[5]!$pass[2]!$ex[6]!$ex[7]!$ex[8]!$pass4!$ex[9]!$pass5!$ex[10]";
	&HEADER;
	print << "	-----END-----";
		<table width=100% height=100%><tr><td align=center>
		<table bgcolor=#000000 border=0 style="font-size:12px;">
			<tr><td bgcolor=#646464 align=center><img src=\"$IMG_FOLDER1/w.gif\"></td></tr>
			<tr><td bgcolor=#000000 align=center>
			<b style="font-size:20px;">Data Export Utility</b><br>
			<div align=left>&nbsp;&nbsp;�O���R���A��X�ಾ���`����<br>
			�H�U��ܪ��O�A�����骺�ƭȥN�X<br>
			�Ф@�r���|�a�߶K��A���O�ƪO�W<br>
			�����O�s�A�o����ಾ�D�`���n<br>

			</div>
			&nbsp;&nbsp;�ಾ�ɮת����Ĵ������@�ӬP��<br>�W�L�o�Ӯɭ����ಾ�ɮצ��i��Q�t�ε����L��</div>
			<br></td></tr>
			<tr>
				<td style="height:21px; color:#ffffff; font-size:16px;">
					<textarea rows=5 cols=50>$EX</textarea>
					</td></tr>
		</table>
	-----END-----
	&FOOTER;
	print "</td></tr></table></body>";

	}
}

sub INPORT2{
	&DBM_INPORT(P);
	@CountPl=keys %P;
	$Count=@CountPl;
	
	if ($Count >= $ENTRY_MAX){&ERROR('�W�L�n���H�ƭ��B');}
	
	&HEADER;
	require "$LOG_FOLDER/$HASH_DATA";
	print << "	-----END-----";
	(�ثe�H��:$Count  �̤j�H��:$ENTRY_MAX)<br>
	<script language="JavaScript">
		function checkRiyou (){
			if (document.del.pname.value == '') {window.alert("ID�S����J");return false
			}else if(document.del.pass.value == '') {window.alert("PASS�S����J");return false
			}else if(document.del.indata.value == '') {window.alert("��O�ȥN�X�S����J");return false
			}else if(document.del.MsName.value == '') {window.alert("����W�٨S����J");return false
			}else {if (confirm('�ಾ�^�и�ƶ}�l\\n�A�T�w�ܡH') == true){return true;}else{return false}	}
		}
	</script>
		<table width=100% height=100%><tr><td align=center>
		<table bgcolor=#000000 border=0 style="font-size:12px;">
			<tr><td colspan=2 bgcolor=#646464 align=center><img src=\"$IMG_FOLDER1/w.gif\"></td></tr>
			<tr><td colspan=2 bgcolor=#000000 align=center>
			<b style="font-size:20px;">Data Inport Utility</b><br>
			�o�ӿﶵ�Ψӱ��Ǩ䥦�a���ಾ���Τ�W<br>
			�����`�N���O��Ӫ������A���šA�H�ΪZ���b�ಾ��O�����_��<br>
			�H�U����m�п�J�Τ�W�H���ಾ�N�X<br><br>
			<br></td></tr>
			<tr><td align=right style="height:21px; color:#ffffff; font-size:16px;" valign=top>�Τ�W<br>
					�Τ�K�X<br><br>�ಾ�N�X</td>
				<td style="height:21px; color:#ffffff; font-size:16px;">
					<form action=$MAIN_SCRIPT method=POST target=_top name=del onSubmit="return checkRiyou()">
					<input type=hidden name=cmd value=INPORT5>
					<input type=text size=20 name=pname value="" $STYLE_L><br>
					<input type=password size=15 name=pass value="" $STYLE_L><br>
					<textarea rows=5 cols=50 name=indata>$EX</textarea>
					</td></tr>
	-----END-----
	print "<script language=\"JavaScript\">\nfunction changeImg(){num=document.del.icon.value;document.msImg.src=\"$IMG_FOLDER2/\"+ num +\".gif\";}\n</script>";
	&JScfm(checkCustom,"���魫�s�]�m�A�A�T�{�ܡH");
	print "<tr><td $BgColor colspan=2 style=\"font-size:16px;\"><b>����@��</b><br><br>\n";
	print "&nbsp;&nbsp;ICON�ܧ�<img src=\"$IMG_FOLDER2/1.gif\" name=\"msImg\"><br>\n";
	print "&nbsp;&nbsp;&nbsp;&nbsp;<select name=\"icon\" $STYLE_L onChange=\"changeImg()\">\n";
	foreach (0..$ICON){
		print "<option value=\"$_\"";
		print " selected\n"if $_ eq $PL_VALUES[27];
		print ">ICON No.$_\n";
	}
	print "</select><br>&nbsp;&nbsp;MS����<br>&nbsp;&nbsp;&nbsp;&nbsp;\n";
	print "<input type=text name=MsName size=30 maxlength=15 value=\"\" $STYLE_L><br>\n";
	print "&nbsp;&nbsp;�����O�ܧ�<br>&nbsp;&nbsp;&nbsp;&nbsp;\n";
	print "<select name=MsType $STYLE_L>\n";
	print "<option value=1";print " selected"if $PL_VALUES[4] eq '1';print ">�����O����\n";
	print "<option value=2";print " selected"if $PL_VALUES[4] eq '2';print ">���m�O����\n";
	print "<option value=3";print " selected"if $PL_VALUES[4] eq '3';print ">�ӱ��׭���\n";
	print "<option value=4";print " selected"if $PL_VALUES[4] eq '4';print ">�R���v����\n";
	print "<option value=0";print " selected"if $PL_VALUES[4] eq '0';print ">������</select><br>\n";
	print "&nbsp;&nbsp;�Z��<br>&nbsp;&nbsp;&nbsp;&nbsp;<select name=\"w\" $STYLE_L>";
	while (my($wkey,$wvalue) =each %WEAPON_LIST) {
		if (length($wkey) == 1){my@w=split(/,/,$wvalue);print "<option value=$wkey>$w[0]\n" if $w[6] !=2 && $w[6] !=6 && $w[6] !=4;}
	}

	print "</select><br>";
	print "&nbsp;&nbsp;�C���ܧ�<br>&nbsp;&nbsp;&nbsp;&nbsp;\n";
	$br=0;
		foreach (@COLOR){$br++;
			print "<input type=\"radio\" name=\"MsColor\" value=$_";
	        print " checked" if $br == 1;
	        print "><font color=$_>��</font>\n";
			if ($br%10==0){print"<br>&nbsp;&nbsp;&nbsp;&nbsp;\n";}
		}
	print << "	-----END-----";
			<tr><td colspan=3 align=center><br><br>��J��аO���o�Ǹ��<br>
				<input type=submit value=\"�ಾ\" class=button2 >
			</td></tr>

		</table>

	-----END-----
	&FOOTER;
	print "</td></tr></table></form></body>";


}
sub INPORT3{

	@pass=split(/\!/,$FORM{'indata'});
	&ERROR('�Τ�W��') if $pass[2] ne crypt("$FORM{'pname'}",eb);
	&ERROR('�Τ�K�X��') if $pass[8] ne crypt("$FORM{'pass'}",eb);

	@in=("$pass[0]","$pass[1]","$pass[3]","$pass[4]","$pass[6]","$pass[7]","$pass[9]","$pass[10]","$pass[11]","$pass[13]","$pass[15]");
	foreach (@in){foreach $k(0..9){$to++;$_ =~ s/$to/$k/eg;}}
	$pass1="$in[3]$in[4]$in[5]$in[6]";
	$pass2="$in[1]$in[2]";
	$pass3="$in[0]$in[9]";
	&ERROR('��_��ƥ���') if crypt ("$pass1",eb) ne "$pass[5]" || crypt("$pass2",eb) ne "$pass[12]" || crypt("$pass3",eb) ne "$pass[14]";
	$c=0;
	foreach (@in){
		if ($c==4 ||$c==5 ||$c==6 ||$c==7){&ERROR('��_��ƥ���') if $_ < 0 || $_ > 65;}
		if ($c==10){&ERROR('�W�L��_���Ĵ���') if $_ > time+(604800);}
		$c++;
	}

		&LOCK;
	$pwd=crypt "$FORM{'pass'}",eb;
	dbmopen (%PL,"$DBM_P",0666);
		if($PL{"$FORM{'pname'}"}){dbmclose (%PL);&UNLOCK;&ERROR('�w�g���ۦP���Τ�W�s�b');}
		$PL{"$FORM{'pname'}"} = ("1 $DATE $pwd $FORM{'MsName'} $FORM{'MsType'}  0 noComment 0 $FORM{'w'}!0   $in[0] $FORM{'MsColor'} 0 $in[1] $in[1] $in[2] $in[2] $in[3] $in[4] $in[5] $in[6] $in[7] $in[8] 0 $DATE $FORM{'icon'}  $in[9] 0");
	dbmclose (%PL);
	&UNLOCK;
	SET_COOKIE:{
		my @gmt = gmtime(time + $COOKIE_KEEP*24*60*60);
		$gmt[0] = sprintf("%02d", $gmt[0]);	$gmt[1] = sprintf("%02d", $gmt[1]);
		$gmt[2] = sprintf("%02d", $gmt[2]);	$gmt[3] = sprintf("%02d", $gmt[3]);	$gmt[5] += 1900;
		$gmt[4] = ('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')[$gmt[4]];
		$gmt[6] = ('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday')[$gmt[6]];
		my $date_gmt = "$gmt[6], $gmt[3]\-$gmt[4]\-$gmt[5] $gmt[2]:$gmt[1]:$gmt[0] GMT";
		my $cook = "pname:$FORM{'pname'},pass:$FORM{'pass'}";print "Set-Cookie: EB=$cook; expires=$date_gmt\n";
	}
	print "Location: $MAIN_SCRIPT" . "\n\n";

}


1;
