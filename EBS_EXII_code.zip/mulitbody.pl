#!/usr/bin/perl
#DEBUG ��@..�ۧ@�v,���v�Ҧ�

print "Content-type: text/html;\n\n";
#@pair = split(/;/, $ENV{'HTTP_COOKIE'});
#print "Current Key:<br>";
#foreach (@pair) {my($key, $value) = split(/=/, $_);$DUMMY{$key} = $value;print "$value <br>";}
#print "Current:<br>";
#@pairs = split(/,/, $DUMMY{EB});
#foreach (@pairs) {my($key, $value) = split(/:/, $_);$COOKIE{$key} = $value;print "$value <br>";}


#exit;
require 'config.cgi';
require "debug_sub.pl";
print "ID ���� ���R��:<br>";
@tasvalue=read_file("$EventRecordDir/muiltuserec.txt");
$Kide=0;
foreach(@tasvalue)
{
if (($Kide % 2) eq 0){$fontcolor="#000000";}else{$fontcolor="#0000FF";}
print "<font color=$fontcolor> $_ <font><br>";
if (length($_)>5 ){$Kide++;}
}	


