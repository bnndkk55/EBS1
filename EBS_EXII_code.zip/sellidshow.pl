#!/usr/bin/perl
require 'config.cgi';
require "ebs_sub1.cgi";
print "Content-type: text/html;charset=big5\n\n";
&DBM_INPORT(P);
while (($Name,$Val) = each %P)
{
@TVALUES = split(/\s/,$Val);
if (@TVALUES[94] ne ""){print "@TVALUES[94]:$Name,";}
}
1;